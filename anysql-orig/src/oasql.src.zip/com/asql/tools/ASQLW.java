package com.asql.tools;

import com.asql.core.DBConnection;
import com.asql.swt.SWTCommand;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class ASQLW
{
  private Display display = null;
  
  public void RunApplication(Display paramDisplay)
  {
    int i = 0;
    this.display = paramDisplay;
    Display.setAppName("AnySQL");
    new SWTCommand();
    while (i == 0) {
      try
      {
        if ((!this.display.isDisposed()) && (!this.display.readAndDispatch())) {
          this.display.sleep();
        }
        Shell[] arrayOfShell = this.display.getShells();
        i = 1;
        for (int j = 0; j < arrayOfShell.length; j++) {
          if (!arrayOfShell[j].isDisposed())
          {
            i = 0;
            break;
          }
        }
        if (i != 0) {
          break;
        }
      }
      catch (Throwable localThrowable) {}
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    DBConnection.setLocale("ENGLISH");
    Display localDisplay = Display.getDefault();
    ASQLW localASQLW = new ASQLW();
    localASQLW.RunApplication(localDisplay);
    if (!localDisplay.isDisposed()) {
      localDisplay.dispose();
    }
  }
}


/* Location:           D:\tmp\oasql.jar
 * Qualified Name:     com.asql.tools.ASQLW
 * JD-Core Version:    0.7.0.1
 */