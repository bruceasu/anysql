package com.asql.tools;

import com.asql.core.Command;
import com.asql.core.CommandLog;
import com.asql.core.DBConnection;
import com.asql.core.DefaultSQLExecutor;
import com.asql.mysql.MySQLSQLExecutor;
import com.asql.oracle.OracleSQLExecutor;
import com.asql.sybase.SybaseSQLExecutor;
import java.io.IOException;

public class ASQL
{
  public static void main(String[] paramArrayOfString)
    throws IOException
  {
    DBConnection.setLocale("ENGLISH");
    Object localObject = null;
    String str1 = "ORACLE";
    String str2 = null;
    String str3 = null;
    for (int i = 0; i < paramArrayOfString.length; i++) {
      if (paramArrayOfString[i].toUpperCase().startsWith("--")) {
        str1 = paramArrayOfString[i].substring(2);
      } else if (paramArrayOfString[i].toUpperCase().startsWith("USERID=")) {
        str2 = paramArrayOfString[i].substring(7);
      } else if (paramArrayOfString[i].toUpperCase().startsWith("START=")) {
        str3 = paramArrayOfString[i].substring(6);
      }
    }
    if ("ORACLE".equalsIgnoreCase(str1)) {
      localObject = new OracleSQLExecutor();
    } else if ("SYBASE".equalsIgnoreCase(str1)) {
      localObject = new SybaseSQLExecutor();
    } else if ("MSSQL".equalsIgnoreCase(str1)) {
      localObject = new SybaseSQLExecutor();
    } else if ("MYSQL".equalsIgnoreCase(str1)) {
      localObject = new MySQLSQLExecutor();
    } else {
      localObject = new OracleSQLExecutor();
    }
    Command localCommand;
    if ((str2 != null) && (str2.length() > 0))
    {
      localCommand = new Command(5, 5, "CONNECT " + str2);
      ((DefaultSQLExecutor)localObject).run(localCommand);
    }
    if ((str3 != null) && (str3.length() > 0))
    {
      localCommand = new Command(16, 16, "@ " + str3);
      ((DefaultSQLExecutor)localObject).run(localCommand);
    }
    else
    {
      ((DefaultSQLExecutor)localObject).run();
    }
    if (((DefaultSQLExecutor)localObject).getCommandLog().getLogFile() != null) {
      ((DefaultSQLExecutor)localObject).getCommandLog().getLogFile().close();
    }
    ((DefaultSQLExecutor)localObject).getCommandLog().setLogFile(null);
  }
}


/* Location:           D:\tmp\oasql.jar
 * Qualified Name:     com.asql.tools.ASQL
 * JD-Core Version:    0.7.0.1
 */