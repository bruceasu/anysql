package com.asql.oracle;

import com.asql.core.CMDType;
import com.asql.core.Command;
import com.asql.core.CommandLog;
import com.asql.core.CommandReader;
import com.asql.core.DBConnection;
import com.asql.core.DBOperation;
import com.asql.core.DBRowCache;
import com.asql.core.DateOperator;
import com.asql.core.DefaultSQLExecutor;
import com.asql.core.InputCommandReader;
import com.asql.core.JavaVM;
import com.asql.core.OptionCommand;
import com.asql.core.OutputCommandLog;
import com.asql.core.SQLCallable;
import com.asql.core.SQLStatement;
import com.asql.core.SQLTypes;
import com.asql.core.SimpleDBRowCache;
import com.asql.core.TextUtils;
import com.asql.core.VariableTable;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.Reader;
import java.io.Writer;
import java.math.BigInteger;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Vector;
import java.util.zip.GZIPOutputStream;

public class OracleSQLExecutor
  extends DefaultSQLExecutor
{
  private CMDType _cmdtype = null;
  private CommandLog _stdout = null;
  private CommandReader _stdin = null;
  private VariableTable tnsnames = new VariableTable();
  private Command lastcommand = null;
  private String autotrace_type = "OFF";
  private String autotrace_name = "ALL";
  private String oracle_driver = "THIN";
  private SQLStatement[] desc_sqls = new SQLStatement[10];
  private SQLStatement[] trace_sqls = new SQLStatement[9];
  private CheckNet[] check_oranet = new CheckNet[50];
  private Hashtable h_statname = new Hashtable();
  private int scan_limit = 4096;
  private String last_object_type = null;
  private String last_object_owner = null;
  private String last_object_name = null;
  private DBRowCache load_buffer = new SimpleDBRowCache();
  private String[] oracle_ora_function = { "PARAMETER", "INITORA", "SPID", "2PC", "ACTIVE", "SQL", "SORT", "SESSION", "BGSESS", "DEAD", "TSFREE", "FILEFREE", "SEGMENT", "EXTENT", "NOINDEX", "INDEX", "RBS", "LOCKWAIT", "TSBH", "OBJBH", "USERBH", "RECOVER", "TRAN", "BUSY", "CHAIN", "PGA", "LIBCACHE", "ROWCACHE", "SYSSTAT", "WAITSTAT", "SYSEVENT", "TSSTAT", "FILESTAT", "SESSTAT", "SEGSTAT", "BLOCK", "DDLLOCK", "BACKUP", "LOGHIS", "TOPEXE", "TOPGETS", "TOPREAD", "TOPGET", "WAIT", "SGASTAT", "LATCH", "LOCK", "OBJECT", "LONGOPS", "TABLESPACE", "DATAFILE", "ARCLOG", "LATCHWAIT", "CURSOR", "GLOBAL", "MOVEIND", "MOVETAB", "SHARE", "UNDO", "UNDOHDR", "_PARAMETER", "CHARSET", "SQLMEM", "HASH", "HOLD", "ACTIVESQL", "BLOCKING", "PXSTAT", "PX", "PXSESS", "PXPROCESS", "PQSLAVE", "XPLAN", "SQLLIKE", "WSQL", "PLAN", "FREESPACE", "MACHINE", "KILLMACHINE", "KILLUSER", "HOT", "KILLSQL", "KILLHOLD", "TSTAT", "ISTAT", "SIZE", "UNUSABLE", "INVALID", "FILEOBJ", "RESIZE", "NOLOGGING", "OBJSQL", "SPTOPSQL", "SPSQL", "OBJGRANT", "PLAN+", "SPSTAT", "SPEVENT" };
  private final int ORACLE_ORA_PARAMETER = 0;
  private final int ORACLE_ORA_INITORA = 1;
  private final int ORACLE_ORA_SPID = 2;
  private final int ORACLE_ORA_2PC = 3;
  private final int ORACLE_ORA_ACTIVE = 4;
  private final int ORACLE_ORA_SQL = 5;
  private final int ORACLE_ORA_SORT = 6;
  private final int ORACLE_ORA_SESSION = 7;
  private final int ORACLE_ORA_BGSESSION = 8;
  private final int ORACLE_ORA_DEAD = 9;
  private final int ORACLE_ORA_TSFREE = 10;
  private final int ORACLE_ORA_FILEFREE = 11;
  private final int ORACLE_ORA_SEGMENT = 12;
  private final int ORACLE_ORA_EXTENT = 13;
  private final int ORACLE_ORA_NOINDEX = 14;
  private final int ORACLE_ORA_INDEX = 15;
  private final int ORACLE_ORA_RBS = 16;
  private final int ORACLE_ORA_LOCKWAIT = 17;
  private final int ORACLE_ORA_TSBH = 18;
  private final int ORACLE_ORA_OBJBH = 19;
  private final int ORACLE_ORA_USERBH = 20;
  private final int ORACLE_ORA_RECOVER = 21;
  private final int ORACLE_ORA_TRANSACTION = 22;
  private final int ORACLE_ORA_BUSY = 23;
  private final int ORACLE_ORA_CHAIN = 24;
  private final int ORACLE_ORA_PGA = 25;
  private final int ORACLE_ORA_LIBCACHE = 26;
  private final int ORACLE_ORA_ROWCACHE = 27;
  private final int ORACLE_ORA_SYSSTAT = 28;
  private final int ORACLE_ORA_WAITSTAT = 29;
  private final int ORACLE_ORA_SYSEVENT = 30;
  private final int ORACLE_ORA_TSSTAT = 31;
  private final int ORACLE_ORA_FILESTAT = 32;
  private final int ORACLE_ORA_SESSTAT = 33;
  private final int ORACLE_ORA_SEGSTAT = 34;
  private final int ORACLE_ORA_BLOCK = 35;
  private final int ORACLE_ORA_DDLLOCK = 36;
  private final int ORACLE_ORA_BACKUP = 37;
  private final int ORACLE_ORA_LOGHIS = 38;
  private final int ORACLE_ORA_TOPEXE = 39;
  private final int ORACLE_ORA_TOPGETS = 40;
  private final int ORACLE_ORA_TOPREAD = 41;
  private final int ORACLE_ORA_TOPGET = 42;
  private final int ORACLE_ORA_WAIT = 43;
  private final int ORACLE_ORA_SGASTAT = 44;
  private final int ORACLE_ORA_LOCK = 45;
  private final int ORACLE_ORA_OBJECT = 46;
  private final int ORACLE_ORA_GLOBAL = 47;
  private final int ORACLE_ORA_MOVEIND = 48;
  private final int ORACLE_ORA_MOVETAB = 49;
  private final int ORACLE_ORA_SHARE = 50;
  private final int ORACLE_ORA_UNDO = 51;
  private final int ORACLE_ORA_UNDOHDR = 52;
  private final int ORACLE_ORA__PARAMETER = 53;
  private final int ORACLE_ORA_CHARSET = 54;
  private final int ORACLE_ORA_SQLMEM = 55;
  private final int ORACLE_ORA_HASH = 63;
  private final int ORACLE_ORA_XPLAN = 72;
  private String[] oracle_list_type = { "OBJECT", "CLUSTER", "INDEX", "SEQUENCE", "SYNONYM", "TABLE", "TRIGGER", "TYPE", "VIEW", "MVIEW", "TABPART", "INDPART", "PROCEDURE", "FUNCTION", "PACKAGE", "SEGMENT", "REBUILD", "LOB", "QUEUE", "LOBPART" };
  private final int ORACLE_SQLFILE_1 = 0;
  private final int ORACLE_SQLFILE_2 = 1;
  private final int ORACLE_LIST_OBJECT = 0;
  private final int ORACLE_LIST_CLUSTER = 1;
  private final int ORACLE_LIST_INDEX = 2;
  private final int ORACLE_LIST_SEQUENCE = 3;
  private final int ORACLE_LIST_SYNONYM = 4;
  private final int ORACLE_LIST_TABLE = 5;
  private final int ORACLE_LIST_TRIGGER = 6;
  private final int ORACLE_LIST_TYPE = 7;
  private final int ORACLE_LIST_VIEW = 8;
  private final int ORACLE_LIST_MVIEW = 9;
  private final int ORACLE_LIST_TABPART = 10;
  private final int ORACLE_LIST_INDPART = 11;
  private final int ORACLE_LIST_PROCEDURE = 12;
  private final int ORACLE_LIST_FUNCTION = 13;
  private final int ORACLE_LIST_PACKAGE = 14;
  private final int ORACLE_LIST_SEGMENT = 15;
  private final int ORACLE_LIST_REBUILD = 16;
  private final int ORACLE_LIST_LOB = 17;
  private final int ORACLE_LIST_QUEUE = 18;
  private final int ORACLE_LIST_LOBPART = 19;
  private String[] oracle_show_keys = { "USER", "SGA", "SESSION", "CHILD", "PARENT", "CONSTRAINT", "CONS", "VERSION", "SPACE", "TABLE", "STATS", "WAIT", "VARIABLE", "ERRORS", "LOAD", "TOPSQL" };
  private final int ORACLE_SHOW_USER = 0;
  private final int ORACLE_SHOW_SGA = 1;
  private final int ORACLE_SHOW_SESSION = 2;
  private final int ORACLE_SHOW_CHILD = 3;
  private final int ORACLE_SHOW_PARENT = 4;
  private final int ORACLE_SHOW_CONSTRAINT = 5;
  private final int ORACLE_SHOW_CONS = 6;
  private final int ORACLE_SHOW_VERSION = 7;
  private final int ORACLE_SHOW_SPACE = 8;
  private final int ORACLE_SHOW_TABLE = 9;
  private final int ORACLE_SHOW_STATS = 10;
  private final int ORACLE_SHOW_WAIT = 11;
  private final int ORACLE_SHOW_VARIABLE = 12;
  private final int ORACLE_SHOW_ERRORS = 13;
  private final int ORACLE_SHOW_LOAD = 14;
  private final int ORACLE_SHOW_TOPSQL = 15;
  protected static final int ORACLE_LOB = 0;
  protected static final int ORACLE_LOBEXP = 1;
  protected static final int ORACLE_CROSS = 2;
  protected static final int ORACLE_LOBIMP = 3;
  protected static final int ORACLE_EXPLAINPLAN = 4;
  protected static final int ORACLE_UNLOAD = 5;
  protected static final int ORACLE_LOBLEN = 6;
  protected static final int ORACLE_LOAD = 7;
  protected static final int ORACLE_EXPMVIEW = 8;
  protected static final int ORACLE_EXPREWRITE = 9;
  protected static final int ORACLE_SHOW = 0;
  protected static final int ORACLE_DESCRIBE = 1;
  protected static final int ORACLE_SOURCE = 2;
  protected static final int ORACLE_DESC = 3;
  protected static final int ORACLE_LIST = 4;
  protected static final int ORACLE_DEPEND = 5;
  protected static final int ORACLE_ORAFUNCTION = 6;
  protected static final int ORACLE_START = 7;
  protected static final int ORACLE_HOST = 8;
  protected static final int ORACLE_CONNECT = 0;
  protected static final int ORACLE_DEBUGLEVEL = 1;
  protected static final int ORACLE_PAGESIZE = 2;
  protected static final int ORACLE_HEADING = 3;
  protected static final int ORACLE_DELIMITER = 4;
  protected static final int ORACLE_RECORD = 5;
  protected static final int ORACLE_DISCONNECT = 6;
  protected static final int ORACLE_LOADTNS = 7;
  protected static final int ORACLE_CONN = 8;
  protected static final int ORACLE_VAR = 9;
  protected static final int ORACLE_UNVAR = 10;
  protected static final int ORACLE_PRINT = 11;
  protected static final int ORACLE_AUTOTRACE = 12;
  protected static final int ORACLE_TIMING = 13;
  protected static final int ORACLE_AUTOT = 14;
  protected static final int ORACLE_AUTOCOMMIT = 15;
  protected static final int ORACLE_FETCHSIZE = 16;
  protected static final int ORACLE_ECHO = 17;
  protected static final int ORACLE_DEFINE = 18;
  protected static final int ORACLE_DRIVER = 19;
  protected static final int ORACLE_TERMOUT = 20;
  protected static final int ORACLE_SQLSET = 21;
  protected static final int ORACLE_SPOOLAPPEND = 22;
  protected static final int ORACLE_SPOOLOFF = 23;
  protected static final int ORACLE_SPOOL = 24;
  protected static final int ORACLE_READ = 25;
  protected static final int ORACLE_HELP = 26;
  protected static final int ORACLE_LCOMMAND = 27;
  protected static final int ORACLE_READONLY = 28;
  protected static final int ORACLE_LOCALE = 29;
  protected static final int ORACLE_SCANLIMIT = 30;
  protected static final int ORACLE_TUNESORT = 31;
  protected static final int ORACLE_ENCODING = 32;
  protected static final int ORACLE_BUFFER_ADD = 33;
  protected static final int ORACLE_BUFFER_LIST = 34;
  protected static final int ORACLE_BUFFER_RESET = 35;
  protected static final int ORACLE_QUERYONLY = 36;
  protected static final int ORACLE_OLHASH = 37;
  protected static final int ORACLE_OLDROP = 38;
  protected static final int ORACLE_OLSHIFT = 39;
  protected static final int ORACLE_OLSHOW = 40;
  protected static final int ORACLE_OLMOVE = 41;
  protected static final int ORACLE_OLLIST = 42;
  protected static final int ORACLE_OLSQL = 43;
  protected static final int ORACLE_OLRENAME = 44;
  protected static final int ORACLE_OL = 45;
  
  public OracleSQLExecutor()
  {
    super(new OracleCMDType());
    Properties localProperties = System.getProperties();
    String str1 = localProperties.getProperty("os.name");
    String str2 = localProperties.getProperty("ORACLE_HOME");
    loadTNSNames("tnsnames.ora");
    loadTNSNames(JavaVM.JAVA_HOME + "/tnsnames.ora");
    if ((str2 != null) && (str2.length() > 0))
    {
      String str3 = null;
      if (str1.toUpperCase().startsWith("WINDOWS")) {
        str3 = str2 + "\\network\\admin\\tnsnames.ora";
      } else {
        str3 = str2 + "/network/admin/tnsnames.ora";
      }
      loadTNSNames(str3);
    }
  }
  
  private void getObjectFromCommand(String paramString)
  {
    String[] arrayOfString = TextUtils.toStringArray(TextUtils.getWords(paramString));
    int i = 0;
    this.last_object_type = null;
    this.last_object_owner = null;
    this.last_object_name = null;
    while ((arrayOfString[i].equalsIgnoreCase("ALTER")) || (arrayOfString[i].equalsIgnoreCase("CREATE")) || (arrayOfString[i].equalsIgnoreCase("OR")) || (arrayOfString[i].equalsIgnoreCase("REPLACE")) || (arrayOfString[i].equalsIgnoreCase("PUBLIC")) || (arrayOfString[i].equalsIgnoreCase("DROP"))) {
      i++;
    }
    if ((i < arrayOfString.length) && (i > 0))
    {
      if ((arrayOfString[i].equalsIgnoreCase("PACKAGE")) || (arrayOfString[i].equalsIgnoreCase("TYPE")))
      {
        i++;
        if (i < arrayOfString.length) {
          if (arrayOfString[i].equalsIgnoreCase("BODY"))
          {
            this.last_object_type = (arrayOfString[(i - 1)].toUpperCase() + " BODY");
          }
          else
          {
            this.last_object_type = arrayOfString[(i - 1)].toUpperCase();
            i--;
          }
        }
      }
      else
      {
        this.last_object_type = arrayOfString[i].toUpperCase();
      }
      i++;
    }
    if ((i < arrayOfString.length) && (i > 0))
    {
      String str = arrayOfString[i].toUpperCase();
      i = str.indexOf("(");
      if (i > 0) {
        str = str.substring(0, i);
      }
      i = str.indexOf(".");
      if (i > 0)
      {
        this.last_object_owner = str.substring(0, i);
        this.last_object_name = str.substring(i + 1);
      }
      else
      {
        this.last_object_name = str;
      }
    }
  }
  
  public OracleSQLExecutor(CommandReader paramCommandReader, CommandLog paramCommandLog)
  {
    super(new OracleCMDType(), paramCommandReader, paramCommandLog);
    Properties localProperties = System.getProperties();
    String str1 = localProperties.getProperty("os.name");
    String str2 = localProperties.getProperty("ORACLE_HOME");
    loadTNSNames("tnsnames.ora");
    if ((str2 != null) && (str2.length() > 0))
    {
      String str3 = null;
      if (str1.toUpperCase().startsWith("WINDOWS")) {
        str3 = str2 + "\\network\\admin\\tnsnames.ora";
      } else {
        str3 = str2 + "/network/admin/tnsnames.ora";
      }
      loadTNSNames(str3);
    }
  }
  
  private void prepareTraceSQL(boolean paramBoolean)
    throws SQLException
  {
    String str2 = "";
    if (paramBoolean)
    {
      SQLStatement localSQLStatement = prepareStatement(this.database, "SELECT STATISTIC#,NAME FROM V$STATNAME \n  WHERE NAME IN ('consistent gets','db block gets','physical reads', \n\t    'bytes sent via SQL*Net to client','execute count','free buffer requested', \n     'free buffer inspected','physical writes','logons cumulative',\n     'CPU used by this session','redo blocks written','DBWR buffers scanned', \n     'consistent changes','parse count (total)','parse count (hard)', \n     'user calls','user commits','db block changes','table scan rows gotten', \n     'table fetch by rowid','sorts (memory)','sorts (disk)','redo size', \n     'enqueue waits','CR blocks created','opened cursors cumulative','SQL*Net roundtrips to/from client')", this.sysvariable);
      DBRowCache localDBRowCache = executeQuery(localSQLStatement, this.sysvariable, 1000);
      for (int j = 1; j <= localDBRowCache.getRowCount(); j++)
      {
        Object localObject = localDBRowCache.getItem(j, 1);
        String str1 = (String)localDBRowCache.getItem(j, 2);
        this.h_statname.put(localObject, str1);
        if (j > 1) {
          str2 = str2 + "," + localObject.toString();
        } else {
          str2 = localObject.toString();
        }
      }
      localSQLStatement.close();
      if (this.trace_sqls[0] == null) {
        this.trace_sqls[0] = prepareStatement(this.database, "SELECT /* AnySQL T0 */ /*+ RULE */ S.STATISTIC#,VALUE \n  FROM V$STATNAME S, v$MYSTAT MY \n  WHERE MY.STATISTIC#(+) = S.STATISTIC# \n    AND S.STATISTIC# IN (" + str2 + ")", this.sysvariable);
      }
      if (this.trace_sqls[1] == null) {
        this.trace_sqls[1] = prepareStatement(this.database, "SELECT /* AnySQL T1 */ /*+ RULE */ STATISTIC#,VALUE \n  FROM V$SYSSTAT WHERE STATISTIC# IN (" + str2 + ")", this.sysvariable);
      }
      if (this.trace_sqls[2] == null) {
        this.trace_sqls[2] = prepareStatement(this.database, "SELECT /* AnySQL T2 */ /*+ RULE */ S.STATISTIC#,VALUE \n  FROM V$STATNAME S,V$SESSTAT MY \n  WHERE MY.STATISTIC# = S.STATISTIC# \n    AND MY.SID = TO_NUMBER(:P_SID) \n    AND S.STATISTIC# IN (" + str2 + ")", this.sysvariable);
      }
      if (this.trace_sqls[3] == null) {
        this.trace_sqls[3] = prepareStatement(this.database, "SELECT /* AnySQL T3 */ /*+ NOMERGE ALL_ROWS */ \n     e.NAME,nvl(s.total_waits,0) waits,nvl(s.time_waited,0) wtime \n  FROM v$event_name e,(SELECT /*+ RULE ORDERED USE_NL(S,E) */ \n           e.EVENT,e.TOTAL_WAITS,e.TIME_WAITED \n           FROM v$session s,v$session_event e \n\t       WHERE e.event not like 'SQL%message%' and e.event not like '%rdbms%'\n            and e.event not like '%wake%' and S.SID = E.SID \n            AND S.AUDSID=USERENV('SESSIONID')) S \n\t WHERE e.NAME = S.EVENT(+) AND e.NAME not like 'SQL%message%' \n\t   and e.NAME not like '%rdbms%' and e.NAME not like '%wake%' \n      and e.name not like 'queue messages' \n      and e.name not like '%timer' \n      and e.name not like '%Idle Wait'", this.sysvariable);
      }
      if (this.trace_sqls[4] == null) {
        this.trace_sqls[4] = prepareStatement(this.database, "SELECT /* AnySQL T4 */ /*+ NOMERGE ALL_ROWS */ \n     n.name,nvl(e.total_waits,0) waits,nvl(e.time_waited,0) wtime \n  FROM (SELECT EVENT,TOTAL_WAITS,TIME_WAITED \n        FROM V$SESSION_EVENT WHERE SID=TO_NUMBER(:P_SID)) E,\n       V$EVENT_NAME N \n  WHERE e.event(+) = n.name \n      AND n.name not like 'SQL%message%' \n      and n.name not like '%rdbms%' \n      and n.name not like '%wake%' \n      and n.name not like 'queue messages' \n      and n.name not like '%timer' \n      and n.name not like '%Idle Wait'", this.sysvariable);
      }
      if (this.trace_sqls[5] == null) {
        this.trace_sqls[5] = prepareStatement(this.database, "SELECT /* AnySQL T5 */ \n     e.event name,nvl(e.total_waits,0) waits,nvl(e.time_waited,0) wtime \n  FROM V$SYSTEM_EVENT e \n\t WHERE e.event not like 'SQL%message%' \n\t   and e.event not like '%rdbms%' \n\t   and e.event not like 'SQL*Net%client' \n      and e.event not like '%wake%' \n      and e.event not like 'queue messages' \n      and e.event not like '%timer' \n      and e.event not like '%Idle Wait' \nUNION ALL \nSELECT 'CPU time',0,VALUE FROM V$SYSSTAT WHERE NAME='CPU used by this session'", this.sysvariable);
      }
      if (this.trace_sqls[6] == null) {
        this.trace_sqls[6] = prepareStatement(this.database, "DELETE /* AnySQL T6 */ FROM PLAN_TABLE WHERE STATEMENT_ID=:PLAN_STMT_ID", this.sysvariable);
      }
      if (this.trace_sqls[7] == null) {
        this.trace_sqls[7] = prepareStatement(this.database, "SELECT /* AnySQL T7 */ * FROM (SELECT /*+ RULE */ \n    LPAD(TO_CHAR(ID),3,' ')||LPAD(NVL(TO_CHAR(PARENT_ID),' '),4,' ')|| \n    ' '||LPAD(' ',2*(LEVEL-1),' ')|| \n    OPERATION||' '||DECODE(OPTIONS,NULL,'','('||OPTIONS||') ')  \n    ||DECODE(ID,0,'Optimizer='||OPTIMIZER||' ','')  \n    ||DECODE(OBJECT_OWNER,NULL,'','OF '||  \n    OBJECT_NAME)||DECODE(OBJECT_TYPE,NULL,' ',' ('||OBJECT_TYPE||') ') SQLPLAN, \n    COST, CARDINALITY CARD,ROUND(Bytes/1024) KByte,PARTITION_START PS,PARTITION_STOP PE\n FROM PLAN_TABLE CONNECT BY PARENT_ID = PRIOR ID AND STATEMENT_ID = PRIOR STATEMENT_ID \n START WITH ID = 0 AND STATEMENT_ID=:PLAN_STMT_ID\n    ORDER BY ID) \n UNION ALL \n SELECT DECODE(ROWNUM,1,CHR(10),'')||SQLPLAN,COST,CARD,BYTES,P1,P2 \n    FROM (SELECT  LPAD(TO_CHAR(ID),3,' ')||'   '||OTHER_TAG SQLPLAN, \n    TO_NUMBER(NULL) COST, TO_NUMBER(NULL) CARD,TO_NUMBER(NULL) Bytes,NULL P1,NULL P2 \n    FROM PLAN_TABLE WHERE OTHER_TAG IS NOT NULL AND STATEMENT_ID = :PLAN_STMT_ID\n    ORDER BY ID)", this.sysvariable);
      }
      if (this.trace_sqls[8] == null) {
        this.trace_sqls[8] = prepareStatement(this.database, "SELECT /* AnySQL T8 */ /*+ RULE */ \n    HASH_VALUE,EXECUTIONS,BUFFER_GETS,DISK_READS,ROWS_PROCESSED,SORTS \n FROM V$SQLAREA \n WHERE ABS(EXECUTIONS) > 0 AND (BUFFER_GETS > 1000 OR BUFFER_GETS < 0 OR DISK_READS > 50)", this.sysvariable);
      }
    }
    else
    {
      this.h_statname.clear();
      for (int i = 0; i < this.trace_sqls.length; i++) {
        if (this.trace_sqls[i] != null) {
          this.trace_sqls[i].close();
        }
      }
      this.trace_sqls[0] = null;
      this.trace_sqls[1] = null;
      this.trace_sqls[2] = null;
      this.trace_sqls[3] = null;
      this.trace_sqls[4] = null;
      this.trace_sqls[5] = null;
      this.trace_sqls[6] = null;
      this.trace_sqls[7] = null;
      this.trace_sqls[8] = null;
    }
  }
  
  protected DBRowCache getSessionStats()
  {
    DBRowCache localDBRowCache = null;
    try
    {
      if (this.trace_sqls[0] != null) {
        localDBRowCache = executeQuery(this.trace_sqls[0], this.sysvariable, 1000);
      }
      return localDBRowCache;
    }
    catch (SQLException localSQLException) {}
    return null;
  }
  
  protected DBRowCache getSQLExecution()
  {
    DBRowCache localDBRowCache = null;
    try
    {
      if (this.trace_sqls[8] != null) {
        localDBRowCache = executeQuery(this.trace_sqls[8], this.sysvariable, 10000);
      }
      return localDBRowCache;
    }
    catch (SQLException localSQLException) {}
    return null;
  }
  
  protected DBRowCache getSessionStats(String paramString1, String paramString2)
  {
    DBRowCache localDBRowCache = null;
    VariableTable localVariableTable = new VariableTable();
    localVariableTable.add("P_SID", 12);
    localVariableTable.add("P_NAME", 12);
    localVariableTable.setValue("P_SID", paramString1);
    localVariableTable.setValue("P_NAME", paramString2);
    try
    {
      if (paramString1 == null)
      {
        if (this.trace_sqls[1] != null) {
          localDBRowCache = executeQuery(this.trace_sqls[1], localVariableTable, 1000);
        }
      }
      else if (this.trace_sqls[2] != null) {
        localDBRowCache = executeQuery(this.trace_sqls[2], localVariableTable, 1000);
      }
      return localDBRowCache;
    }
    catch (SQLException localSQLException) {}
    return null;
  }
  
  protected void printSessionWaits(DBRowCache paramDBRowCache1, DBRowCache paramDBRowCache2)
  {
    if ((paramDBRowCache1 == null) || (paramDBRowCache2 == null)) {
      return;
    }
    if (paramDBRowCache1.getRowCount() == 0) {
      return;
    }
    if (paramDBRowCache1.getRowCount() == paramDBRowCache2.getRowCount())
    {
      this._stdout.println();
      this._stdout.println("Waiting Event");
      this._stdout.println("  Waits     Time  Event");
      this._stdout.println("-----------------------------------------------------");
      for (int i = 1; i <= paramDBRowCache1.getRowCount(); i++)
      {
        String str = paramDBRowCache1.getString(i, 1);
        BigInteger localBigInteger1 = new BigInteger(paramDBRowCache1.getItem(i, 2).toString());
        BigInteger localBigInteger3 = new BigInteger(paramDBRowCache1.getItem(i, 3).toString());
        BigInteger localBigInteger2 = new BigInteger(paramDBRowCache2.getItem(i, 2).toString());
        BigInteger localBigInteger4 = new BigInteger(paramDBRowCache2.getItem(i, 3).toString());
        BigInteger localBigInteger5 = localBigInteger2.add(localBigInteger1.negate());
        BigInteger localBigInteger6 = localBigInteger4.add(localBigInteger3.negate());
        if ((localBigInteger6.longValue() > 0L) && (str.equals(paramDBRowCache2.getItem(i, 1))))
        {
          this._stdout.print(rpad(localBigInteger5.longValue() + " ", 8));
          this._stdout.print(rpad(localBigInteger6.longValue() + "  ", 10));
          this._stdout.println((String)paramDBRowCache1.getItem(i, 1));
        }
      }
    }
  }
  
  protected void printSessionStats(DBRowCache paramDBRowCache1, DBRowCache paramDBRowCache2)
  {
    if ((paramDBRowCache1 == null) || (paramDBRowCache2 == null)) {
      return;
    }
    if (paramDBRowCache1.getRowCount() == 0) {
      return;
    }
    if (paramDBRowCache1.getRowCount() == paramDBRowCache2.getRowCount())
    {
      this._stdout.println();
      this._stdout.println("Statistics");
      this._stdout.println("---------------------------------------------------");
      for (int i = 1; i <= paramDBRowCache1.getRowCount(); i++)
      {
        Object localObject1 = paramDBRowCache1.getItem(i, 1);
        Object localObject2 = paramDBRowCache2.getItem(i, 1);
        BigInteger localBigInteger1 = new BigInteger(paramDBRowCache1.getItem(i, 2).toString());
        BigInteger localBigInteger2 = new BigInteger(paramDBRowCache2.getItem(i, 2).toString());
        BigInteger localBigInteger3 = localBigInteger2.add(localBigInteger1.negate());
        if ((localBigInteger3.longValue() > 0L) && (localObject1.equals(localObject2))) {
          if (localBigInteger3.longValue() > 10000000L) {
            this._stdout.println(rpad(new StringBuffer().append(" ").append(localBigInteger3.longValue() / 1000000L).append("M").toString(), 12) + "  " + this.h_statname.get(localObject1).toString());
          } else if (localBigInteger3.longValue() > 10000L) {
            this._stdout.println(rpad(new StringBuffer().append(" ").append(localBigInteger3.longValue() / 1000L).append("K").toString(), 12) + "  " + this.h_statname.get(localObject1).toString());
          } else {
            this._stdout.println(rpad(new StringBuffer().append(" ").append(localBigInteger3.longValue()).toString(), 12) + "  " + this.h_statname.get(localObject1).toString());
          }
        }
      }
    }
  }
  
  public final DBRowCache getSessionWait()
  {
    DBRowCache localDBRowCache = null;
    try
    {
      if (this.trace_sqls[3] != null) {
        localDBRowCache = executeQuery(this.trace_sqls[3], this.sysvariable, 2000);
      }
    }
    catch (SQLException localSQLException)
    {
      this._stdout.print(localSQLException);
    }
    return localDBRowCache;
  }
  
  public final DBRowCache getSessionWait(String paramString)
  {
    DBRowCache localDBRowCache = null;
    VariableTable localVariableTable = new VariableTable();
    localVariableTable.add("P_SID", 12);
    localVariableTable.setValue("P_SID", paramString);
    try
    {
      if ((paramString != null) && (paramString.length() > 0))
      {
        if (this.trace_sqls[4] != null) {
          localDBRowCache = executeQuery(this.trace_sqls[4], localVariableTable, 2000);
        }
      }
      else if (this.trace_sqls[5] != null) {
        localDBRowCache = executeQuery(this.trace_sqls[5], this.sysvariable, 2000);
      }
    }
    catch (SQLException localSQLException)
    {
      this._stdout.print(localSQLException);
    }
    return localDBRowCache;
  }
  
  public final DBRowCache getSystemEvent()
  {
    DBRowCache localDBRowCache = null;
    try
    {
      if (this.trace_sqls[5] != null) {
        localDBRowCache = executeQuery(this.trace_sqls[5], this.sysvariable, 2000);
      }
    }
    catch (SQLException localSQLException) {}
    return localDBRowCache;
  }
  
  public final DBRowCache getExplainPlan(String paramString)
  {
    DBRowCache localDBRowCache = null;
    String str = "P" + Math.random();
    SQLStatement localSQLStatement = null;
    try
    {
      this.sysvariable.add("PLAN_STMT_ID", 12);
      this.sysvariable.setValue("PLAN_STMT_ID", str);
      if (this.trace_sqls[6] != null)
      {
        this.trace_sqls[6].bind(this.sysvariable);
        this.trace_sqls[6].stmt.execute();
      }
      localSQLStatement = prepareScript(this.database, "EXPLAIN PLAN SET STATEMENT_ID='" + str + "' FOR " + paramString, this.sysvariable);
      localSQLStatement.stmt.execute();
      if (this.trace_sqls[7] != null) {
        localDBRowCache = executeQuery(this.trace_sqls[7], this.sysvariable, 1000);
      }
      if (this.trace_sqls[6] != null)
      {
        this.trace_sqls[6].bind(this.sysvariable);
        this.trace_sqls[6].stmt.execute();
      }
      this.sysvariable.remove("PLAN_STMT_ID");
      localSQLStatement.close();
    }
    catch (SQLException localSQLException1)
    {
      this._stdout.print(localSQLException1);
    }
    try
    {
      if (localSQLStatement != null) {
        localSQLStatement.close();
      }
    }
    catch (SQLException localSQLException2) {}
    return localDBRowCache;
  }
  
  public final boolean execute(Command paramCommand)
  {
    DBRowCache localDBRowCache1 = null;
    DBRowCache localDBRowCache2 = null;
    DBRowCache localDBRowCache3 = null;
    DBRowCache localDBRowCache4 = null;
    long l2 = 0L;
    if (paramCommand == null)
    {
      this._stdout.println("No command to execute.");
      return true;
    }
    long l1;
    switch (paramCommand.TYPE1)
    {
    case 0: 
    case 1: 
    case 2: 
    case 13: 
      if (!isConnected())
      {
        this._stdout.println("Database not connected.");
        return true;
      }
      getObjectFromCommand(paramCommand.COMMAND.substring(0, Math.min(100, paramCommand.COMMAND.length() - 1)));
      this._stdout.println();
      if ((!"OFF".equalsIgnoreCase(this.autotrace_type)) && (("ALL".equalsIgnoreCase(this.autotrace_name)) || ("EVENT".equalsIgnoreCase(this.autotrace_name)))) {
        localDBRowCache3 = getSessionWait();
      }
      if ((!"OFF".equalsIgnoreCase(this.autotrace_type)) && (("ALL".equalsIgnoreCase(this.autotrace_name)) || ("STATISTICS".equalsIgnoreCase(this.autotrace_name)) || ("STATS".equalsIgnoreCase(this.autotrace_name)))) {
        localDBRowCache1 = getSessionStats();
      }
      l1 = System.currentTimeMillis();
      executeSQL(this.database, paramCommand, this.sysvariable, this._stdout);
      l2 = System.currentTimeMillis();
      if (this.timing) {
        this._stdout.println("Execute time: " + DBOperation.getElapsed(l2 - l1));
      }
      if ((!"OFF".equalsIgnoreCase(this.autotrace_type)) && (("ALL".equalsIgnoreCase(this.autotrace_name)) || ("STATISTICS".equalsIgnoreCase(this.autotrace_name)) || ("STATS".equalsIgnoreCase(this.autotrace_name))))
      {
        localDBRowCache2 = getSessionStats();
        printSessionStats(localDBRowCache1, localDBRowCache2);
        localDBRowCache1 = null;
        localDBRowCache2 = null;
      }
      if ((!"OFF".equalsIgnoreCase(this.autotrace_type)) && (("ALL".equalsIgnoreCase(this.autotrace_name)) || ("EVENT".equalsIgnoreCase(this.autotrace_name))))
      {
        localDBRowCache4 = getSessionWait();
        printSessionWaits(localDBRowCache3, localDBRowCache4);
        localDBRowCache3 = null;
        localDBRowCache4 = null;
      }
      if ((paramCommand.TYPE1 != 13) && (paramCommand.TYPE1 != 2) && (!"OFF".equalsIgnoreCase(this.autotrace_type)) && (("ALL".equalsIgnoreCase(this.autotrace_name)) || ("EXPLAIN".equalsIgnoreCase(this.autotrace_name)) || ("EXP".equalsIgnoreCase(this.autotrace_name))))
      {
        DBRowCache localDBRowCache5 = getExplainPlan(paramCommand.COMMAND);
        if (localDBRowCache5 != null)
        {
          this._stdout.println();
          this._stdout.println("Execute Plan");
          showDBRowCache(localDBRowCache5, true);
        }
      }
      this.lastcommand = paramCommand;
      this._stdout.println();
      break;
    case 3: 
      if (!isConnected())
      {
        this._stdout.println("Database not connected.");
        return true;
      }
      getObjectFromCommand(paramCommand.COMMAND.substring(0, Math.min(100, paramCommand.COMMAND.length() - 1)));
      this._stdout.println();
      if ((!"OFF".equalsIgnoreCase(this.autotrace_type)) && (("ALL".equalsIgnoreCase(this.autotrace_name)) || ("EVENT".equalsIgnoreCase(this.autotrace_name)))) {
        localDBRowCache3 = getSessionWait();
      }
      if ((!"OFF".equalsIgnoreCase(this.autotrace_type)) && (("ALL".equalsIgnoreCase(this.autotrace_name)) || ("STATISTICS".equalsIgnoreCase(this.autotrace_name)) || ("STATS".equalsIgnoreCase(this.autotrace_name)))) {
        localDBRowCache1 = getSessionStats();
      }
      l1 = System.currentTimeMillis();
      executeScript(this.database, paramCommand, this.sysvariable, this._stdout);
      l2 = System.currentTimeMillis();
      if (this.timing) {
        this._stdout.println(" Execute time: " + DBOperation.getElapsed(l2 - l1));
      }
      if ((!"OFF".equalsIgnoreCase(this.autotrace_type)) && (("ALL".equalsIgnoreCase(this.autotrace_name)) || ("STATISTICS".equalsIgnoreCase(this.autotrace_name)) || ("STATS".equalsIgnoreCase(this.autotrace_name))))
      {
        localDBRowCache2 = getSessionStats();
        printSessionStats(localDBRowCache1, localDBRowCache2);
        localDBRowCache1 = null;
        localDBRowCache2 = null;
      }
      if ((!"OFF".equalsIgnoreCase(this.autotrace_type)) && (("ALL".equalsIgnoreCase(this.autotrace_name)) || ("EVENT".equalsIgnoreCase(this.autotrace_name))))
      {
        localDBRowCache4 = getSessionWait();
        printSessionWaits(localDBRowCache3, localDBRowCache4);
        localDBRowCache3 = null;
        localDBRowCache4 = null;
      }
      this.lastcommand = paramCommand;
      this._stdout.println();
      break;
    case 7: 
      execute(this.lastcommand);
      break;
    case 4: 
      if (!isConnected())
      {
        this._stdout.println("Database not connected.");
        return true;
      }
      this._stdout.println();
      if ((!"OFF".equalsIgnoreCase(this.autotrace_type)) && (("ALL".equalsIgnoreCase(this.autotrace_name)) || ("EVENT".equalsIgnoreCase(this.autotrace_name)))) {
        localDBRowCache3 = getSessionWait();
      }
      if ((!"OFF".equalsIgnoreCase(this.autotrace_type)) && (("ALL".equalsIgnoreCase(this.autotrace_name)) || ("STATISTICS".equalsIgnoreCase(this.autotrace_name)) || ("STATS".equalsIgnoreCase(this.autotrace_name)))) {
        localDBRowCache1 = getSessionStats();
      }
      l1 = System.currentTimeMillis();
      executeCall(this.database, new Command(paramCommand.TYPE1, paramCommand.TYPE2, skipWord(paramCommand.COMMAND, 1)), this.sysvariable, this._stdout);
      l2 = System.currentTimeMillis();
      if (this.timing) {
        this._stdout.println("Execute time: " + DBOperation.getElapsed(l2 - l1));
      }
      if ((!"OFF".equalsIgnoreCase(this.autotrace_type)) && (("ALL".equalsIgnoreCase(this.autotrace_name)) || ("STATISTICS".equalsIgnoreCase(this.autotrace_name)) || ("STATS".equalsIgnoreCase(this.autotrace_name))))
      {
        localDBRowCache2 = getSessionStats();
        printSessionStats(localDBRowCache1, localDBRowCache2);
        localDBRowCache1 = null;
        localDBRowCache2 = null;
      }
      if ((!"OFF".equalsIgnoreCase(this.autotrace_type)) && (("ALL".equalsIgnoreCase(this.autotrace_name)) || ("EVENT".equalsIgnoreCase(this.autotrace_name))))
      {
        localDBRowCache4 = getSessionWait();
        printSessionWaits(localDBRowCache3, localDBRowCache4);
        localDBRowCache3 = null;
        localDBRowCache4 = null;
      }
      this._stdout.println();
      break;
    case 16: 
      int i = this._cmdtype.startsWith(this._cmdtype.getSQLFile(), paramCommand.COMMAND);
      switch (i)
      {
      case 0: 
        if (procRun2("@@ " + paramCommand.COMMAND.trim().substring(2), paramCommand.WORKINGDIR)) {
          return false;
        }
        break;
      case 1: 
        if (procRun1("@ " + paramCommand.COMMAND.trim().substring(1))) {
          return false;
        }
        break;
      }
      break;
    case 6: 
      int j = getMultipleID(paramCommand.COMMAND);
      switch (j)
      {
      case 0: 
        this._stdout.println();
        l1 = System.currentTimeMillis();
        procLOB(paramCommand.COMMAND);
        l2 = System.currentTimeMillis();
        if (this.timing) {
          this._stdout.println("Execute time: " + DBOperation.getElapsed(l2 - l1));
        }
        this._stdout.println();
        break;
      case 1: 
        this._stdout.println();
        l1 = System.currentTimeMillis();
        procLOBEXP(paramCommand.COMMAND);
        l2 = System.currentTimeMillis();
        if (this.timing) {
          this._stdout.println("Execute time: " + DBOperation.getElapsed(l2 - l1));
        }
        this._stdout.println();
        break;
      case 6: 
        this._stdout.println();
        l1 = System.currentTimeMillis();
        procLOBLEN(paramCommand.COMMAND);
        l2 = System.currentTimeMillis();
        if (this.timing) {
          this._stdout.println("Execute time: " + DBOperation.getElapsed(l2 - l1));
        }
        this._stdout.println();
        break;
      case 3: 
        this._stdout.println();
        l1 = System.currentTimeMillis();
        procLOBIMP(paramCommand.COMMAND);
        l2 = System.currentTimeMillis();
        if (this.timing) {
          this._stdout.println("Execute time: " + DBOperation.getElapsed(l2 - l1));
        }
        this._stdout.println();
        break;
      case 4: 
        this._stdout.println();
        procExplainPlan(paramCommand.COMMAND);
        this._stdout.println();
        break;
      case 8: 
        this._stdout.println();
        procExplainMView(paramCommand.COMMAND);
        this._stdout.println();
        break;
      case 9: 
        this._stdout.println();
        procExplainRewrite(paramCommand.COMMAND);
        this._stdout.println();
        break;
      case 5: 
        this._stdout.println();
        procUnload(paramCommand.COMMAND);
        this._stdout.println();
        break;
      case 7: 
        this._stdout.println();
        procLoad(paramCommand.COMMAND);
        this._stdout.println();
        break;
      case 2: 
        this._stdout.println();
        if ((!"OFF".equalsIgnoreCase(this.autotrace_type)) && (("ALL".equalsIgnoreCase(this.autotrace_name)) || ("EVENT".equalsIgnoreCase(this.autotrace_name)))) {
          localDBRowCache3 = getSessionWait();
        }
        if ((!"OFF".equalsIgnoreCase(this.autotrace_type)) && (("ALL".equalsIgnoreCase(this.autotrace_name)) || ("STATISTICS".equalsIgnoreCase(this.autotrace_name)) || ("STATS".equalsIgnoreCase(this.autotrace_name)))) {
          localDBRowCache1 = getSessionStats();
        }
        l1 = System.currentTimeMillis();
        procCross(paramCommand.COMMAND);
        l2 = System.currentTimeMillis();
        if (this.timing) {
          this._stdout.println("Execute time: " + DBOperation.getElapsed(l2 - l1));
        }
        if ((!"OFF".equalsIgnoreCase(this.autotrace_type)) && (("ALL".equalsIgnoreCase(this.autotrace_name)) || ("STATISTICS".equalsIgnoreCase(this.autotrace_name)) || ("STATS".equalsIgnoreCase(this.autotrace_name))))
        {
          localDBRowCache2 = getSessionStats();
          printSessionStats(localDBRowCache1, localDBRowCache2);
          localDBRowCache1 = null;
          localDBRowCache2 = null;
        }
        if ((!"OFF".equalsIgnoreCase(this.autotrace_type)) && (("ALL".equalsIgnoreCase(this.autotrace_name)) || ("EVENT".equalsIgnoreCase(this.autotrace_name))))
        {
          localDBRowCache4 = getSessionWait();
          printSessionWaits(localDBRowCache3, localDBRowCache4);
          localDBRowCache3 = null;
          localDBRowCache4 = null;
        }
        if ((paramCommand.TYPE1 != 13) && (paramCommand.TYPE1 != 2) && (!"OFF".equalsIgnoreCase(this.autotrace_type)) && (("ALL".equalsIgnoreCase(this.autotrace_name)) || ("EXPLAIN".equalsIgnoreCase(this.autotrace_name)) || ("EXP".equalsIgnoreCase(this.autotrace_name))))
        {
          DBRowCache localDBRowCache6 = getExplainPlan(paramCommand.COMMAND);
          if (localDBRowCache6 != null)
          {
            this._stdout.println();
            this._stdout.println("Execute Plan");
            showDBRowCache(localDBRowCache6, true);
          }
        }
        this._stdout.println();
      }
      break;
    case 17: 
      int k = getDBCommandID(paramCommand.COMMAND);
      switch (k)
      {
      case 2: 
        this._stdout.println();
        l1 = System.currentTimeMillis();
        procSource(paramCommand.COMMAND);
        l2 = System.currentTimeMillis();
        if (this.timing)
        {
          this._stdout.println();
          this._stdout.println();
          this._stdout.println("Execute time: " + DBOperation.getElapsed(l2 - l1));
        }
        this._stdout.println();
        break;
      case 1: 
      case 3: 
        this._stdout.println();
        l1 = System.currentTimeMillis();
        procDescribe(paramCommand.COMMAND);
        l2 = System.currentTimeMillis();
        if (this.timing)
        {
          this._stdout.println();
          this._stdout.println("Execute time: " + DBOperation.getElapsed(l2 - l1));
        }
        this._stdout.println();
        break;
      case 0: 
        this._stdout.println();
        l1 = System.currentTimeMillis();
        procShow(paramCommand.COMMAND);
        l2 = System.currentTimeMillis();
        if (this.timing)
        {
          this._stdout.println();
          this._stdout.println("Execute time: " + DBOperation.getElapsed(l2 - l1));
        }
        this._stdout.println();
        break;
      case 4: 
        this._stdout.println();
        l1 = System.currentTimeMillis();
        procList(paramCommand.COMMAND);
        l2 = System.currentTimeMillis();
        if (this.timing)
        {
          this._stdout.println();
          this._stdout.println("Execute time: " + DBOperation.getElapsed(l2 - l1));
        }
        this._stdout.println();
        break;
      case 5: 
        this._stdout.println();
        procDepend(paramCommand.COMMAND);
        this._stdout.println();
        break;
      case 6: 
        this._stdout.println();
        l1 = System.currentTimeMillis();
        procOraFunction(paramCommand.COMMAND);
        l2 = System.currentTimeMillis();
        if (this.timing) {
          this._stdout.println("Execute time: " + DBOperation.getElapsed(l2 - l1));
        }
        this._stdout.println();
        break;
      case 7: 
        if (procRun1(paramCommand.COMMAND)) {
          return false;
        }
        break;
      case 8: 
        procHost(paramCommand.COMMAND);
      }
      break;
    case 5: 
      int m = getSingleID(paramCommand.COMMAND);
      switch (m)
      {
      case 0: 
      case 8: 
        procConnect(paramCommand.COMMAND);
        break;
      case 6: 
        procDisconnect(paramCommand.COMMAND);
        break;
      case 1: 
        procDebugLevel(paramCommand.COMMAND);
        break;
      case 30: 
        procScanLimit(paramCommand.COMMAND);
        break;
      case 31: 
        procTunesort(paramCommand.COMMAND);
        break;
      case 17: 
        procEcho(paramCommand.COMMAND);
        break;
      case 2: 
        procPageSize(paramCommand.COMMAND);
        break;
      case 3: 
        procHeading(paramCommand.COMMAND);
        break;
      case 20: 
        procTermout(paramCommand.COMMAND);
        break;
      case 4: 
        procDelimiter(paramCommand.COMMAND);
        break;
      case 5: 
        procSetRecord(paramCommand.COMMAND);
        break;
      case 7: 
        procLoadTNS(paramCommand.COMMAND);
        break;
      case 9: 
        procVariable(paramCommand.COMMAND);
        break;
      case 10: 
        procUnvariable(paramCommand.COMMAND);
        break;
      case 11: 
        procPrint(paramCommand.COMMAND);
        break;
      case 12: 
      case 14: 
        procAutotrace(paramCommand.COMMAND);
        break;
      case 13: 
        procTiming(paramCommand.COMMAND);
        break;
      case 19: 
        procDriver(paramCommand.COMMAND);
        break;
      case 15: 
        procAutocommit(paramCommand.COMMAND);
        break;
      case 36: 
        procQueryOnly(paramCommand.COMMAND);
        break;
      case 16: 
        procFetchSize(paramCommand.COMMAND);
        break;
      case 18: 
        procDefine(paramCommand.COMMAND);
        break;
      case 21: 
        procSQLSet(paramCommand.COMMAND);
        break;
      case 22: 
        procSpoolAppend(paramCommand.COMMAND);
        break;
      case 24: 
        procSpool(paramCommand.COMMAND);
        break;
      case 25: 
        procRead(paramCommand.COMMAND);
        break;
      case 26: 
        procHelp(paramCommand.COMMAND);
        break;
      case 23: 
        procSpoolOff(paramCommand.COMMAND);
        break;
      case 27: 
        procListCommand(paramCommand.COMMAND);
        break;
      case 33: 
        procBUFFERADD(paramCommand.COMMAND);
        break;
      case 34: 
        procBUFFERLIST(paramCommand.COMMAND);
        break;
      case 35: 
        procBUFFERRESET(paramCommand.COMMAND);
        break;
      case 32: 
        procEncoding(paramCommand.COMMAND);
        break;
      case 29: 
        procLocale(paramCommand.COMMAND);
        break;
      case 28: 
        procReadonly(paramCommand.COMMAND);
        break;
      case 37: 
        procOLHash(paramCommand.COMMAND);
        break;
      case 38: 
        procOLDrop(paramCommand.COMMAND);
        break;
      case 39: 
        procOLShift(paramCommand.COMMAND);
        break;
      case 40: 
        procOLShow(paramCommand.COMMAND);
        break;
      case 41: 
        procOLMove(paramCommand.COMMAND);
        break;
      case 42: 
        procOLList(paramCommand.COMMAND);
        break;
      case 43: 
        procOLSQL(paramCommand.COMMAND);
        break;
      case 44: 
        procOLRename(paramCommand.COMMAND);
        break;
      case 45: 
        procOL(paramCommand.COMMAND);
      }
      break;
    }
    return true;
  }
  
  private void stopConnectionTest()
  {
    for (int i = 0; i < this.check_oranet.length; i++) {
      if (this.check_oranet[i] != null) {
        this.check_oranet[i].stopCheck();
      }
    }
  }
  
  private void startConnectionTest(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[0]).size();
    String str1 = skipWord(paramString, i);
    String str2 = "";
    String str3 = "";
    String str4 = "";
    str1 = str1.trim();
    Properties localProperties = DBConnection.getProperties("ORACLE");
    String[] arrayOfString = TextUtils.toStringArray(TextUtils.getWords(str1));
    this._stdout.println("Start Ora*Net Checker ......!");
    if (arrayOfString.length == 3)
    {
      if (("AS".equalsIgnoreCase(arrayOfString[1])) && (("SYSDBA".equalsIgnoreCase(arrayOfString[2])) || ("SYSOPER".equalsIgnoreCase(arrayOfString[2])))) {
        localProperties.setProperty("internal_logon", arrayOfString[2].toLowerCase());
      }
      str1 = arrayOfString[0];
    }
    int j = -1;
    j = str1.indexOf("@");
    if (j == -1)
    {
      str2 = str1;
      str4 = "";
    }
    else
    {
      str2 = str1.substring(0, j);
      str4 = str1.substring(j + 1);
    }
    j = str2.indexOf("/");
    if (j == -1) {
      try
      {
        str3 = this._stdin.readPassword();
        str2 = str2 + "/" + str3.trim();
      }
      catch (Exception localException) {}
    }
    if ((str4.length() > 0) && (this.tnsnames.exists(str4)) && (this.tnsnames.getValue(str4) != null)) {
      str4 = (String)this.tnsnames.getValue(str4);
    }
    for (int k = 0; k < this.check_oranet.length; k++)
    {
      if (this.check_oranet[k] != null) {
        this.check_oranet[k].stopCheck();
      }
      this.check_oranet[k] = new CheckNet(str2 + "@" + str4);
      this.check_oranet[k].start();
    }
  }
  
  private void procConnect(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[0]).size();
    Object localObject1 = skipWord(paramString, i);
    Object localObject2 = "";
    String str1 = "";
    String str2 = "";
    localObject1 = ((String)localObject1).trim();
    Properties localProperties = DBConnection.getProperties("ORACLE");
    String[] arrayOfString = TextUtils.toStringArray(TextUtils.getWords((String)localObject1));
    if (arrayOfString.length == 3)
    {
      if (("AS".equalsIgnoreCase(arrayOfString[1])) && (("SYSDBA".equalsIgnoreCase(arrayOfString[2])) || ("SYSOPER".equalsIgnoreCase(arrayOfString[2])))) {
        localProperties.setProperty("internal_logon", arrayOfString[2].toLowerCase());
      }
      localObject1 = arrayOfString[0];
    }
    int j = -1;
    j = ((String)localObject1).indexOf("@");
    if (j == -1)
    {
      localObject2 = localObject1;
      str2 = "";
    }
    else
    {
      localObject2 = ((String)localObject1).substring(0, j);
      str2 = ((String)localObject1).substring(j + 1);
    }
    localObject1 = localObject2;
    j = ((String)localObject1).indexOf("/");
    if (j == -1)
    {
      try
      {
        str1 = this._stdin.readPassword();
      }
      catch (Exception localException) {}
    }
    else
    {
      localObject2 = ((String)localObject1).substring(0, j);
      str1 = ((String)localObject1).substring(j + 1);
    }
    if ((str2.length() > 0) && (this.tnsnames.exists(str2)) && (this.tnsnames.getValue(str2) != null)) {
      str2 = (String)this.tnsnames.getValue(str2);
    }
    if (getDebugLevel() > 0)
    {
      this._stdout.println("==================== TNS Name ====================");
      this._stdout.println((String)localObject2 + "@" + str2);
      this._stdout.println("==================================================");
      this._stdout.println();
    }
    try
    {
      try
      {
        if (this.database != null)
        {
          prepareDescSQL(false);
          prepareTraceSQL(false);
          this.database.close();
        }
      }
      catch (SQLException localSQLException1)
      {
        this._stdout.print(localSQLException1);
      }
      if (this.oracle_driver.equalsIgnoreCase("THIN")) {
        this.database = DBConnection.getConnection("ORACLE", (String)localObject2 + "/" + str1 + "@" + str2, localProperties);
      } else if (this.oracle_driver.equalsIgnoreCase("OCI")) {
        this.database = DBConnection.getConnection("ORAOCI", (String)localObject2 + "/" + str1 + "@" + str2, localProperties);
      } else {
        this.database = DBConnection.getConnection("DDORA", str2, (String)localObject2, str1, localProperties);
      }
      this.database.setAutoCommit(false);
      this.autocommit = this.database.getAutoCommit();
      this._stdout.println("Database connected.");
    }
    catch (SQLException localSQLException2)
    {
      this._stdout.print(localSQLException2);
    }
    try
    {
      prepareDescSQL(isConnected());
    }
    catch (SQLException localSQLException3)
    {
      this._stdout.print(localSQLException3);
    }
    try
    {
      prepareTraceSQL(isConnected());
    }
    catch (SQLException localSQLException4)
    {
      this._stdout.print(localSQLException4);
    }
  }
  
  private void procDriver(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[12]).size();
    String str = skipWord(paramString, i);
    str = str.trim();
    if ((!str.equalsIgnoreCase("THIN")) && (!str.equalsIgnoreCase("OCI")) && (!str.equalsIgnoreCase("DATADIRECT")))
    {
      this._stdout.println("Usage: SET DRIVER { THIN | OCI | DATADIRECT }");
      return;
    }
    this.oracle_driver = str;
    this._stdout.println("Oracle driver set to : " + str);
  }
  
  private void procAutotrace(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[12]).size();
    String str = skipWord(paramString, i);
    String[] arrayOfString = TextUtils.toStringArray(TextUtils.getWords(str));
    if (arrayOfString.length == 0)
    {
      this._stdout.println("Usage: SET AUTOTRACE {ON | OFF | TRACE} [STATISTICS]");
      return;
    }
    if ((!"ON".equalsIgnoreCase(arrayOfString[0])) && (!"OFF".equalsIgnoreCase(arrayOfString[0])) && (!"TRACE".equalsIgnoreCase(arrayOfString[0])))
    {
      this._stdout.println("Usage: SET AUTOTRACE {ON | OFF | TRACE} [STATISTICS]");
      return;
    }
    this.autotrace_type = arrayOfString[0];
    if (arrayOfString.length > 1) {
      this.autotrace_name = arrayOfString[1];
    } else {
      this.autotrace_name = "ALL";
    }
    this._stdout.setAutotrace(this.autotrace_type.equalsIgnoreCase("TRACE"));
    this._stdout.println("Autotrace set to : " + str);
  }
  
  private void procDebugLevel(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[1]).size();
    String str = skipWord(paramString, i);
    str = str.trim();
    int j = getint(str, 0);
    setDebugLevel(j);
    this._stdout.println("Debug level set to : " + getDebugLevel());
  }
  
  private void procScanLimit(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[30]).size();
    String str = skipWord(paramString, i);
    str = str.trim();
    int j = getint(str, 0);
    if (j > 0)
    {
      if (j < 128) {
        j = 128;
      }
      this.scan_limit = j;
    }
    this._stdout.println("Scan Limit set to : " + this.scan_limit);
  }
  
  private void procTunesort(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[31]).size();
    String str = skipWord(paramString, i);
    str = str.trim();
    int j = getint(str, 10);
    if (j < 1) {
      j = 1;
    }
    if (j > 500) {
      j = 500;
    }
    if (!isConnected())
    {
      this._stdout.println("Not connected to database!");
      return;
    }
    try
    {
      SQLStatement localSQLStatement = null;
      localSQLStatement = prepareStatement(this.database, "ALTER SESSION SET SORT_AREA_SIZE=" + j * 1048576, this.sysvariable);
      localSQLStatement.stmt.execute();
      localSQLStatement.close();
      localSQLStatement = prepareStatement(this.database, "ALTER SESSION SET SORT_AREA_RETAINED_SIZE=" + j * 1048576, this.sysvariable);
      localSQLStatement.stmt.execute();
      localSQLStatement.close();
      localSQLStatement = prepareStatement(this.database, "ALTER SESSION SET SORT_MULTIBLOCK_READ_COUNT=128", this.sysvariable);
      localSQLStatement.stmt.execute();
      localSQLStatement.close();
      this._stdout.println("Command completed.");
    }
    catch (SQLException localSQLException)
    {
      this._stdout.print(localSQLException);
    }
  }
  
  private void procPageSize(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[2]).size();
    String str = skipWord(paramString, i);
    str = str.trim();
    int j = getint(str, 14);
    this._stdout.setPagesize(j);
    this._stdout.println("Page size set to : " + this._stdout.getPagesize());
  }
  
  private void procFetchSize(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[16]).size();
    String str = skipWord(paramString, i);
    str = str.trim();
    int j = getint(str, 200);
    setFetchSize(j);
  }
  
  private void procTiming(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[13]).size();
    String str = skipWord(paramString, i);
    str = str.trim();
    this.timing = "ON".equalsIgnoreCase(str);
    this._stdout.println("Timing set to : " + (this.timing ? "ON" : "OFF"));
  }
  
  private void procSpoolAppend(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[22]).size();
    String str1 = skipWord(paramString, i);
    if (str1.trim().length() == 0)
    {
      this._stdout.println("Usage: SPOOL [APPEND] file");
      return;
    }
    String str2 = this.sysvariable.parseString(str1.trim());
    try
    {
      FileOutputStream localFileOutputStream = new FileOutputStream(str2, true);
      if (this._stdout.getLogFile() != null) {
        this._stdout.getLogFile().close();
      }
      this._stdout.setLogFile(new OutputCommandLog(this, localFileOutputStream));
    }
    catch (IOException localIOException)
    {
      this._stdout.print(localIOException);
    }
  }
  
  private void procSpool(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[24]).size();
    String str1 = skipWord(paramString, i);
    if (str1.trim().length() == 0)
    {
      this._stdout.println("Usage: SPOOL [APPEND] file");
      return;
    }
    String str2 = this.sysvariable.parseString(str1.trim());
    try
    {
      FileOutputStream localFileOutputStream = new FileOutputStream(str2);
      if (this._stdout.getLogFile() != null) {
        this._stdout.getLogFile().close();
      }
      this._stdout.setLogFile(new OutputCommandLog(this, localFileOutputStream));
    }
    catch (IOException localIOException)
    {
      this._stdout.print(localIOException);
    }
  }
  
  private void procRead(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[25]).size();
    String str1 = skipWord(paramString, i);
    str1 = str1.trim();
    String[] arrayOfString = TextUtils.toStringArray(TextUtils.getWords(str1));
    if (arrayOfString.length < 2)
    {
      this._stdout.println("Usage: READ varname filename");
      return;
    }
    String str2 = arrayOfString[0];
    String str3 = str1.substring(str2.length()).trim();
    if (!this.sysvariable.exists(str2))
    {
      this._stdout.println("Variable " + str2 + " not defined!");
      return;
    }
    try
    {
      FileReader localFileReader = new FileReader(this.sysvariable.parseString(str3));
      char[] arrayOfChar = new char[65536];
      int j = localFileReader.read(arrayOfChar);
      try
      {
        this.sysvariable.setValue(str2, String.valueOf(arrayOfChar, 0, j));
      }
      catch (Exception localException)
      {
        this._stdout.print(localException);
      }
      localFileReader.close();
    }
    catch (IOException localIOException)
    {
      this._stdout.print(localIOException);
    }
  }
  
  private void procHelp(String paramString)
  {
    this._stdout.println();
    this._stdout.println("Usage: HELP");
    this._stdout.println();
    this._stdout.println(" CONNECT SHOW SET DESCRIBE SOURCE DISCONNECT LOADTNS LIST");
    this._stdout.println(" DEPEND VAR UNVAR PRINT DEFINE SQLSET SPOOL START READ ");
    this._stdout.println(" @ @@ LOB LOBEXP LOBIMP LOBLEN UNLOAD");
    this._stdout.println();
  }
  
  private void procListCommand(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[27]).size();
    String str = skipWord(paramString, i);
    String[] arrayOfString = TextUtils.toStringArray(TextUtils.getWords(str));
    int j = 1;
    int k = 0;
    if (arrayOfString.length > 0)
    {
      j = getint(arrayOfString[0], 1);
      if (arrayOfString.length > 1) {
        k = getint(arrayOfString[1], 0);
      }
    }
    if ((this.lastcommand == null) || (this.lastcommand.COMMAND == null))
    {
      this._stdout.println("No command in buffer.");
    }
    else
    {
      Vector localVector = TextUtils.getLines(this.lastcommand.COMMAND);
      if ((j > localVector.size()) || (j < 1) || (k < 0))
      {
        this._stdout.println("Invalid line number.");
        return;
      }
      this._stdout.println();
      for (int m = j - 1; (m < localVector.size()) && ((k == 0) || (m < j - 1 + k)); m++)
      {
        this._stdout.print(rpad(m + 1 + " ", 5));
        this._stdout.println((String)localVector.elementAt(m));
      }
      this._stdout.println();
    }
  }
  
  private void procHost(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getDBCommand()[8]).size();
    String str = skipWord(paramString, i);
    str = this.sysvariable.parseString(str.trim());
    if (str.length() > 0) {
      try
      {
        host(str);
      }
      catch (IOException localIOException)
      {
        this._stdout.print(localIOException);
      }
    }
  }
  
  private boolean procRun2(String paramString1, String paramString2)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[7]).size();
    String str1 = skipWord(paramString1, i);
    if (str1.trim().length() == 0)
    {
      this._stdout.println("Usage: @[@] file");
      return false;
    }
    String str2 = this.sysvariable.parseString(str1.trim());
    try
    {
      if ((paramString2 != null) && (paramString2.length() > 0)) {
        str2 = paramString2 + JavaVM.FILE_SEPERATOR + str2;
      }
      File localFile = new File(str2);
      FileInputStream localFileInputStream = new FileInputStream(localFile);
      InputCommandReader localInputCommandReader = new InputCommandReader(localFileInputStream);
      localInputCommandReader.setWorkingDir(localFile.getParent());
      Command localCommand = run(localInputCommandReader);
      localInputCommandReader.close();
      return localCommand.COMMAND != null;
    }
    catch (IOException localIOException)
    {
      this._stdout.print(localIOException);
    }
    return false;
  }
  
  private boolean procRun1(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[7]).size();
    String str1 = skipWord(paramString, i);
    if (str1.trim().length() == 0)
    {
      this._stdout.println("Usage: @[@] file");
      return false;
    }
    String str2 = this.sysvariable.parseString(str1.trim());
    try
    {
      File localFile = new File(str2);
      FileInputStream localFileInputStream = new FileInputStream(localFile);
      InputCommandReader localInputCommandReader = new InputCommandReader(localFileInputStream);
      localInputCommandReader.setWorkingDir(localFile.getParent());
      Command localCommand = run(localInputCommandReader);
      localInputCommandReader.close();
      return localCommand.COMMAND != null;
    }
    catch (IOException localIOException)
    {
      this._stdout.print(localIOException);
    }
    return false;
  }
  
  private void procSpoolOff(String paramString)
  {
    if (this._stdout.getLogFile() != null) {
      this._stdout.getLogFile().close();
    }
    this._stdout.setLogFile(null);
  }
  
  private void procDefine(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[18]).size();
    String str1 = skipWord(paramString, i);
    int j = str1.indexOf("=");
    if (j == -1)
    {
      this._stdout.println("Usage:");
      this._stdout.println("  DEFINE variable=value");
      this._stdout.println("  SET    PAGESIZE   pagesize");
      this._stdout.println("  SET    DEBUGLEVEL debuglevel");
      this._stdout.println("  SET    AUTOTRACE  {OFF|ON|TRACE} [EXP|EVENT|STATS]");
      this._stdout.println("  SET    HEADING    {OFF|ON}");
      this._stdout.println("  SET    DELIMITER  delimiter");
      this._stdout.println("  SET    TIMING     {ON|OFF}");
      this._stdout.println("  SET    LOCALE     locale");
      this._stdout.println("  SET    READONLY   {TRUE|FALSE}");
      this._stdout.println("LOCALE: ENGLISH FRENCH GERMAN ITALIAN JAPANESE KOREAN CHINESE");
      this._stdout.println("        SMPLIFIED_CHINESE TRADITIONAL_CHINESE FRANCE GERMANY");
      this._stdout.println("        ITALY JAPAN KOREA CHINA PRC TAIWAN UK US CANADA");
      return;
    }
    String str2 = str1.substring(0, j);
    String str3 = str1.substring(j + 1);
    if (str2.trim().length() == 0)
    {
      this._stdout.println("Usage:");
      this._stdout.println("  DEFINE variable=value");
      this._stdout.println("  SET    PAGESIZE   pagesize");
      this._stdout.println("  SET    DEBUGLEVEL debuglevel");
      this._stdout.println("  SET    AUTOTRACE  {OFF|ON|TRACE} [EXP|EVENT|STATS]");
      this._stdout.println("  SET    HEADING    {OFF|ON}");
      this._stdout.println("  SET    DELIMITER  delimiter");
      this._stdout.println("  SET    TIMING     {ON|OFF}");
      this._stdout.println("  SET    LOCALE     locale");
      this._stdout.println("  SET    READONLY   {TRUE|FALSE}");
      this._stdout.println("LOCALE: ENGLISH FRENCH GERMAN ITALIAN JAPANESE KOREAN CHINESE");
      this._stdout.println("        SMPLIFIED_CHINESE TRADITIONAL_CHINESE FRANCE GERMANY");
      this._stdout.println("        ITALY JAPAN KOREA CHINA PRC TAIWAN UK US CANADA");
      return;
    }
    if (!this.sysvariable.exists(str2.trim())) {
      this.sysvariable.add(str2.trim(), 12);
    }
    try
    {
      if (str3.length() == 0) {
        this.sysvariable.setValue(str2, null);
      } else {
        this.sysvariable.setValue(str2, str3);
      }
    }
    catch (Exception localException)
    {
      this._stdout.print("Invalid format : ");
      this._stdout.println(str3);
    }
  }
  
  private void procSQLSet(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[18]).size();
    String str1 = skipWord(paramString, i);
    int j = str1.indexOf("=");
    if (j == -1)
    {
      this._stdout.println("Usage: SQLSET variable=query");
      return;
    }
    String str2 = str1.substring(0, j);
    String str3 = str1.substring(j + 1);
    if (str2.trim().length() == 0)
    {
      this._stdout.println("Usage: SQLSET variable=query");
      return;
    }
    if (!this.sysvariable.exists(str2.trim()))
    {
      this._stdout.println("Variable " + str2 + " not declared.");
      return;
    }
    if (!isConnected())
    {
      this._stdout.println("Database not connected.");
      return;
    }
    try
    {
      DBRowCache localDBRowCache = executeQuery(this.database, str3, this.sysvariable, 1000);
      if ((localDBRowCache.getRowCount() == 1) && (localDBRowCache.getColumnCount() == 1)) {
        try
        {
          this.sysvariable.setValue(str2, localDBRowCache.getItem(1, 1));
        }
        catch (Exception localException)
        {
          this._stdout.print("Invalid format : ");
          this._stdout.println(str3);
        }
      } else {
        this._stdout.println("Query does not return one row and one column.");
      }
    }
    catch (SQLException localSQLException)
    {
      this._stdout.print(localSQLException);
    }
  }
  
  private void procQueryOnly(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[36]).size();
    String str = skipWord(paramString, i);
    str = str.trim();
    if (str.length() == 0)
    {
      if (this._cmdtype != null) {
        this._stdout.println("QUERYONLY : " + (this._cmdtype.getQueryOnly() ? "TRUE" : "FALSE"));
      }
      return;
    }
    this.autocommit = "TRUE".equalsIgnoreCase(str);
    if (this._cmdtype != null) {
      this._cmdtype.setQueryOnly(this.autocommit);
    }
  }
  
  private void procAutocommit(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[15]).size();
    String str = skipWord(paramString, i);
    str = str.trim();
    if (!isConnected())
    {
      this._stdout.println("Database not connected.");
      return;
    }
    if (str.length() == 0)
    {
      try
      {
        this.autocommit = this.database.getAutoCommit();
        this._stdout.println("Autocommit : " + (this.autocommit ? "ON" : "OFF"));
      }
      catch (SQLException localSQLException1)
      {
        this._stdout.print(localSQLException1);
      }
      return;
    }
    this.autocommit = "ON".equalsIgnoreCase(str);
    try
    {
      this.database.setAutoCommit(this.autocommit);
      this.autocommit = this.database.getAutoCommit();
    }
    catch (SQLException localSQLException2)
    {
      this._stdout.print(localSQLException2);
    }
  }
  
  private void procTermout(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[3]).size();
    String str = skipWord(paramString, i);
    str = str.trim();
    boolean bool = "ON".equalsIgnoreCase(str);
    this._stdout.setTermout(bool);
    setTermout(bool);
  }
  
  private void procLocale(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[29]).size();
    String str = skipWord(paramString, i);
    str = str.trim();
    if (str.length() > 0) {
      DBConnection.setLocale(str);
    }
  }
  
  private void procEncoding(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[32]).size();
    String str = skipWord(paramString, i);
    str = str.trim();
    if (str.length() > 0) {
      DBConnection.setEncoding(str);
    }
  }
  
  private void procReadonly(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[3]).size();
    String str = skipWord(paramString, i);
    str = str.trim();
    if (isConnected()) {
      try
      {
        this.database.setReadOnly("TRUE".equalsIgnoreCase(str));
      }
      catch (SQLException localSQLException)
      {
        this._stdout.print(localSQLException);
      }
    }
  }
  
  private void procHeading(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[3]).size();
    String str = skipWord(paramString, i);
    str = str.trim();
    boolean bool = "ON".equalsIgnoreCase(str);
    this._stdout.setHeading(bool);
  }
  
  private void procEcho(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[3]).size();
    String str = skipWord(paramString, i);
    str = str.trim();
    boolean bool = "ON".equalsIgnoreCase(str);
    setEcho(bool);
  }
  
  private void procDelimiter(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[4]).size();
    String str = skipWord(paramString, i);
    str = str.trim();
    if ("TAB".equalsIgnoreCase(str)) {
      str = "\t";
    }
    this._stdout.setSeperator(str.length() == 0 ? " " : str);
    if (str.length() == 0) {
      this._stdout.println("Delimiter set to : SPACE");
    } else if (str.equals("\t")) {
      this._stdout.println("Delimiter set to : TAB");
    } else {
      this._stdout.println("Delimiter set to : " + str);
    }
  }
  
  private void procSetRecord(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[5]).size();
    String str = skipWord(paramString, i);
    str = str.trim();
    this._stdout.setRecord(str);
  }
  
  private void procSource(String paramString)
  {
    if (!isConnected())
    {
      this._stdout.println("Database not connected!");
      return;
    }
    int i = TextUtils.getWords(this._cmdtype.getDBCommand()[2]).size();
    String str1 = skipWord(paramString, i);
    str1 = str1.trim();
    String[] arrayOfString = TextUtils.toStringArray(TextUtils.getWords(str1, new String[] { "." }));
    if (arrayOfString.length == 0)
    {
      this._stdout.println("Usage: SOURCE user.pattern");
      return;
    }
    VariableTable localVariableTable = new VariableTable();
    localVariableTable.add("P_OWNER", 12);
    localVariableTable.add("P_NAME", 12);
    localVariableTable.add("P_TYPE", 12);
    if ((arrayOfString.length == 1) || (arrayOfString.length == 2))
    {
      if (arrayOfString.length == 1) {
        localVariableTable.setValue("P_NAME", arrayOfString[0].toUpperCase());
      }
      if (arrayOfString.length == 2)
      {
        localVariableTable.setValue("P_OWNER", arrayOfString[0].toUpperCase());
        localVariableTable.setValue("P_NAME", arrayOfString[1].toUpperCase());
      }
    }
    DBRowCache localDBRowCache1 = null;
    DBRowCache localDBRowCache2 = null;
    if (arrayOfString.length == 1) {
      try
      {
        localDBRowCache2 = executeQuery(this.database, "SELECT /* AnySQL */ USER OWNER,OBJECT_NAME,OBJECT_TYPE FROM USER_OBJECTS \n  WHERE OBJECT_NAME=:P_NAME AND \n  OBJECT_TYPE IN ('VIEW','PACKAGE','PACKAGE BODY','PROCEDURE',\n  'FUNCTION','TRIGGER','TYPE','TYPE BODY','MATERIALIZED VIEW','INDEX','TABLE') \n  ORDER BY OBJECT_TYPE", localVariableTable, 10000);
      }
      catch (SQLException localSQLException1)
      {
        this._stdout.print(localSQLException1);
      }
    }
    if (arrayOfString.length == 2) {
      try
      {
        localDBRowCache2 = executeQuery(this.database, "SELECT /* AnySQL */ OWNER,OBJECT_NAME,OBJECT_TYPE FROM ALL_OBJECTS \n  WHERE OWNER=:P_OWNER AND OBJECT_NAME=:P_NAME AND \n  OBJECT_TYPE IN ('VIEW','PACKAGE','PACKAGE BODY','PROCEDURE', \n  'FUNCTION','TRIGGER','TYPE','TYPE BODY','MATERIALIZED VIEW','INDEX','TABLE') \n  ORDER BY OBJECT_TYPE", localVariableTable, 10000);
      }
      catch (SQLException localSQLException2)
      {
        this._stdout.print(localSQLException2);
      }
    }
    if ((localDBRowCache2 == null) || (localDBRowCache2.getRowCount() == 0))
    {
      if (arrayOfString.length == 1) {
        try
        {
          localDBRowCache2 = executeQuery(this.database, "SELECT /* AnySQL */ OWNER,OBJECT_NAME,OBJECT_TYPE FROM ALL_OBJECTS \nWHERE (OWNER,OBJECT_NAME)  \n   IN (SELECT TABLE_OWNER,TABLE_NAME FROM USER_SYNONYMS \n       WHERE SYNONYM_NAME=:P_NAME AND \n       DB_LINK IS NULL) \n  AND OBJECT_TYPE IN ('VIEW','PACKAGE','PACKAGE BODY','PROCEDURE',\n      'FUNCTION','TRIGGER','TYPE','TYPE BODY','MATERIALIZED VIEW','INDEX','TABLE') \n  ORDER BY OBJECT_TYPE", localVariableTable, 10000);
        }
        catch (SQLException localSQLException3)
        {
          this._stdout.print(localSQLException3);
        }
      }
      if (arrayOfString.length == 2) {
        try
        {
          localDBRowCache2 = executeQuery(this.database, "SELECT /* AnySQL */ OWNER,OBJECT_NAME,OBJECT_TYPE FROM ALL_OBJECTS \nWHERE (OWNER,OBJECT_NAME)  \n   IN (SELECT TABLE_OWNER,TABLE_NAME FROM ALL_SYNONYMS \n       WHERE OWNER = :P_OWNER AND SYNONYM_NAME=:P_NAME AND \n       DB_LINK IS NULL) \n  AND OBJECT_TYPE IN ('VIEW','PACKAGE','PACKAGE BODY','PROCEDURE',\n  'FUNCTION','TRIGGER','TYPE','TYPE BODY','MATERIALIZED VIEW','INDEX','TABLE') \n  ORDER BY OBJECT_TYPE", localVariableTable, 10000);
        }
        catch (SQLException localSQLException4)
        {
          this._stdout.print(localSQLException4);
        }
      }
    }
    if (((localDBRowCache2 == null) || (localDBRowCache2.getRowCount() == 0)) && (arrayOfString.length == 1)) {
      try
      {
        localDBRowCache2 = executeQuery(this.database, "SELECT /* AnySQL */ OWNER,OBJECT_NAME,OBJECT_TYPE FROM ALL_OBJECTS \nWHERE (OWNER,OBJECT_NAME)  \n   IN (SELECT TABLE_OWNER,TABLE_NAME FROM ALL_SYNONYMS \n       WHERE OWNER = 'PUBLIC' AND SYNONYM_NAME=:P_NAME AND \n       DB_LINK IS NULL) \n  AND OBJECT_TYPE IN ('VIEW','PACKAGE','PACKAGE BODY','PROCEDURE',\n      'FUNCTION','TRIGGER','TYPE','TYPE BODY','MATERIALIZED VIEW','INDEX','TABLE') \n  ORDER BY OBJECT_TYPE", localVariableTable, 10000);
      }
      catch (SQLException localSQLException5)
      {
        this._stdout.print(localSQLException5);
      }
    }
    String str2;
    for (int j = localDBRowCache2.getRowCount(); j > 1; j--)
    {
      str2 = (String)localDBRowCache2.getItem(j, 1);
      String str3 = (String)localDBRowCache2.getItem(j, 3);
      if ((str2.equals("SYS")) && ((str3.equals("PACKAGE BODY")) || (str3.equals("TYPE BODY")))) {
        localDBRowCache2.deleteRow(j);
      }
    }
    if ((localDBRowCache2 == null) || (localDBRowCache2.getRowCount() == 0))
    {
      this._stdout.println("No source object founded!");
      return;
    }
    for (j = 1; j <= localDBRowCache2.getRowCount(); j++)
    {
      localVariableTable.setValue("P_OWNER", localDBRowCache2.getItem(j, 1));
      localVariableTable.setValue("P_NAME", localDBRowCache2.getItem(j, 2));
      localVariableTable.setValue("P_TYPE", localDBRowCache2.getItem(j, 3));
      str2 = (String)localDBRowCache2.getItem(j, 3);
      try
      {
        if (str2.equalsIgnoreCase("VIEW"))
        {
          localDBRowCache1 = executeQuery(this.database, "SELECT /* AnySQL */ \nDBMS_METADATA.GET_DDL('VIEW',:P_NAME,:P_OWNER) FROM DUAL", localVariableTable, 5000);
        }
        else if (str2.equalsIgnoreCase("MATERIALIZED VIEW"))
        {
          localDBRowCache1 = executeQuery(this.database, "SELECT /* AnySQL */ \nDBMS_METADATA.GET_DDL('MATERIALIZED_VIEW',:P_NAME,:P_OWNER) FROM DUAL", localVariableTable, 5000);
        }
        else if (str2.equalsIgnoreCase("TRIGGER"))
        {
          localDBRowCache1 = executeQuery(this.database, "SELECT /* AnySQL */ \nDBMS_METADATA.GET_DDL('TRIGGER',:P_NAME,:P_OWNER) FROM DUAL", localVariableTable, 5000);
        }
        else if (str2.equalsIgnoreCase("INDEX"))
        {
          localDBRowCache1 = executeQuery(this.database, "SELECT /* AnySQL */ \nDBMS_METADATA.GET_DDL('INDEX',:P_NAME,:P_OWNER) FROM DUAL", localVariableTable, 5000);
        }
        else if (str2.equalsIgnoreCase("TABLE"))
        {
          localDBRowCache1 = executeQuery(this.database, "SELECT /* AnySQL */ \nDBMS_METADATA.GET_DDL('TABLE',:P_NAME,:P_OWNER) FROM DUAL", localVariableTable, 5000);
        }
        else
        {
          localDBRowCache1 = executeQuery(this.database, "SELECT /* AnySQL */ TEXT FROM ALL_SOURCE \n WHERE OWNER=:P_OWNER AND NAME=:P_NAME AND TYPE=:P_TYPE \n ORDER BY LINE", localVariableTable, 10000);
          this._stdout.print("CREATE OR REPLACE ");
        }
      }
      catch (SQLException localSQLException6)
      {
        this._stdout.print(localSQLException6);
        continue;
      }
      if ((localDBRowCache1 != null) && (localDBRowCache1.getRowCount() > 0))
      {
        for (int k = 1; k <= localDBRowCache1.getRowCount(); k++) {
          this._stdout.println(removeNewLine((String)localDBRowCache1.getItem(k, 1)));
        }
        if (j < localDBRowCache2.getRowCount())
        {
          this._stdout.println();
          this._stdout.println();
        }
      }
      else
      {
        this._stdout.println("No source founded!");
      }
    }
  }
  
  private void prepareDescSQL(boolean paramBoolean)
    throws SQLException
  {
    if (paramBoolean)
    {
      if (this.desc_sqls[0] == null) {
        this.desc_sqls[0] = prepareStatement(this.database, "SELECT /* AnySQL D0 */  \n USER OWNER,OBJECT_NAME,OBJECT_TYPE FROM USER_OBJECTS \nWHERE OBJECT_NAME=:P_NAME AND \n  OBJECT_TYPE IN ('TABLE','VIEW','PACKAGE','PROCEDURE', \n'FUNCTION','CLUSTER')", this.sysvariable);
      }
      if (this.desc_sqls[1] == null) {
        this.desc_sqls[1] = prepareStatement(this.database, "SELECT /* AnySQL D1 */ \n OWNER,OBJECT_NAME,OBJECT_TYPE FROM ALL_OBJECTS \nWHERE UPPER(OWNER) = :P_OWNER AND OBJECT_NAME=:P_NAME AND \n  OBJECT_TYPE IN ('TABLE','VIEW','PACKAGE','PROCEDURE',\n'FUNCTION','CLUSTER')", this.sysvariable);
      }
      if (this.desc_sqls[2] == null) {
        this.desc_sqls[2] = prepareStatement(this.database, "SELECT /* AnySQL D2 */ O.OWNER,O.OBJECT_NAME,O.OBJECT_TYPE \n FROM  ALL_OBJECTS O \n WHERE (OWNER,OBJECT_NAME) \n   IN (SELECT TABLE_OWNER,TABLE_NAME FROM USER_SYNONYMS \n       WHERE SYNONYM_NAME=:P_NAME AND \n       DB_LINK IS NULL) \n   AND O.OBJECT_TYPE IN ('TABLE','VIEW','PACKAGE', \n      'PROCEDURE','FUNCTION','CLUSTER')", this.sysvariable);
      }
      if (this.desc_sqls[3] == null) {
        this.desc_sqls[3] = prepareStatement(this.database, "SELECT /* AnySQL D3 */ O.OWNER,O.OBJECT_NAME,O.OBJECT_TYPE \n FROM  ALL_OBJECTS O \n WHERE (OWNER,OBJECT_NAME)  \n   IN (SELECT TABLE_OWNER,TABLE_NAME FROM ALL_SYNONYMS \n       WHERE OWNER = :P_OWNER AND SYNONYM_NAME=:P_NAME AND \n       DB_LINK IS NULL) \n   AND O.OBJECT_TYPE IN ('TABLE','VIEW','PACKAGE', \n       'PROCEDURE','FUNCTION','CLUSTER')", this.sysvariable);
      }
      if (this.desc_sqls[4] == null) {
        this.desc_sqls[4] = prepareStatement(this.database, "SELECT /* AnySQL D4 */ O.OWNER,O.OBJECT_NAME,O.OBJECT_TYPE \n FROM  ALL_OBJECTS O \n WHERE (OWNER,OBJECT_NAME) \n   IN (SELECT TABLE_OWNER,TABLE_NAME FROM ALL_SYNONYMS \n       WHERE OWNER = 'PUBLIC' AND SYNONYM_NAME=:P_NAME AND \n       DB_LINK IS NULL) \n   AND O.OBJECT_TYPE IN ('TABLE','VIEW','PACKAGE', \n      'PROCEDURE','FUNCTION','CLUSTER')", this.sysvariable);
      }
      if (this.desc_sqls[5] == null) {
        this.desc_sqls[5] = prepareStatement(this.database, "select /* AnySQL D5 */ \n  COLUMN_ID NO#,COLUMN_NAME NAME, \n  DECODE(NULLABLE,'N','NOT NULL','') NULLABLE, \n  (case  \n     when data_type='CHAR' then data_type||'('||data_length||')' \n     when data_type='VARCHAR' then data_type||'('||data_length||')' \n     when data_type='VARCHAR2' then data_type||'('||data_length||')' \n     when data_type='NCHAR' then data_type||'('||data_length||')' \n     when data_type='NVARCHAR' then data_type||'('||data_length||')' \n     when data_type='NVARCHAR2' then data_type||'('||data_length||')' \n     when data_type='RAW' then data_type||'('||data_length||')' \n     when data_type='NUMBER' then \n\t    ( \n\t       case \n\t          when data_scale is null and data_precision is null then 'NUMBER' \n\t          when data_scale <> 0  then 'NUMBER('||NVL(DATA_PRECISION,38)||','||DATA_SCALE||')' \n             else 'NUMBER('||NVL(DATA_PRECISION,38)||')' \n\t       end \n\t    ) \n     else\n        ( case \n            when data_type_owner is not null then data_type_owner||'.'||data_type \n\t\t\t else data_type \n          end ) \n   end) TYPE --,(case when default_length>0 then 'Default' else null end) \"Default\"  \n   from all_tab_columns \n   where UPPER(owner)=:P_OWNER AND TABLE_NAME=:P_NAME \n   order by 1", this.sysvariable);
      }
      if (this.desc_sqls[6] == null) {
        this.desc_sqls[6] = prepareStatement(this.database, "SELECT /* AnySQL D6 */ \n   OBJECT_NAME||'('||NVL(OVERLOAD,-1)||')' NAME \n   ,RPAD(' ',2*NVL(DATA_LEVEL,0),' ')||NVL(NVL(ARGUMENT_NAME,DATA_TYPE),'@return') ARG,IN_OUT, \n  (case \n     when pls_type is not null then pls_type \n     when type_subname is not null then decode(package_name,type_name,'','.'||type_name)||type_subname \n\t  else data_type \n   end) TYPE --,(case when default_length>0 then 'Default' else null end) \"Default\" \n FROM ALL_ARGUMENTS \n WHERE UPPER(OWNER)=:P_OWNER AND PACKAGE_NAME=:P_NAME \n  ORDER BY 1,OVERLOAD,SEQUENCE,POSITION", this.sysvariable);
      }
      if (this.desc_sqls[7] == null) {
        this.desc_sqls[7] = prepareStatement(this.database, "SELECT /* AnySQL D7 */ \n   RPAD('  ',2*NVL(DATA_LEVEL,0),' ')||NVL(ARGUMENT_NAME,'@return') NAME,IN_OUT, \n  (case \n     when pls_type is not null then pls_type \n     when type_subname is not null then type_name||'.'||type_subname \n\t  else data_type \n   end) TYPE --,(case when default_length>0 then 'Default' else null end) \"Default\"\n FROM ALL_ARGUMENTS \n WHERE PACKAGE_NAME IS NULL AND UPPER(OWNER)=:P_OWNER \n   AND OBJECT_NAME=:P_NAME ORDER BY POSITION", this.sysvariable);
      }
      if (this.desc_sqls[8] == null) {
        this.desc_sqls[8] = prepareStatement(this.database, "SELECT  /* AnySQL */  /*+ RULE */ \n    DECODE(C.COLUMN_POSITION,1,I.INDEX_TYPE,'') TYPE, \n    DECODE(C.COLUMN_POSITION,1,I.UNIQUENESS,'') ISUNQ, \n    DECODE(C.COLUMN_POSITION,1,C.INDEX_NAME,'') INDEX_NAME, \n    C.COLUMN_POSITION NO#,C.COLUMN_NAME, C.DESCEND  \n  FROM ALL_IND_COLUMNS C, ALL_INDEXES I \n  WHERE C.INDEX_OWNER=I.OWNER AND C.INDEX_NAME=I.INDEX_NAME \n    AND I.TABLE_NAME=:P_NAME AND I.TABLE_OWNER=:P_OWNER \n  ORDER BY C.INDEX_NAME,C.COLUMN_POSITION \n", this.sysvariable);
      }
      if (this.desc_sqls[9] == null) {
        this.desc_sqls[9] = prepareStatement(this.database, "SELECT  /* AnySQL */  /*+ RULE */ \n    PARTITIONED,AVG_ROW_LEN,NUM_ROWS,BLOCKS,EMPTY_BLOCKS \n  FROM DBA_TABLES T  \n  WHERE T.TABLE_NAME=:P_NAME AND UPPER(T.OWNER)=:P_OWNER", this.sysvariable);
      }
    }
    else
    {
      for (int i = 0; i < this.desc_sqls.length; i++) {
        if (this.desc_sqls[i] != null) {
          this.desc_sqls[i].close();
        }
      }
      this.desc_sqls[0] = null;
      this.desc_sqls[1] = null;
      this.desc_sqls[2] = null;
      this.desc_sqls[3] = null;
      this.desc_sqls[4] = null;
      this.desc_sqls[5] = null;
      this.desc_sqls[6] = null;
      this.desc_sqls[7] = null;
      this.desc_sqls[8] = null;
      this.desc_sqls[9] = null;
    }
  }
  
  private void procDescribe(String paramString)
  {
    if (!isConnected())
    {
      this._stdout.println("Database not connected!");
      return;
    }
    int i = TextUtils.getWords(this._cmdtype.getDBCommand()[1]).size();
    String str1 = skipWord(paramString, i);
    str1 = str1.trim();
    String[] arrayOfString = TextUtils.toStringArray(TextUtils.getWords(str1, new String[] { "." }));
    VariableTable localVariableTable = new VariableTable();
    localVariableTable.add("P_OWNER", 12);
    localVariableTable.add("P_NAME", 12);
    localVariableTable.add("P_TYPE", 12);
    if ((arrayOfString.length == 1) || (arrayOfString.length == 2))
    {
      if (arrayOfString.length == 1) {
        localVariableTable.setValue("P_NAME", arrayOfString[0].toUpperCase());
      }
      if (arrayOfString.length == 2)
      {
        localVariableTable.setValue("P_OWNER", arrayOfString[0].toUpperCase());
        localVariableTable.setValue("P_NAME", arrayOfString[1].toUpperCase());
      }
    }
    DBRowCache localDBRowCache1 = null;
    DBRowCache localDBRowCache2 = null;
    if (arrayOfString.length == 1) {
      try
      {
        localDBRowCache2 = executeQuery(this.desc_sqls[0], localVariableTable, 5000);
      }
      catch (SQLException localSQLException1)
      {
        this._stdout.print(localSQLException1);
      }
    }
    if (arrayOfString.length == 2) {
      try
      {
        localDBRowCache2 = executeQuery(this.desc_sqls[1], localVariableTable, 5000);
      }
      catch (SQLException localSQLException2)
      {
        this._stdout.print(localSQLException2);
      }
    }
    if ((localDBRowCache2 == null) || (localDBRowCache2.getRowCount() == 0))
    {
      if (arrayOfString.length == 1) {
        try
        {
          localDBRowCache2 = executeQuery(this.desc_sqls[2], localVariableTable, 5000);
        }
        catch (SQLException localSQLException3)
        {
          this._stdout.print(localSQLException3);
        }
      }
      if (arrayOfString.length == 2) {
        try
        {
          localDBRowCache2 = executeQuery(this.desc_sqls[3], localVariableTable, 5000);
        }
        catch (SQLException localSQLException4)
        {
          this._stdout.print(localSQLException4);
        }
      }
    }
    if ((localDBRowCache2 == null) || (localDBRowCache2.getRowCount() == 0)) {
      try
      {
        localDBRowCache2 = executeQuery(this.desc_sqls[4], localVariableTable, 5000);
      }
      catch (SQLException localSQLException5)
      {
        this._stdout.print(localSQLException5);
      }
    }
    if ((localDBRowCache2 == null) || (localDBRowCache2.getRowCount() == 0))
    {
      this._stdout.println("Object not exists!");
      return;
    }
    for (int j = 1; j < 2; j++)
    {
      localDBRowCache2.getWidth(false);
      localVariableTable.setValue("P_OWNER", localDBRowCache2.getItem(j, 1));
      localVariableTable.setValue("P_NAME", localDBRowCache2.getItem(j, 2));
      localVariableTable.setValue("P_TYPE", localDBRowCache2.getItem(j, 3));
      String str2 = (String)localDBRowCache2.getItem(j, 3);
      try
      {
        if ((str2.equalsIgnoreCase("VIEW")) || (str2.equalsIgnoreCase("TABLE")) || (str2.equalsIgnoreCase("CLUSTER"))) {
          localDBRowCache1 = executeQuery(this.desc_sqls[5], localVariableTable, 5000);
        } else if ((str2.equalsIgnoreCase("PACKAGE")) || (str2.equalsIgnoreCase("PACKAGE BODY"))) {
          localDBRowCache1 = executeQuery(this.desc_sqls[6], localVariableTable, 5000);
        } else if ((str2.equalsIgnoreCase("PROCEDURE")) || (str2.equalsIgnoreCase("FUNCTION"))) {
          localDBRowCache1 = executeQuery(this.desc_sqls[7], localVariableTable, 5000);
        }
      }
      catch (SQLException localSQLException6)
      {
        this._stdout.print(localSQLException6);
        continue;
      }
      int k;
      if ((localDBRowCache1 != null) && (localDBRowCache1.getRowCount() > 0))
      {
        localDBRowCache1.getWidth(false);
        if ((str2.equalsIgnoreCase("VIEW")) || (str2.equalsIgnoreCase("CLUSTER")) || (str2.equalsIgnoreCase("PROCEDURE")) || (str2.equalsIgnoreCase("FUNCTION")))
        {
          localDBRowCache1.setColumnSize("NAME", 30);
          this._stdout.println(localDBRowCache1.getFixedHeader());
          this._stdout.println(localDBRowCache1.getSeperator());
          k = 1;
        }
      }
      while (k <= localDBRowCache1.getRowCount())
      {
        this._stdout.println(localDBRowCache1.getFixedRow(k));
        k++;
        continue;
        if (str2.equalsIgnoreCase("TABLE"))
        {
          localDBRowCache1.setColumnSize("NAME", 30);
          this._stdout.println(localDBRowCache1.getFixedHeader());
          this._stdout.println(localDBRowCache1.getSeperator());
          for (k = 1; k <= localDBRowCache1.getRowCount(); k++) {
            this._stdout.println(localDBRowCache1.getFixedRow(k));
          }
          try
          {
            localDBRowCache1 = executeQuery(this.desc_sqls[8], localVariableTable, 5000);
            localDBRowCache1.getWidth(false);
            localDBRowCache1.setColumnSize("INDEX_NAME", 30);
            if (localDBRowCache1.getRowCount() > 0)
            {
              this._stdout.println();
              this._stdout.println(localDBRowCache1.getFixedHeader());
              this._stdout.println(localDBRowCache1.getSeperator());
              for (k = 1; k <= localDBRowCache1.getRowCount(); k++) {
                this._stdout.println(localDBRowCache1.getFixedRow(k));
              }
            }
          }
          catch (SQLException localSQLException7) {}
          try
          {
            localDBRowCache1 = executeQuery(this.desc_sqls[9], localVariableTable, 5000);
            localDBRowCache1.getWidth(false);
            if (localDBRowCache1.getRowCount() > 0)
            {
              this._stdout.println();
              this._stdout.println(localDBRowCache1.getFixedHeader());
              this._stdout.println(localDBRowCache1.getSeperator());
              for (int m = 1; m <= localDBRowCache1.getRowCount(); m++) {
                this._stdout.println(localDBRowCache1.getFixedRow(m));
              }
            }
          }
          catch (SQLException localSQLException8) {}
        }
        else if ((str2.equalsIgnoreCase("PACKAGE")) || (str2.equalsIgnoreCase("PACKAGE BODY")))
        {
          Object localObject = "#null";
          int n = 0;
          int i1 = localDBRowCache1.getColumnSize(1);
          int i2 = 1;
          while (i2 <= localDBRowCache1.getRowCount())
          {
            String str3 = (String)localDBRowCache1.getItem(i2, 1);
            String str4 = str3.substring(0, str3.indexOf("("));
            String str5 = (String)localDBRowCache1.getItem(i2, 4);
            String str6 = (String)localDBRowCache1.getItem(i2, 2);
            if (!str3.equalsIgnoreCase((String)localObject))
            {
              n = 0;
              if ((str5 == null) || (str5.length() == 0))
              {
                this._stdout.println("PROCECURE " + str4);
              }
              else if (str6.trim().equals("@return"))
              {
                this._stdout.println("FUNCTION " + str4 + " RETURN " + str5);
              }
              else
              {
                this._stdout.println("PROCECURE " + str4);
                this._stdout.println(" " + localDBRowCache1.getFixedHeader().substring(i1));
                this._stdout.println(" " + localDBRowCache1.getSeperator().substring(i1));
                this._stdout.println(" " + localDBRowCache1.getFixedRow(i2).substring(i1));
                n = 1;
              }
              localObject = str3;
            }
            else
            {
              if (n == 0)
              {
                this._stdout.println(" " + localDBRowCache1.getFixedHeader().substring(i1));
                this._stdout.println(" " + localDBRowCache1.getSeperator().substring(i1));
                n = 1;
              }
              if (!str6.trim().equals("@return")) {
                this._stdout.println(" " + localDBRowCache1.getFixedRow(i2).substring(i1));
              }
            }
            i2++;
            continue;
            this._stdout.println("No column founded!");
          }
        }
      }
    }
  }
  
  private void showDBRowCache(DBRowCache paramDBRowCache, boolean paramBoolean)
  {
    paramDBRowCache.getWidth(false);
    if (paramBoolean)
    {
      this._stdout.println(paramDBRowCache.getFixedHeader());
      this._stdout.println(paramDBRowCache.getSeperator());
    }
    for (int i = 1; i <= paramDBRowCache.getRowCount(); i++) {
      this._stdout.println(paramDBRowCache.getFixedRow(i));
    }
  }
  
  private void procShow(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getDBCommand()[0]).size();
    String str = skipWord(paramString, i);
    String[] arrayOfString = TextUtils.toStringArray(TextUtils.getWords(str));
    if (arrayOfString.length > 0)
    {
      int j = commandAt(this.oracle_show_keys, new String[] { arrayOfString[0] });
      switch (j)
      {
      case 0: 
        procShowUser(str);
        break;
      case 1: 
        procShowSGA(str);
        break;
      case 2: 
        procShowSession(str);
        break;
      case 5: 
      case 6: 
        procShowConstraint(str);
        break;
      case 4: 
        procShowParent(str);
        break;
      case 3: 
        procShowChild(str);
        break;
      case 7: 
        procShowVersion(str);
        break;
      case 8: 
        procShowSpace(str);
        break;
      case 9: 
        procShowTable(str);
        break;
      case 10: 
        procShowStats(str);
        break;
      case 14: 
        procShowLoad(str);
        break;
      case 15: 
        procShowTopSQL(str);
        break;
      case 11: 
        procShowWait(str);
        break;
      case 12: 
        procShowVariable(str);
        break;
      case 13: 
        procShowErrors(str);
        break;
      default: 
        this._stdout.println("Usage: SHOW keyword argument");
        this._stdout.println();
        this._stdout.println("Keyword:");
        this._stdout.println("  USER SGA SESSION CHILD PARENT CONSTRAINT VERSION SPACE");
        this._stdout.println("  TABLE STATS WAIT VARIABLE ERRORS TOPSQL");
        this._stdout.println("Argument:");
        this._stdout.println("  for CHILD and PARENT, it should be table name,");
        this._stdout.println("  for CONSTRAINT, it should be constraint name.");
        break;
      }
    }
    else
    {
      this._stdout.println("Usage: SHOW keyword argument");
      this._stdout.println();
      this._stdout.println("Keyword:");
      this._stdout.println("  USER SGA SESSION CHILD PARENT CONSTRAINT VERSION SPACE");
      this._stdout.println("  TABLE STATS WAIT VARIABLE ERRORS TOPSQL");
      this._stdout.println("Argument:");
      this._stdout.println("  for CHILD and PARENT, it should be table name,");
      this._stdout.println("  for CONSTRAINT, it should be constraint name.");
    }
  }
  
  private void procShowUser(String paramString)
  {
    if (!isConnected())
    {
      this._stdout.println("Database not connected!");
      return;
    }
    try
    {
      DBRowCache localDBRowCache = executeQuery(this.database, "SELECT 'Current user : ' || USER FROM DUAL", this.sysvariable, 5000);
      showDBRowCache(localDBRowCache, false);
    }
    catch (SQLException localSQLException)
    {
      this._stdout.print(localSQLException);
    }
  }
  
  private void procShowVariable(String paramString)
  {
    String[] arrayOfString = this.sysvariable.getNames();
    if (arrayOfString.length > 0)
    {
      this._stdout.println(" Name                           Type");
      this._stdout.println(" ------------------------------ ------------");
      for (int i = 0; i < arrayOfString.length; i++)
      {
        this._stdout.print(" " + lpad(arrayOfString[i], 30));
        this._stdout.print(" ");
        this._stdout.println(SQLTypes.getTypeName(this.sysvariable.getType(arrayOfString[i])));
      }
    }
    this._stdout.println("No variables defined.");
  }
  
  private void procShowErrors(String paramString)
  {
    if (!isConnected())
    {
      this._stdout.println("Database not connected!");
      return;
    }
    try
    {
      VariableTable localVariableTable = new VariableTable();
      localVariableTable.add("P_OWNER", 12);
      localVariableTable.add("P_TYPE", 12);
      localVariableTable.add("P_NAME", 12);
      localVariableTable.setValue("P_OWNER", this.last_object_owner);
      localVariableTable.setValue("P_TYPE", this.last_object_type);
      localVariableTable.setValue("P_NAME", this.last_object_name);
      DBRowCache localDBRowCache = executeQuery(this.database, "SELECT /* AnySQL */ /*+ RULE */  \n  TO_CHAR(LINE)||'/'||TO_CHAR(POSITION) \"LINE/COL\",  \n  TEXT \"ERROR\"  \nFROM ALL_ERRORS A  \nWHERE A.NAME = UPPER(:P_NAME)  \n  AND A.OWNER = UPPER(NVL(:P_OWNER,USER))  \n  AND A.TYPE  = UPPER(:P_TYPE) \nORDER BY LINE, POSITION", localVariableTable, 1000);
      if (localDBRowCache.getRowCount() > 0)
      {
        this._stdout.print(this.last_object_type);
        this._stdout.print(" ");
        this._stdout.print(this.last_object_name);
        this._stdout.println(" ERRORS:");
        this._stdout.println();
        showDBRowCache(localDBRowCache, true);
      }
      else
      {
        this._stdout.println("No errors.");
      }
    }
    catch (SQLException localSQLException)
    {
      this._stdout.print(localSQLException);
    }
  }
  
  private void procShowSGA(String paramString)
  {
    if (!isConnected())
    {
      this._stdout.println("Database not connected!");
      return;
    }
    try
    {
      DBRowCache localDBRowCache = executeQuery(this.database, "SELECT * FROM V$SGA", this.sysvariable, 5000);
      showDBRowCache(localDBRowCache, false);
    }
    catch (SQLException localSQLException)
    {
      this._stdout.print(localSQLException);
    }
  }
  
  private void procShowVersion(String paramString)
  {
    if (!isConnected())
    {
      this._stdout.println("Database not connected!");
      return;
    }
    try
    {
      DBRowCache localDBRowCache = executeQuery(this.database, "SELECT * FROM V$VERSION", this.sysvariable, 5000);
      showDBRowCache(localDBRowCache, false);
    }
    catch (SQLException localSQLException)
    {
      this._stdout.print(localSQLException);
    }
  }
  
  private void procShowParent(String paramString)
  {
    if (!isConnected())
    {
      this._stdout.println("Database not connected!");
      return;
    }
    DBRowCache localDBRowCache = null;
    String str = skipWord(paramString, 1);
    str = str.trim();
    String[] arrayOfString = TextUtils.toStringArray(TextUtils.getWords(str, new String[] { "." }));
    if (arrayOfString.length == 0)
    {
      this._stdout.println("Table name required.");
      return;
    }
    VariableTable localVariableTable = new VariableTable();
    localVariableTable.add("P_OWNER", 12);
    localVariableTable.add("P_NAME", 12);
    if ((arrayOfString.length == 1) || (arrayOfString.length == 2))
    {
      if (arrayOfString.length == 1) {
        localVariableTable.setValue("P_NAME", arrayOfString[0].toUpperCase());
      }
      if (arrayOfString.length == 2)
      {
        localVariableTable.setValue("P_OWNER", arrayOfString[0].toUpperCase());
        localVariableTable.setValue("P_NAME", arrayOfString[1].toUpperCase());
      }
    }
    try
    {
      localDBRowCache = executeQuery(this.database, "SELECT /* AnySQL */ R.CONSTRAINT_NAME FKNAME, \n       T.OWNER||'.'||T.TABLE_NAME TNAME, \n       T.CONSTRAINT_NAME PKNAME \n  FROM ALL_CONSTRAINTS R, ALL_CONSTRAINTS T \n  WHERE R.CONSTRAINT_TYPE = 'R' \n    AND R.R_OWNER = T.OWNER AND R.R_CONSTRAINT_NAME = T.CONSTRAINT_NAME \n    AND R.OWNER = NVL(:P_OWNER,USER) AND R.TABLE_NAME = :P_NAME", localVariableTable, 2000);
    }
    catch (SQLException localSQLException)
    {
      this._stdout.print(localSQLException);
      return;
    }
    if ((localDBRowCache == null) || (localDBRowCache.getRowCount() == 0))
    {
      this._stdout.println("Table " + str + " not exists or have no parent table!");
      return;
    }
    showDBRowCache(localDBRowCache, true);
  }
  
  private void procShowTable(String paramString)
  {
    if (!isConnected())
    {
      this._stdout.println("Database not connected!");
      return;
    }
    DBRowCache localDBRowCache = null;
    String str = skipWord(paramString, 1);
    str = str.trim();
    String[] arrayOfString = TextUtils.toStringArray(TextUtils.getWords(str, new String[] { "." }));
    if (arrayOfString.length == 0)
    {
      this._stdout.println("Table name required.");
      return;
    }
    VariableTable localVariableTable = new VariableTable();
    localVariableTable.add("P_OWNER", 12);
    localVariableTable.add("P_NAME", 12);
    if ((arrayOfString.length == 1) || (arrayOfString.length == 2))
    {
      if (arrayOfString.length == 1) {
        localVariableTable.setValue("P_NAME", arrayOfString[0].toUpperCase());
      }
      if (arrayOfString.length == 2)
      {
        localVariableTable.setValue("P_OWNER", arrayOfString[0].toUpperCase());
        localVariableTable.setValue("P_NAME", arrayOfString[1].toUpperCase());
      }
    }
    try
    {
      localDBRowCache = executeQuery(this.database, "SELECT /* AnySQL */ OWNER,INDEX_NAME,INDEX_TYPE,UNIQUENESS, \n       TABLESPACE_NAME TS_NAME,STATUS,PARTITIONED \n  FROM ALL_INDEXES \n  WHERE TABLE_OWNER=NVL(:P_OWNER,USER) AND TABLE_NAME=:P_NAME \n", localVariableTable, 2000);
    }
    catch (SQLException localSQLException1)
    {
      this._stdout.print(localSQLException1);
      return;
    }
    this._stdout.println("Index List:");
    this._stdout.print(localDBRowCache);
    try
    {
      localDBRowCache = executeQuery(this.database, "SELECT /* AnySQL */ OWNER,CONSTRAINT_NAME, \n  DECODE(CONSTRAINT_TYPE , \n        'P','Primary Key', \n        'R','Foreign Key', \n        'U','Unique', \n        'C','Check','Not Null') TYPE, \n        STATUS,VALIDATED \n  FROM ALL_CONSTRAINTS \n  WHERE OWNER=NVL(:P_OWNER,USER) AND TABLE_NAME=:P_NAME \n", localVariableTable, 2000);
    }
    catch (SQLException localSQLException2)
    {
      this._stdout.print(localSQLException2);
      return;
    }
    this._stdout.println();
    this._stdout.println("Constraint List:");
    this._stdout.print(localDBRowCache);
    try
    {
      localDBRowCache = executeQuery(this.database, "SELECT /* AnySQL */ OWNER,TRIGGER_NAME, \n  TRIGGER_TYPE,TRIGGERING_EVENT EVENT,STATUS \n  FROM ALL_TRIGGERS \n  WHERE TABLE_OWNER=NVL(:P_OWNER,USER) AND TABLE_NAME=:P_NAME \n", localVariableTable, 2000);
    }
    catch (SQLException localSQLException3)
    {
      this._stdout.print(localSQLException3);
      return;
    }
    this._stdout.println();
    this._stdout.println("Trigger List:");
    this._stdout.print(localDBRowCache);
  }
  
  private void procShowWait(String paramString)
  {
    if (!isConnected())
    {
      this._stdout.println("Database not connected!");
      return;
    }
    Object localObject = null;
    String str1 = skipWord(paramString, 1);
    OptionCommand localOptionCommand = new OptionCommand(str1);
    String str2 = null;
    int i = 1000000;
    int j = 5;
    this.exit_show_loop = 0;
    str2 = localOptionCommand.getOption("S", null);
    i = localOptionCommand.getInt("C", 1000000);
    j = localOptionCommand.getInt("T", 5);
    if (i < 1) {
      i = 1;
    }
    if (j < 5) {
      j = 5;
    }
    if (j > 300) {
      j = 300;
    }
    DBRowCache localDBRowCache1 = null;
    DBRowCache localDBRowCache2 = getSessionWait(str2);
    SimpleDBRowCache localSimpleDBRowCache = new SimpleDBRowCache();
    localSimpleDBRowCache.copyStruct(localDBRowCache2);
    for (int k = 0; (k < i) && (this.exit_show_loop == 0); k++)
    {
      try
      {
        Thread.currentThread();
        Thread.sleep(j * 1000);
      }
      catch (InterruptedException localInterruptedException)
      {
        return;
      }
      localDBRowCache1 = getSessionWait(str2);
      localSimpleDBRowCache.deleteAllRow();
      this._stdout.println("Time: " + DateOperator.getDay("yyyy-MM-dd HH:mm:ss"));
      this._stdout.println("  Waits     Time  Event");
      this._stdout.println("-----------------------------------------------------");
      if ((localDBRowCache2 == null) || (localDBRowCache1 == null)) {
        return;
      }
      if (localDBRowCache2.getColumnCount() == 0) {
        return;
      }
      if (localDBRowCache2.getRowCount() == localDBRowCache1.getRowCount())
      {
        for (int m = 1; m <= localDBRowCache2.getRowCount(); m++)
        {
          String str3 = (String)localDBRowCache2.getItem(m, 1);
          BigInteger localBigInteger1 = new BigInteger(localDBRowCache2.getItem(m, 2).toString());
          BigInteger localBigInteger3 = new BigInteger(localDBRowCache2.getItem(m, 3).toString());
          BigInteger localBigInteger2 = new BigInteger(localDBRowCache1.getItem(m, 2).toString());
          BigInteger localBigInteger4 = new BigInteger(localDBRowCache1.getItem(m, 3).toString());
          BigInteger localBigInteger5 = localBigInteger2.add(localBigInteger1.negate());
          BigInteger localBigInteger6 = localBigInteger4.add(localBigInteger3.negate());
          if ((localBigInteger6.longValue() > 0L) && (str3.equals(localDBRowCache1.getItem(m, 1))))
          {
            int n = localSimpleDBRowCache.appendRow();
            localSimpleDBRowCache.setItem(n, 1, str3);
            localSimpleDBRowCache.setItem(n, 2, localBigInteger5);
            localSimpleDBRowCache.setItem(n, 3, localBigInteger6);
          }
        }
        localSimpleDBRowCache.quicksort(3, false);
        for (m = 1; m <= localSimpleDBRowCache.getRowCount(); m++)
        {
          this._stdout.print(rpad(localSimpleDBRowCache.getItem(m, 2) + " ", 8));
          this._stdout.print(rpad(localSimpleDBRowCache.getItem(m, 3) + "  ", 10));
          this._stdout.println((String)localSimpleDBRowCache.getItem(m, 1));
        }
      }
      if (k < i - 1) {
        this._stdout.println();
      }
      localDBRowCache2 = localDBRowCache1;
    }
    localDBRowCache2 = null;
  }
  
  private String formatStatsValue(long paramLong)
  {
    if (paramLong > 10000000L) {
      return paramLong / 1000000L + "M";
    }
    if (paramLong > 10000L) {
      return paramLong / 1000L + "K";
    }
    if (paramLong >= 0L) {
      return String.valueOf(paramLong);
    }
    return "n/a";
  }
  
  private void procShowStats(String paramString)
  {
    if (!isConnected())
    {
      this._stdout.println("Database not connected!");
      return;
    }
    Object localObject1 = null;
    String str1 = skipWord(paramString, 1);
    OptionCommand localOptionCommand = new OptionCommand(str1);
    String str2 = null;
    int i = 10000000;
    int j = 5;
    String str3 = "%";
    this.exit_show_loop = 0;
    str2 = localOptionCommand.getOption("S", null);
    i = localOptionCommand.getInt("C", 1000000);
    j = localOptionCommand.getInt("T", 5);
    if (i < 1) {
      i = 1;
    }
    if (j < 5) {
      j = 5;
    }
    if (j > 300) {
      j = 300;
    }
    DBRowCache localDBRowCache1 = null;
    DBRowCache localDBRowCache2 = getSessionStats(str2, str3);
    for (int k = 0; (k < i) && (this.exit_show_loop == 0); k++)
    {
      try
      {
        Thread.currentThread();
        Thread.sleep(j * 1000);
      }
      catch (InterruptedException localInterruptedException)
      {
        return;
      }
      localDBRowCache1 = getSessionStats(str2, str3);
      this._stdout.println("Statistics (" + DateOperator.getDay("yyyy-MM-dd HH:mm:ss") + ")");
      this._stdout.println("-----------------------------------------------------------");
      if ((localDBRowCache2 == null) || (localDBRowCache1 == null)) {
        return;
      }
      if (localDBRowCache2.getRowCount() == localDBRowCache1.getRowCount()) {
        for (int m = 1; m <= localDBRowCache2.getRowCount(); m++)
        {
          Object localObject2 = localDBRowCache2.getItem(m, 1);
          Object localObject3 = localDBRowCache1.getItem(m, 1);
          BigInteger localBigInteger1 = new BigInteger(localDBRowCache2.getItem(m, 2).toString());
          BigInteger localBigInteger2 = new BigInteger(localDBRowCache1.getItem(m, 2).toString());
          BigInteger localBigInteger3 = localBigInteger2.add(localBigInteger1.negate());
          if ((localBigInteger3.longValue() > 0L) && (localObject2.equals(localObject3))) {
            this._stdout.println(rpad(new StringBuffer().append(" ").append(formatStatsValue(localBigInteger3.longValue())).toString(), 8) + "   " + lpad(this.h_statname.get(localObject2).toString(), 32));
          }
        }
      }
      if (k < i - 1) {
        this._stdout.println();
      }
      localDBRowCache2 = localDBRowCache1;
    }
  }
  
  private void procShowLoad(String paramString)
  {
    if (!isConnected())
    {
      this._stdout.println("Database not connected!");
      return;
    }
    Object localObject1 = null;
    String str1 = skipWord(paramString, 1);
    OptionCommand localOptionCommand = new OptionCommand(str1);
    int i = 10000000;
    int j = 3;
    int k = 8;
    String str2 = null;
    long l1 = 0L;
    long l2 = 0L;
    float f = 0.0F;
    Hashtable localHashtable = new Hashtable();
    this.exit_show_loop = 0;
    str2 = localOptionCommand.getString("S", null);
    i = localOptionCommand.getInt("C", 1000000);
    j = localOptionCommand.getInt("T", 10);
    k = localOptionCommand.getInt("N", 8);
    if (k < 5) {
      k = 5;
    }
    if (i < 1) {
      i = 1;
    }
    if (j < 5) {
      j = 5;
    }
    if (j > 900) {
      j = 900;
    }
    DBRowCache localDBRowCache1 = null;
    DBRowCache localDBRowCache2 = null;
    DBRowCache localDBRowCache3 = null;
    DBRowCache localDBRowCache4 = getSessionWait(str2);
    DBRowCache localDBRowCache5 = getSQLExecution();
    DBRowCache localDBRowCache6 = getSessionStats(str2, "");
    SimpleDBRowCache localSimpleDBRowCache1 = new SimpleDBRowCache();
    SimpleDBRowCache localSimpleDBRowCache2 = new SimpleDBRowCache();
    localSimpleDBRowCache1.copyStruct(localDBRowCache4);
    localSimpleDBRowCache2.copyStruct(localDBRowCache5);
    if (localDBRowCache5 != null) {
      for (m = 1; m < localDBRowCache5.getRowCount(); m++) {
        localHashtable.put(localDBRowCache5.getItem(m, 1), new Integer(m));
      }
    }
    l1 = System.currentTimeMillis();
    for (int m = 0; (m < i) && (this.exit_show_loop == 0); m++)
    {
      try
      {
        Thread.currentThread();
        Thread.sleep(j * 1000);
      }
      catch (InterruptedException localInterruptedException)
      {
        return;
      }
      localDBRowCache2 = getSessionWait(str2);
      localDBRowCache1 = getSessionStats(str2, "");
      localDBRowCache3 = getSQLExecution();
      l2 = System.currentTimeMillis();
      f = 1.0F * (float)(l2 - l1) / 1000.0F;
      l1 = l2;
      localSimpleDBRowCache1.deleteAllRow();
      if (str2 == null) {
        this._stdout.println("System Load (" + DateOperator.getDay("yyyy-MM-dd HH:mm:ss") + ")");
      } else {
        this._stdout.println("Session: " + str2 + " Load (" + DateOperator.getDay("yyyy-MM-dd HH:mm:ss") + ")");
      }
      this._stdout.println("---System Statistics------------------------------------------------------------------");
      if ((localDBRowCache6 == null) || (localDBRowCache1 == null)) {
        return;
      }
      Object localObject2;
      Object localObject3;
      BigInteger localBigInteger1;
      BigInteger localBigInteger2;
      BigInteger localBigInteger3;
      if (localDBRowCache6.getRowCount() == localDBRowCache1.getRowCount())
      {
        for (int i1 = 1; i1 <= localDBRowCache6.getRowCount(); i1++)
        {
          localObject2 = localDBRowCache1.getItem(i1, 1);
          localObject3 = localDBRowCache6.getItem(i1, 1);
          localBigInteger1 = new BigInteger(localDBRowCache6.getItem(i1, 2).toString());
          localBigInteger2 = new BigInteger(localDBRowCache1.getItem(i1, 2).toString());
          localBigInteger3 = localBigInteger2.add(localBigInteger1.negate());
          if (localObject2.equals(localObject3)) {
            if (i1 % 2 == 1) {
              this._stdout.print(rpad(new StringBuffer().append(" ").append(formatStatsValue(localBigInteger3.longValue())).toString(), 6) + rpad(new StringBuffer().append(" ").append(formatStatsValue(((float)localBigInteger3.longValue() / f))).toString(), 6) + "  " + lpad(this.h_statname.get(localObject2).toString(), 32));
            } else {
              this._stdout.println(rpad(new StringBuffer().append(" ").append(formatStatsValue(localBigInteger3.longValue())).toString(), 6) + rpad(new StringBuffer().append(" ").append(formatStatsValue(((float)localBigInteger3.longValue() / f))).toString(), 6) + "  " + lpad(this.h_statname.get(localObject2).toString(), 32));
            }
          }
        }
        if (localDBRowCache6.getRowCount() % 2 == 1) {
          this._stdout.println();
        }
      }
      localDBRowCache6 = localDBRowCache1;
      BigInteger localBigInteger4;
      BigInteger localBigInteger5;
      int i4;
      if ((localDBRowCache2 != null) && (localDBRowCache6 != null) && (localDBRowCache4.getRowCount() == localDBRowCache2.getRowCount()))
      {
        this._stdout.println();
        this._stdout.println("----Waits---Waits/S-----Time-----Time/S--Pct--Event-----------------------------------");
        for (int i2 = 1; i2 <= localDBRowCache4.getRowCount(); i2++)
        {
          localObject2 = (String)localDBRowCache4.getItem(i2, 1);
          localObject3 = new BigInteger(localDBRowCache4.getItem(i2, 2).toString());
          localBigInteger2 = new BigInteger(localDBRowCache4.getItem(i2, 3).toString());
          localBigInteger1 = new BigInteger(localDBRowCache2.getItem(i2, 2).toString());
          localBigInteger3 = new BigInteger(localDBRowCache2.getItem(i2, 3).toString());
          localBigInteger4 = localBigInteger1.add(((BigInteger)localObject3).negate());
          localBigInteger5 = localBigInteger3.add(localBigInteger2.negate());
          if ((localBigInteger5.longValue() > 0L) && (((String)localObject2).equals(localDBRowCache2.getItem(i2, 1))))
          {
            int i3 = localSimpleDBRowCache1.appendRow();
            localSimpleDBRowCache1.setItem(i3, 1, localObject2);
            localSimpleDBRowCache1.setItem(i3, 2, localBigInteger4);
            localSimpleDBRowCache1.setItem(i3, 3, localBigInteger5);
          }
        }
        localSimpleDBRowCache1.quicksort(3, false);
        double d = localSimpleDBRowCache1.sum("WTIME");
        for (i4 = 1; (i4 <= localSimpleDBRowCache1.getRowCount()) && (i4 <= 5); i4++)
        {
          localBigInteger4 = (BigInteger)localSimpleDBRowCache1.getItem(i4, 2);
          localBigInteger5 = (BigInteger)localSimpleDBRowCache1.getItem(i4, 3);
          this._stdout.print(rpad(localBigInteger4.toString() + " ", 10));
          this._stdout.print(rpad(((float)localBigInteger4.longValue() / f) + " ", 10));
          this._stdout.print(rpad(localBigInteger5.toString() + "  ", 10));
          this._stdout.print(rpad(((float)localBigInteger5.longValue() / f) + " ", 10));
          this._stdout.print(rpad((int)(100.0D * localBigInteger5.doubleValue() / d) + "  ", 6));
          this._stdout.println((String)localSimpleDBRowCache1.getItem(i4, 1));
        }
      }
      localDBRowCache4 = localDBRowCache2;
      if ((localDBRowCache5 != null) && (localDBRowCache3 != null) && (localDBRowCache5.getRowCount() > 0) && (localDBRowCache3.getRowCount() > 0))
      {
        int n = 0;
        localSimpleDBRowCache2.deleteAllRow();
        for (i4 = 1; i4 < localDBRowCache3.getRowCount(); i4++) {
          if (localHashtable.containsKey(localDBRowCache3.getItem(i4, 1)))
          {
            int i5 = ((Integer)localHashtable.get(localDBRowCache3.getItem(i4, 1))).intValue();
            localObject3 = new BigInteger(localDBRowCache5.getItem(i5, 2).toString());
            localBigInteger1 = new BigInteger(localDBRowCache3.getItem(i4, 2).toString());
            if (localBigInteger1.compareTo((BigInteger)localObject3) > 0)
            {
              n = localSimpleDBRowCache2.appendRow();
              localSimpleDBRowCache2.setItem(n, 1, localDBRowCache3.getItem(i4, 1));
              localSimpleDBRowCache2.setItem(n, 2, localBigInteger1.add(((BigInteger)localObject3).negate()));
              localObject3 = new BigInteger(localDBRowCache5.getItem(i5, 3).toString());
              localBigInteger1 = new BigInteger(localDBRowCache3.getItem(i4, 3).toString());
              localSimpleDBRowCache2.setItem(n, 3, localBigInteger1.add(((BigInteger)localObject3).negate()));
              localObject3 = new BigInteger(localDBRowCache5.getItem(i5, 4).toString());
              localBigInteger1 = new BigInteger(localDBRowCache3.getItem(i4, 4).toString());
              localSimpleDBRowCache2.setItem(n, 4, localBigInteger1.add(((BigInteger)localObject3).negate()));
              localObject3 = new BigInteger(localDBRowCache5.getItem(i5, 5).toString());
              localBigInteger1 = new BigInteger(localDBRowCache3.getItem(i4, 5).toString());
              localSimpleDBRowCache2.setItem(n, 5, localBigInteger1.add(((BigInteger)localObject3).negate()));
              localObject3 = new BigInteger(localDBRowCache5.getItem(i5, 6).toString());
              localBigInteger1 = new BigInteger(localDBRowCache3.getItem(i4, 6).toString());
              localSimpleDBRowCache2.setItem(n, 6, localBigInteger1.add(((BigInteger)localObject3).negate()));
            }
          }
          else
          {
            localObject3 = new BigInteger(localDBRowCache3.getItem(i4, 2).toString());
            if (((BigInteger)localObject3).longValue() > 0L)
            {
              n = localSimpleDBRowCache2.appendRow();
              localSimpleDBRowCache2.setItem(n, 1, localDBRowCache3.getItem(i4, 1));
              localSimpleDBRowCache2.setItem(n, 2, localObject3);
              localObject3 = new BigInteger(localDBRowCache3.getItem(i4, 3).toString());
              localSimpleDBRowCache2.setItem(n, 3, localObject3);
              localObject3 = new BigInteger(localDBRowCache3.getItem(i4, 4).toString());
              localSimpleDBRowCache2.setItem(n, 4, localObject3);
              localObject3 = new BigInteger(localDBRowCache3.getItem(i4, 5).toString());
              localSimpleDBRowCache2.setItem(n, 5, localObject3);
              localObject3 = new BigInteger(localDBRowCache3.getItem(i4, 6).toString());
              localSimpleDBRowCache2.setItem(n, 6, localObject3);
            }
          }
        }
        localSimpleDBRowCache2.quicksort(3, false);
        this._stdout.println();
        this._stdout.println("---Exec--Exe/S--Get/S--Get/E--Dsk/S--Dsk/E--Sorts--Row/E------HASH---(Order by Gets)--");
        BigInteger localBigInteger6;
        for (i4 = 1; (i4 <= k) && (i4 <= localSimpleDBRowCache2.getRowCount()); i4++)
        {
          localBigInteger2 = (BigInteger)localSimpleDBRowCache2.getItem(i4, 2);
          localBigInteger3 = (BigInteger)localSimpleDBRowCache2.getItem(i4, 3);
          localBigInteger4 = (BigInteger)localSimpleDBRowCache2.getItem(i4, 4);
          localBigInteger5 = (BigInteger)localSimpleDBRowCache2.getItem(i4, 5);
          localBigInteger6 = (BigInteger)localSimpleDBRowCache2.getItem(i4, 6);
          this._stdout.println(rpad(new StringBuffer().append(" ").append(formatStatsValue(localBigInteger2.longValue())).toString(), 7) + rpad(formatStatsValue(((float)localBigInteger2.longValue() / f)), 7) + rpad(formatStatsValue(((float)localBigInteger3.longValue() / f)), 7) + rpad(formatStatsValue(localBigInteger3.longValue() / localBigInteger2.longValue()), 7) + rpad(formatStatsValue(((float)localBigInteger4.longValue() / f)), 7) + rpad(formatStatsValue(localBigInteger4.longValue() / localBigInteger2.longValue()), 7) + rpad(formatStatsValue(localBigInteger6.longValue()), 7) + rpad(formatStatsValue(localBigInteger5.longValue() / localBigInteger2.longValue()), 7) + rpad(localSimpleDBRowCache2.getItem(i4, 1).toString(), 16));
        }
        localSimpleDBRowCache2.quicksort(4, false);
        this._stdout.println();
        this._stdout.println("---Exec--Exe/S--Get/S--Get/E--Dsk/S--Dsk/E--Sorts--Row/E------HASH---(Order by Disk)--");
        for (i4 = 1; (i4 <= k) && (i4 <= localSimpleDBRowCache2.getRowCount()); i4++)
        {
          localBigInteger2 = (BigInteger)localSimpleDBRowCache2.getItem(i4, 2);
          localBigInteger3 = (BigInteger)localSimpleDBRowCache2.getItem(i4, 3);
          localBigInteger4 = (BigInteger)localSimpleDBRowCache2.getItem(i4, 4);
          localBigInteger5 = (BigInteger)localSimpleDBRowCache2.getItem(i4, 5);
          localBigInteger6 = (BigInteger)localSimpleDBRowCache2.getItem(i4, 6);
          this._stdout.println(rpad(new StringBuffer().append(" ").append(formatStatsValue(localBigInteger2.longValue())).toString(), 7) + rpad(formatStatsValue(((float)localBigInteger2.longValue() / f)), 7) + rpad(formatStatsValue(((float)localBigInteger3.longValue() / f)), 7) + rpad(formatStatsValue(localBigInteger3.longValue() / localBigInteger2.longValue()), 7) + rpad(formatStatsValue(((float)localBigInteger4.longValue() / f)), 7) + rpad(formatStatsValue(localBigInteger4.longValue() / localBigInteger2.longValue()), 7) + rpad(formatStatsValue(localBigInteger6.longValue()), 7) + rpad(formatStatsValue(localBigInteger5.longValue() / localBigInteger2.longValue()), 7) + rpad(localSimpleDBRowCache2.getItem(i4, 1).toString(), 16));
        }
        if (localDBRowCache3 != null)
        {
          localHashtable.clear();
          for (i4 = 1; i4 < localDBRowCache3.getRowCount(); i4++) {
            localHashtable.put(localDBRowCache3.getItem(i4, 1), new Integer(i4));
          }
        }
      }
      localDBRowCache5 = localDBRowCache3;
      this._stdout.println();
      System.runFinalization();
      System.gc();
    }
  }
  
  private void procShowTopSQL(String paramString)
  {
    if (!isConnected())
    {
      this._stdout.println("Database not connected!");
      return;
    }
    Object localObject1 = null;
    String str1 = skipWord(paramString, 1);
    OptionCommand localOptionCommand = new OptionCommand(str1);
    int i = 10000000;
    int j = 3;
    int k = 10;
    String str2 = "ALL";
    Object localObject2 = null;
    long l1 = 0L;
    long l2 = 0L;
    float f = 0.0F;
    Hashtable localHashtable = new Hashtable();
    this.exit_show_loop = 0;
    k = localOptionCommand.getInt("N", 12);
    i = localOptionCommand.getInt("C", 1000000);
    j = localOptionCommand.getInt("T", 10);
    str2 = localOptionCommand.getString("O", "ALL");
    if (i < 1) {
      i = 1;
    }
    if (j < 5) {
      j = 5;
    }
    if (j > 900) {
      j = 900;
    }
    if (k < 8) {
      k = 8;
    }
    DBRowCache localDBRowCache1 = null;
    DBRowCache localDBRowCache2 = getSQLExecution();
    SimpleDBRowCache localSimpleDBRowCache = new SimpleDBRowCache();
    localSimpleDBRowCache.copyStruct(localDBRowCache2);
    l1 = System.currentTimeMillis();
    if (localDBRowCache2 != null) {
      for (m = 1; m < localDBRowCache2.getRowCount(); m++) {
        localHashtable.put(localDBRowCache2.getItem(m, 1), new Integer(m));
      }
    }
    for (int m = 0; (m < i) && (this.exit_show_loop == 0); m++)
    {
      try
      {
        Thread.currentThread();
        Thread.sleep(j * 1000);
      }
      catch (InterruptedException localInterruptedException)
      {
        return;
      }
      localDBRowCache1 = getSQLExecution();
      l2 = System.currentTimeMillis();
      f = 1.0F * (float)(l2 - l1) / 1000.0F;
      l1 = l2;
      if ((localDBRowCache2 != null) && (localDBRowCache1 != null) && (localDBRowCache2.getRowCount() > 0) && (localDBRowCache1.getRowCount() > 0))
      {
        int n = 0;
        localSimpleDBRowCache.deleteAllRow();
        for (int i1 = 1; i1 < localDBRowCache1.getRowCount(); i1++)
        {
          BigInteger localBigInteger1;
          if (localHashtable.containsKey(localDBRowCache1.getItem(i1, 1)))
          {
            int i2 = ((Integer)localHashtable.get(localDBRowCache1.getItem(i1, 1))).intValue();
            localBigInteger1 = new BigInteger(localDBRowCache2.getItem(i2, 2).toString());
            BigInteger localBigInteger2 = new BigInteger(localDBRowCache1.getItem(i1, 2).toString());
            if (localBigInteger2.compareTo(localBigInteger1) > 0)
            {
              n = localSimpleDBRowCache.appendRow();
              localSimpleDBRowCache.setItem(n, 1, localDBRowCache1.getItem(i1, 1));
              localSimpleDBRowCache.setItem(n, 2, localBigInteger2.add(localBigInteger1.negate()));
              localBigInteger1 = new BigInteger(localDBRowCache2.getItem(i2, 3).toString());
              localBigInteger2 = new BigInteger(localDBRowCache1.getItem(i1, 3).toString());
              localSimpleDBRowCache.setItem(n, 3, localBigInteger2.add(localBigInteger1.negate()));
              localBigInteger1 = new BigInteger(localDBRowCache2.getItem(i2, 4).toString());
              localBigInteger2 = new BigInteger(localDBRowCache1.getItem(i1, 4).toString());
              localSimpleDBRowCache.setItem(n, 4, localBigInteger2.add(localBigInteger1.negate()));
              localBigInteger1 = new BigInteger(localDBRowCache2.getItem(i2, 5).toString());
              localBigInteger2 = new BigInteger(localDBRowCache1.getItem(i1, 5).toString());
              localSimpleDBRowCache.setItem(n, 5, localBigInteger2.add(localBigInteger1.negate()));
              localBigInteger1 = new BigInteger(localDBRowCache2.getItem(i2, 6).toString());
              localBigInteger2 = new BigInteger(localDBRowCache1.getItem(i1, 6).toString());
              localSimpleDBRowCache.setItem(n, 6, localBigInteger2.add(localBigInteger1.negate()));
            }
          }
          else
          {
            localBigInteger1 = new BigInteger(localDBRowCache1.getItem(i1, 2).toString());
            if (localBigInteger1.longValue() > 0L)
            {
              n = localSimpleDBRowCache.appendRow();
              localSimpleDBRowCache.setItem(n, 1, localDBRowCache1.getItem(i1, 1));
              localSimpleDBRowCache.setItem(n, 2, localBigInteger1);
              localBigInteger1 = new BigInteger(localDBRowCache1.getItem(i1, 3).toString());
              localSimpleDBRowCache.setItem(n, 3, localBigInteger1);
              localBigInteger1 = new BigInteger(localDBRowCache1.getItem(i1, 4).toString());
              localSimpleDBRowCache.setItem(n, 4, localBigInteger1);
              localBigInteger1 = new BigInteger(localDBRowCache1.getItem(i1, 5).toString());
              localSimpleDBRowCache.setItem(n, 5, localBigInteger1);
              localBigInteger1 = new BigInteger(localDBRowCache1.getItem(i1, 6).toString());
              localSimpleDBRowCache.setItem(n, 6, localBigInteger1);
            }
          }
        }
        this._stdout.println("Top SQL (" + DateOperator.getDay("yyyy-MM-dd HH:mm:ss") + ")");
        BigInteger localBigInteger3;
        BigInteger localBigInteger4;
        BigInteger localBigInteger5;
        BigInteger localBigInteger6;
        BigInteger localBigInteger7;
        if ((str2.equalsIgnoreCase("ALL")) || (str2.equalsIgnoreCase("EXEC")))
        {
          localSimpleDBRowCache.quicksort(2, false);
          this._stdout.println("---Exec--Exe/S--Get/S--Get/E--Dsk/S--Dsk/E--Sorts--Row/E------HASH---(Order by Exec)--");
          for (i1 = 1; (i1 <= k) && (i1 <= localSimpleDBRowCache.getRowCount()); i1++)
          {
            localBigInteger3 = (BigInteger)localSimpleDBRowCache.getItem(i1, 2);
            localBigInteger4 = (BigInteger)localSimpleDBRowCache.getItem(i1, 3);
            localBigInteger5 = (BigInteger)localSimpleDBRowCache.getItem(i1, 4);
            localBigInteger6 = (BigInteger)localSimpleDBRowCache.getItem(i1, 5);
            localBigInteger7 = (BigInteger)localSimpleDBRowCache.getItem(i1, 6);
            this._stdout.println(rpad(new StringBuffer().append(" ").append(formatStatsValue(localBigInteger3.longValue())).toString(), 7) + rpad(formatStatsValue(((float)localBigInteger3.longValue() / f)), 7) + rpad(formatStatsValue(((float)localBigInteger4.longValue() / f)), 7) + rpad(formatStatsValue(localBigInteger4.longValue() / localBigInteger3.longValue()), 7) + rpad(formatStatsValue(((float)localBigInteger5.longValue() / f)), 7) + rpad(formatStatsValue(localBigInteger5.longValue() / localBigInteger3.longValue()), 7) + rpad(formatStatsValue(localBigInteger7.longValue()), 7) + rpad(formatStatsValue(localBigInteger6.longValue() / localBigInteger3.longValue()), 7) + rpad(localSimpleDBRowCache.getItem(i1, 1).toString(), 16));
          }
          this._stdout.println();
        }
        if ((str2.equalsIgnoreCase("ALL")) || (str2.equalsIgnoreCase("GETS")))
        {
          localSimpleDBRowCache.quicksort(3, false);
          this._stdout.println("---Exec--Exe/S--Get/S--Get/E--Dsk/S--Dsk/E--Sorts--Row/E------HASH---(Order by Gets)--");
          for (i1 = 1; (i1 <= k) && (i1 <= localSimpleDBRowCache.getRowCount()); i1++)
          {
            localBigInteger3 = (BigInteger)localSimpleDBRowCache.getItem(i1, 2);
            localBigInteger4 = (BigInteger)localSimpleDBRowCache.getItem(i1, 3);
            localBigInteger5 = (BigInteger)localSimpleDBRowCache.getItem(i1, 4);
            localBigInteger6 = (BigInteger)localSimpleDBRowCache.getItem(i1, 5);
            localBigInteger7 = (BigInteger)localSimpleDBRowCache.getItem(i1, 6);
            this._stdout.println(rpad(new StringBuffer().append(" ").append(formatStatsValue(localBigInteger3.longValue())).toString(), 7) + rpad(formatStatsValue(((float)localBigInteger3.longValue() / f)), 7) + rpad(formatStatsValue(((float)localBigInteger4.longValue() / f)), 7) + rpad(formatStatsValue(localBigInteger4.longValue() / localBigInteger3.longValue()), 7) + rpad(formatStatsValue(((float)localBigInteger5.longValue() / f)), 7) + rpad(formatStatsValue(localBigInteger5.longValue() / localBigInteger3.longValue()), 7) + rpad(formatStatsValue(localBigInteger7.longValue()), 7) + rpad(formatStatsValue(localBigInteger6.longValue() / localBigInteger3.longValue()), 7) + rpad(localSimpleDBRowCache.getItem(i1, 1).toString(), 16));
          }
          this._stdout.println();
        }
        if ((str2.equalsIgnoreCase("ALL")) || (str2.equalsIgnoreCase("DISK")))
        {
          localSimpleDBRowCache.quicksort(4, false);
          this._stdout.println("---Exec--Exe/S--Get/S--Get/E--Dsk/S--Dsk/E--Sorts--Row/E------HASH---(Order by Disk)--");
          for (i1 = 1; (i1 <= k) && (i1 <= localSimpleDBRowCache.getRowCount()); i1++)
          {
            localBigInteger3 = (BigInteger)localSimpleDBRowCache.getItem(i1, 2);
            localBigInteger4 = (BigInteger)localSimpleDBRowCache.getItem(i1, 3);
            localBigInteger5 = (BigInteger)localSimpleDBRowCache.getItem(i1, 4);
            localBigInteger6 = (BigInteger)localSimpleDBRowCache.getItem(i1, 5);
            localBigInteger7 = (BigInteger)localSimpleDBRowCache.getItem(i1, 6);
            this._stdout.println(rpad(new StringBuffer().append(" ").append(formatStatsValue(localBigInteger3.longValue())).toString(), 7) + rpad(formatStatsValue(((float)localBigInteger3.longValue() / f)), 7) + rpad(formatStatsValue(((float)localBigInteger4.longValue() / f)), 7) + rpad(formatStatsValue(localBigInteger4.longValue() / localBigInteger3.longValue()), 7) + rpad(formatStatsValue(((float)localBigInteger5.longValue() / f)), 7) + rpad(formatStatsValue(localBigInteger5.longValue() / localBigInteger3.longValue()), 7) + rpad(formatStatsValue(localBigInteger7.longValue()), 7) + rpad(formatStatsValue(localBigInteger6.longValue() / localBigInteger3.longValue()), 7) + rpad(localSimpleDBRowCache.getItem(i1, 1).toString(), 16));
          }
          this._stdout.println();
        }
        if (localDBRowCache1 != null)
        {
          localHashtable.clear();
          for (i1 = 1; i1 < localDBRowCache1.getRowCount(); i1++) {
            localHashtable.put(localDBRowCache1.getItem(i1, 1), new Integer(i1));
          }
        }
      }
      localDBRowCache2 = localDBRowCache1;
      System.runFinalization();
      System.gc();
    }
  }
  
  private void procShowChild(String paramString)
  {
    if (!isConnected())
    {
      this._stdout.println("Database not connected!");
      return;
    }
    DBRowCache localDBRowCache = null;
    String str = skipWord(paramString, 1);
    str = str.trim();
    String[] arrayOfString = TextUtils.toStringArray(TextUtils.getWords(str, new String[] { "." }));
    if (arrayOfString.length == 0)
    {
      this._stdout.println("Table name required.");
      return;
    }
    VariableTable localVariableTable = new VariableTable();
    localVariableTable.add("P_OWNER", 12);
    localVariableTable.add("P_NAME", 12);
    if ((arrayOfString.length == 1) || (arrayOfString.length == 2))
    {
      if (arrayOfString.length == 1) {
        localVariableTable.setValue("P_NAME", arrayOfString[0].toUpperCase());
      }
      if (arrayOfString.length == 2)
      {
        localVariableTable.setValue("P_OWNER", arrayOfString[0].toUpperCase());
        localVariableTable.setValue("P_NAME", arrayOfString[1].toUpperCase());
      }
    }
    try
    {
      localDBRowCache = executeQuery(this.database, "SELECT /* AnySQL */ T.CONSTRAINT_NAME PKNAME, \n       R.OWNER||'.'||R.TABLE_NAME TNAME, \n       R.CONSTRAINT_NAME FKNAME \n  FROM ALL_CONSTRAINTS R, ALL_CONSTRAINTS T \n  WHERE T.CONSTRAINT_TYPE IN ('P','U') \n    AND R.R_OWNER = T.OWNER AND R.R_CONSTRAINT_NAME = T.CONSTRAINT_NAME \n    AND T.OWNER = NVL(:P_OWNER,USER) AND T.TABLE_NAME = :P_NAME", localVariableTable, 2000);
    }
    catch (SQLException localSQLException)
    {
      this._stdout.print(localSQLException);
      return;
    }
    if ((localDBRowCache == null) || (localDBRowCache.getRowCount() == 0))
    {
      this._stdout.println("Table " + str + " not exists or have no child table!");
      return;
    }
    showDBRowCache(localDBRowCache, true);
  }
  
  private void procShowConstraint(String paramString)
  {
    if (!isConnected())
    {
      this._stdout.println("Database not connected!");
      return;
    }
    DBRowCache localDBRowCache = null;
    String str1 = skipWord(paramString, 1);
    str1 = str1.trim();
    String[] arrayOfString = TextUtils.toStringArray(TextUtils.getWords(str1, new String[] { "." }));
    if (arrayOfString.length == 0)
    {
      this._stdout.println("Constraint name required.");
      return;
    }
    VariableTable localVariableTable = new VariableTable();
    localVariableTable.add("P_OWNER", 12);
    localVariableTable.add("P_NAME", 12);
    if ((arrayOfString.length == 1) || (arrayOfString.length == 2))
    {
      if (arrayOfString.length == 1) {
        localVariableTable.setValue("P_NAME", arrayOfString[0].toUpperCase());
      }
      if (arrayOfString.length == 2)
      {
        localVariableTable.setValue("P_OWNER", arrayOfString[0].toUpperCase());
        localVariableTable.setValue("P_NAME", arrayOfString[1].toUpperCase());
      }
    }
    try
    {
      localDBRowCache = executeQuery(this.database, "SELECT /* AnySQL */ \n  DECODE(CONSTRAINT_TYPE , \n\t'P','Primary Key', \n\t'R','Foreign Key', \n\t'U','Unique', \n\t'C','Check','Not Null') TYPE, \n\tTABLE_NAME,STATUS,VALIDATED \n FROM ALL_CONSTRAINTS \nWHERE OWNER = NVL(:P_OWNER,USER) AND CONSTRAINT_NAME = :P_NAME", localVariableTable, 2000);
    }
    catch (SQLException localSQLException1)
    {
      this._stdout.print(localSQLException1);
      return;
    }
    if ((localDBRowCache == null) || (localDBRowCache.getRowCount() == 0))
    {
      this._stdout.println("Constraint " + str1 + " not exists!");
      return;
    }
    showDBRowCache(localDBRowCache, true);
    String str2 = (String)localDBRowCache.getItem(1, 1);
    if ((str2.equals("Primary Key")) || (str2.equals("Unique")) || (str2.equals("Foreign Key"))) {
      try
      {
        localDBRowCache = executeQuery(this.database, "SELECT /* AnySQL */ \n  POSITION NO#,COLUMN_NAME \n FROM ALL_CONS_COLUMNS \nWHERE OWNER = NVL(:P_OWNER,USER) AND CONSTRAINT_NAME = :P_NAME", localVariableTable, 2000);
        if (localDBRowCache.getRowCount() > 0)
        {
          this._stdout.println();
          showDBRowCache(localDBRowCache, true);
        }
      }
      catch (SQLException localSQLException2)
      {
        this._stdout.print(localSQLException2);
        return;
      }
    } else {
      try
      {
        localDBRowCache = executeQuery(this.database, "SELECT /* AnySQL */ \n  SEARCH_CONDITION \n FROM ALL_CONSTRAINTS \nWHERE OWNER = NVL(:P_OWNER,USER) AND CONSTRAINT_NAME = :P_NAME", localVariableTable, 100);
        if (localDBRowCache.getRowCount() > 0)
        {
          this._stdout.println();
          showDBRowCache(localDBRowCache, false);
        }
      }
      catch (SQLException localSQLException3)
      {
        this._stdout.print(localSQLException3);
        return;
      }
    }
  }
  
  private void procShowSession(String paramString)
  {
    if (!isConnected())
    {
      this._stdout.println("Database not connected!");
      return;
    }
    try
    {
      DBRowCache localDBRowCache = executeQuery(this.database, "SELECT /* AnySQL */ /*+ ORDERED USE_NL(S,P) */\n    S.SADDR,P.SPID,S.SID,S.SERIAL#,S.USERNAME \n  FROM V$SESSION S,V$PROCESS P \n  WHERE S.PADDR=P.ADDR AND S.AUDSID = USERENV('SESSIONID')", this.sysvariable, 5000);
      showDBRowCache(localDBRowCache, true);
    }
    catch (SQLException localSQLException)
    {
      this._stdout.print(localSQLException);
    }
  }
  
  private void procOraFunction(String paramString)
  {
    DBRowCache localDBRowCache = null;
    int i = TextUtils.getWords(this._cmdtype.getDBCommand()[6]).size();
    String str1 = skipWord(paramString, i);
    String[] arrayOfString = TextUtils.toStringArray(TextUtils.getWords(str1));
    String str2 = null;
    if (arrayOfString.length == 0)
    {
      this._stdout.println("Usage: ");
      this._stdout.println("  ORA keyword [parameters]  ");
      this._stdout.println("  ------------------------------- -------------------------------- ");
      this._stdout.println("  PARAMETER   name                INITORA   name ");
      this._stdout.println("  SPID        spid                2PC   ");
      this._stdout.println("  ACTIVE                          SQL       sid ");
      this._stdout.println("  SORT                            SESSION   patterm ");
      this._stdout.println("  BGSESS                          DEAD  ");
      this._stdout.println("  TSFREE                          FILEFREE  tablespace ");
      this._stdout.println("  SEGMENT    size(MB)             EXTENT  ");
      this._stdout.println("  NOINDEX    size(MB)             INDEX     size(MB) ");
      this._stdout.println("  RBS                             LOCKWAIT");
      this._stdout.println("  TSBH                            OBJBH     percent ");
      this._stdout.println("  USERBH                          RECOVER ");
      this._stdout.println("  TRAN                            BUSY      sid ");
      this._stdout.println("  CHAIN      sid                  SGASTAT ");
      this._stdout.println("  PGA                             LIBCACHE ");
      this._stdout.println("  ROWCACHE                        SYSSTAT   name ");
      this._stdout.println("  WAITSTAT                        SYSEVENT   ");
      this._stdout.println("  TSSTAT                          FILESTAT  tablespace ");
      this._stdout.println("  SESSTAT    sid  name            SEGSTAT   user ");
      this._stdout.println("  BLOCK      file block           DDLLOCK ");
      this._stdout.println("  BACKUP                          LOGHIS ");
      this._stdout.println("  TOP{EXE|GETS|READ|GET} count    WAIT      sid");
      this._stdout.println("  LOCK       sid                  OBJECT    objid");
      this._stdout.println("  LONGOPS                         TABLESPACE");
      this._stdout.println("  DATAFILE   tablespace           ARCLOG    scn");
      this._stdout.println("  LATCHWAIT                       CURSOR    sid");
      this._stdout.println("  GLOBAL     username             MOVEIND   owner.table tsname");
      this._stdout.println("  MOVETAB    owner.table tsname   SHARE     count");
      this._stdout.println("  UNDO       name                 UNDOHDR   ");
      this._stdout.println("  _PARAMETER name                 CHARSET   name");
      this._stdout.println("  SQLMEM     count                HASH      sql_hash_value");
      this._stdout.println("  HOLD       object_id            ACTIVESQL");
      this._stdout.println("  BLOCKING                        PXSTAT");
      this._stdout.println("  PX                              PXSESS");
      this._stdout.println("  PXPROCESS                       PQSLAVE");
      this._stdout.println("  XPLAN      sql_hash_value       SQLLIKE   pattern");
      this._stdout.println("  WSQL                            PLAN      sql_hash_value");
      this._stdout.println("  MACHINE                         KILLMACHINE machine");
      this._stdout.println("  KILLUSER   username             HOT");
      this._stdout.println("  KILLSQL    username             KILLHOLD  object_id");
      this._stdout.println("  TSTAT      owner.table          ISTAT     owner.table");
      this._stdout.println("  SIZE       owner.table          UNUSABLE  username");
      this._stdout.println("  INVALID    username             FREESPACE tsname");
      this._stdout.println("  FILEOBJ    tsname count         RESIZE    tsname");
      this._stdout.println("  NOLOGGING  username             OBJSQL    owner.object_name");
      this._stdout.println("  SPTOPSQL   days h1 h2 rows      SPSQL     hash days h1 h2");
      this._stdout.println("  SPSTAT     day1 day2  h1 h2     OBJGRANT  owner.object_name");
      return;
    }
    if (!isConnected())
    {
      this._stdout.println("Database not connected!");
      return;
    }
    int j = TextUtils.indexOf(this.oracle_ora_function, arrayOfString[0]);
    if (j == -1) {
      try
      {
        FileReader localFileReader = new FileReader("scripts" + JavaVM.FILE_SEPERATOR + arrayOfString[0].toLowerCase() + ".sql");
        char[] arrayOfChar = new char[65536];
        int m = localFileReader.read(arrayOfChar);
        str2 = String.valueOf(arrayOfChar, 0, m);
        localFileReader.close();
      }
      catch (IOException localIOException)
      {
        this._stdout.println("Invalid keyword " + arrayOfString[0] + " specified.");
        return;
      }
    } else {
      str2 = OracleORAFunction.getORASQL(j);
    }
    VariableTable localVariableTable = new VariableTable();
    localVariableTable.add("V1", 12);
    for (int k = 1; k < arrayOfString.length; k++)
    {
      localVariableTable.add("V" + k, 12);
      localVariableTable.setValue("V" + k, arrayOfString[k]);
      Object[] arrayOfObject = TextUtils.getFields(arrayOfString[k], ".").toArray();
      if (arrayOfObject.length > 1)
      {
        localVariableTable.add("V" + k + "_OWNER", 12);
        localVariableTable.setValue("V" + k + "_OWNER", arrayOfObject[0].toString());
        localVariableTable.add("V" + k + "_NAME", 12);
        localVariableTable.setValue("V" + k + "_NAME", arrayOfObject[1].toString());
      }
      else
      {
        localVariableTable.add("V" + k + "_OWNER", 12);
        localVariableTable.add("V" + k + "_NAME", 12);
        localVariableTable.setValue("V" + k + "_NAME", arrayOfObject[0].toString());
      }
    }
    if (str2 != null)
    {
      int n;
      String str3;
      if ((j == 5) || (j == 63)) {
        try
        {
          localDBRowCache = executeQuery(this.database, str2, localVariableTable, 5000);
          if (localDBRowCache.getRowCount() > 0)
          {
            StringBuffer localStringBuffer1 = new StringBuffer();
            for (n = 1; n <= localDBRowCache.getRowCount(); n++)
            {
              str3 = (String)localDBRowCache.getItem(n, 1);
              localStringBuffer1.append(str3);
              if (str3.getBytes().length < 64) {
                localStringBuffer1.append("\n");
              }
            }
            this._stdout.println(localStringBuffer1.toString().trim());
          }
          else
          {
            this._stdout.println("Invalid SQL address specified.");
          }
        }
        catch (SQLException localSQLException1)
        {
          this._stdout.print(localSQLException1);
        }
      } else if (j == 72) {
        try
        {
          localDBRowCache = executeQuery(this.database, str2, localVariableTable, 5000);
          if (localDBRowCache.getRowCount() > 0)
          {
            StringBuffer localStringBuffer2 = new StringBuffer();
            for (n = 1; n <= localDBRowCache.getRowCount(); n++)
            {
              str3 = (String)localDBRowCache.getItem(n, 1);
              localStringBuffer2.append(str3);
              if (str3.getBytes().length < 64) {
                localStringBuffer2.append("\n");
              }
            }
            this._stdout.println(localStringBuffer2.toString().trim());
            this._stdout.println();
            localDBRowCache = getExplainPlan(localStringBuffer2.toString());
            if (localDBRowCache != null) {
              showDBRowCache(localDBRowCache, true);
            }
          }
          else
          {
            this._stdout.println("Invalid SQL address specified.");
          }
        }
        catch (SQLException localSQLException2)
        {
          this._stdout.print(localSQLException2);
        }
      } else {
        executeSQL(this.database, new Command(0, 7, str2), localVariableTable, this._stdout);
      }
    }
  }
  
  private void procList(String paramString)
  {
    if (!isConnected())
    {
      this._stdout.println("Database not connected!");
      return;
    }
    Object localObject = null;
    int i = TextUtils.getWords(this._cmdtype.getDBCommand()[4]).size();
    String str = skipWord(paramString, i);
    String[] arrayOfString1 = TextUtils.toStringArray(TextUtils.getWords(str));
    if (arrayOfString1.length == 0)
    {
      this._stdout.println("Usage: LIST type pattern");
      this._stdout.println();
      this._stdout.println("TYPE   :");
      this._stdout.println("  OBJECT CLUSTER INDEX SEQUENCE SYNONYM TABLE TRIGGER");
      this._stdout.println("  TYPE VIEW MVIEW TABPART INDPART SEGMENT REBUILD LOB QUEUE");
      this._stdout.println("PATTERN:");
      this._stdout.println("  user.name ('_' as any one char, '%' as any string)");
      return;
    }
    int j = TextUtils.indexOf(this.oracle_list_type, arrayOfString1[0]);
    if (j == -1)
    {
      this._stdout.println("Invalid type " + arrayOfString1[0] + " specified.");
      return;
    }
    VariableTable localVariableTable = new VariableTable();
    localVariableTable.add("P_OWNER", 12);
    localVariableTable.add("P_NAME", 12);
    localVariableTable.add("P_TYPE", 12);
    localVariableTable.setValue("P_NAME", "%");
    if (arrayOfString1.length > 1)
    {
      String[] arrayOfString2 = TextUtils.toStringArray(TextUtils.getWords(arrayOfString1[1], new String[] { "." }));
      if (arrayOfString2.length > 1)
      {
        localVariableTable.setValue("P_OWNER", arrayOfString2[0].toUpperCase());
        localVariableTable.setValue("P_NAME", arrayOfString2[1].toUpperCase());
      }
      else if (arrayOfString2.length > 0)
      {
        localVariableTable.setValue("P_NAME", arrayOfString2[0].toUpperCase());
      }
    }
    switch (j)
    {
    case 0: 
      executeSQL(this.database, new Command(0, 7, "SELECT /* AnySQL */ OBJECT_TYPE TYPE,OBJECT_ID ID,OWNER,OBJECT_NAME, \n      TO_CHAR(CREATED,'YYYY/MM/DD') CREATED, \n      TO_CHAR(LAST_DDL_TIME,'YYYY/MM/DD HH24:MI:SS') MODIFIED,STATUS \n  FROM ALL_OBJECTS \n  WHERE OBJECT_TYPE IN ('CLUSTER','FUNCTION','INDEX',\n       'PACKAGE','PROCEDURE','SEQUENCE','SYNONYM',\n       'TABLE','TRIGGER','TYPE','VIEW') \n    AND (:P_OWNER IS NULL OR UPPER(OWNER) = :P_OWNER) \n    AND OBJECT_NAME LIKE :P_NAME"), localVariableTable, this._stdout);
      break;
    case 1: 
      executeSQL(this.database, new Command(0, 7, "SELECT /* AnySQL */ OWNER,CLUSTER_NAME,CLUSTER_TYPE TYPE, \n   TABLESPACE_NAME TS_NAME,KEY_SIZE KSIZE,HASHKEYS KEYS, \n   INITIAL_EXTENT/1024 INI_K, NEXT_EXTENT/1024 NEXT_K, MAX_EXTENTS MAXEXT,PCT_INCREASE PCT\n   PCT_INCREASE PCTINC,SINGLE_TABLE SIGTBL \n  FROM ALL_CLUSTERS \n  WHERE (:P_OWNER IS NULL OR UPPER(OWNER) = :P_OWNER) \n    AND CLUSTER_NAME LIKE :P_NAME"), localVariableTable, this._stdout);
      break;
    case 2: 
      executeSQL(this.database, new Command(0, 7, "SELECT /* AnySQL */ OWNER,INDEX_NAME,INDEX_TYPE TYPE, \n   TABLESPACE_NAME TS_NAME,\n   UNIQUENESS UK,INITIAL_EXTENT/1024 INI_K, NEXT_EXTENT/1024 NEXT_K,PCT_INCREASE PCT,\n   STATUS,PARTITIONED PART,\n   TO_CHAR(LAST_ANALYZED,'YYYY/MM/DD') ANA_DATE, FREELISTS FLS, FREELIST_GROUPS FLGS \n  FROM ALL_INDEXES \n  WHERE (:P_OWNER IS NULL OR UPPER(OWNER) = :P_OWNER) \n    AND INDEX_NAME LIKE :P_NAME"), localVariableTable, this._stdout);
      break;
    case 3: 
      executeSQL(this.database, new Command(0, 7, "SELECT /* AnySQL */ SEQUENCE_OWNER OWNER,SEQUENCE_NAME, \n   MIN_VALUE LOW,MAX_VALUE HIGH,INCREMENT_BY STEP,CYCLE_FLAG CYC,\n   ORDER_FLAG ORD,CACHE_SIZE CACHE,LAST_NUMBER CURVAL\n  FROM ALL_SEQUENCES \n  WHERE (:P_OWNER IS NULL OR UPPER(SEQUENCE_OWNER) = :P_OWNER) \n    AND SEQUENCE_NAME LIKE :P_NAME"), localVariableTable, this._stdout);
      break;
    case 4: 
      executeSQL(this.database, new Command(0, 7, "SELECT /* AnySQL */ * \n  FROM ALL_SYNONYMS \n  WHERE (:P_OWNER IS NULL OR OWNER = :P_OWNER) \n    AND SYNONYM_NAME LIKE :P_NAME"), localVariableTable, this._stdout);
      break;
    case 5: 
      executeSQL(this.database, new Command(0, 7, "SELECT /* AnySQL */ OWNER,TABLE_NAME, \n   TABLESPACE_NAME TS_NAME,\n   INITIAL_EXTENT/1024 INI_K, NEXT_EXTENT/1024 NEXT_K,PCT_INCREASE PCT,\n   PARTITIONED PART,IOT_TYPE IOT,TO_CHAR(LAST_ANALYZED,'YYYY/MM/DD') ANA_DATE,\n   DECODE(CLUSTER_NAME,NULL,NULL,CLUSTER_OWNER||'.'||CLUSTER_NAME) CNAME,NESTED, \n   FREELISTS FLS, FREELIST_GROUPS FLGS \n  FROM ALL_TABLES \n  WHERE (:P_OWNER IS NULL OR UPPER(OWNER) = :P_OWNER) \n    AND TABLE_NAME LIKE :P_NAME"), localVariableTable, this._stdout);
      break;
    case 6: 
      executeSQL(this.database, new Command(0, 7, "SELECT /* AnySQL */ OWNER,TRIGGER_NAME,\n     TABLE_OWNER||'.'||TABLE_NAME TABLE_NAME,STATUS,\n     TRIGGER_TYPE TYPE,TRIGGERING_EVENT EVENT\n  FROM ALL_TRIGGERS \n  WHERE (:P_OWNER IS NULL OR UPPER(OWNER) = :P_OWNER) \n    AND TRIGGER_NAME LIKE :P_NAME"), localVariableTable, this._stdout);
      break;
    case 7: 
      executeSQL(this.database, new Command(0, 7, "SELECT /* AnySQL */ OWNER,TYPE_NAME,TYPECODE TYPE,PREDEFINED,INCOMPLETE \n  FROM ALL_TYPES \n  WHERE (:P_OWNER IS NULL OR UPPER(OWNER) = :P_OWNER) \n    AND TYPE_NAME LIKE :P_NAME AND OWNER IS NOT NULL"), localVariableTable, this._stdout);
      break;
    case 8: 
      executeSQL(this.database, new Command(0, 7, "SELECT /* AnySQL */ OWNER,VIEW_NAME, \n   DECODE(VIEW_TYPE_OWNER,NULL,NULL,VIEW_TYPE_OWNER||'.'||VIEW_TYPE) TYPE_NAME\n  FROM ALL_VIEWS \n  WHERE (:P_OWNER IS NULL OR UPPER(OWNER) = :P_OWNER) \n    AND VIEW_NAME LIKE :P_NAME"), localVariableTable, this._stdout);
      break;
    case 9: 
      executeSQL(this.database, new Command(0, 7, "SELECT /* AnySQL */ OWNER,MVIEW_NAME,CONTAINER_NAME TABLE_NAME, \n   UPDATABLE UPD,REWRITE_ENABLED REWRITE,REFRESH_MODE||' '||REFRESH_METHOD REFRESH,\n   STALENESS,FAST_REFRESHABLE FASTABLE \n  FROM ALL_MVIEWS \n  WHERE (:P_OWNER IS NULL OR UPPER(OWNER) = :P_OWNER) \n    AND MVIEW_NAME LIKE :P_NAME"), localVariableTable, this._stdout);
      break;
    case 10: 
      executeSQL(this.database, new Command(0, 7, "SELECT /* AnySQL */ PARTITION_POSITION NO#,PARTITION_NAME,TABLESPACE_NAME TS_NAME, \n   HIGH_VALUE,INITIAL_EXTENT/1024 INI_K, NEXT_EXTENT/1024 NEXT_K,PCT_INCREASE PCT, \n   FREELISTS FLS, FREELIST_GROUPS FLGS \n  FROM ALL_TAB_PARTITIONS \n  WHERE UPPER(TABLE_OWNER) = NVL(:P_OWNER,USER) \n    AND TABLE_NAME LIKE :P_NAME \n  ORDER BY 1 "), localVariableTable, this._stdout);
      break;
    case 11: 
      executeSQL(this.database, new Command(0, 7, "SELECT /* AnySQL */ PARTITION_POSITION NO#,PARTITION_NAME,TABLESPACE_NAME TS_NAME, \n   HIGH_VALUE,INITIAL_EXTENT/1024 INI_K, NEXT_EXTENT/1024 NEXT_K,PCT_INCREASE PCT, \n   FREELISTS FLS, FREELIST_GROUPS FLGS \n  FROM ALL_IND_PARTITIONS \n  WHERE UPPER(INDEX_OWNER) = NVL(:P_OWNER,USER) \n    AND INDEX_NAME LIKE :P_NAME \n  ORDER BY 1 "), localVariableTable, this._stdout);
      break;
    case 15: 
      executeSQL(this.database, new Command(0, 7, "SELECT /* AnySQL */ OWNER,SEGMENT_NAME SEG_NAME,PARTITION_NAME SUB_NAME, \n   SEGMENT_TYPE SEG_TYPE,TABLESPACE_NAME TS_NAME,TRUNC(BYTES/1024) SIZE_KB,\n   INITIAL_EXTENT/1024 INI_K, NEXT_EXTENT/1024 NEXT_K,PCT_INCREASE PCT,EXTENTS EXTS\n  FROM DBA_SEGMENTS \n  WHERE UPPER(OWNER) = NVL(:P_OWNER,USER) \n    AND SEGMENT_NAME LIKE :P_NAME"), localVariableTable, this._stdout);
      break;
    case 16: 
      executeSQL(this.database, new Command(0, 7, "SELECT /* AnySQL */ /*+ RULE */  \n    I.OWNER,I.INDEX_NAME,P.PARTITION_NAME,I.INDEX_TYPE,  \n    DECODE(I.PARTITIONED,'YES',P.TABLESPACE_NAME,I.TABLESPACE_NAME) TS_NAME,  \n    DECODE(I.PARTITIONED,'YES',P.STATUS,I.STATUS) STATUS \n FROM ALL_INDEXES I, ALL_IND_PARTITIONS P \n WHERE I.OWNER=P.INDEX_OWNER(+) AND I.INDEX_NAME=P.INDEX_NAME(+) \n   AND UPPER(I.TABLE_OWNER)=NVL(:P_OWNER,USER) AND I.TABLE_NAME LIKE :P_NAME \n    AND I.STATUS<>'VALID' AND NVL(P.STATUS,'UNUSABLE') <> 'USABLE'"), localVariableTable, this._stdout);
      break;
    case 18: 
      executeSQL(this.database, new Command(0, 7, "SELECT /* AnySQL */ /*+ RULE */  \n    OWNER,NAME QNAME,QUEUE_TYPE QTYPE,QUEUE_TABLE TNAME,  \n    ENQUEUE_ENABLED ENQABLE,DEQUEUE_ENABLED DEQABLE,RETENTION \n FROM ALL_QUEUES \n WHERE (:P_OWNER IS NULL OR UPPER(OWNER)=:P_OWNER) AND NAME LIKE :P_NAME"), localVariableTable, this._stdout);
      break;
    case 17: 
      executeSQL(this.database, new Command(0, 7, "SELECT /* AnySQL */ /*+ RULE */  \n    OWNER,TABLE_NAME TNAME,COLUMN_NAME COL,SEGMENT_NAME,INDEX_NAME,PCTVERSION PCT, RETENTION RET, CHUNK, CACHE, LOGGING LOG, IN_ROW  \n FROM ALL_LOBS \n WHERE UPPER(OWNER)=NVL(:P_OWNER,USER) AND TABLE_NAME LIKE :P_NAME||'%' "), localVariableTable, this._stdout);
      break;
    case 19: 
      executeSQL(this.database, new Command(0, 7, "SELECT /* AnySQL */ \n    TABLE_NAME TNAME,COLUMN_NAME COL,  \n    PARTITION_NAME PNAME,LOB_PARTITION_NAME LPNAME,  \n    INITIAL_EXTENT/1024 INIEXT, NEXT_EXTENT/1024 NXTEXT, \n    PCT_INCREASE PCT, FREELISTS FLS  \n FROM ALL_LOB_PARTITIONS \n WHERE UPPER(TABLE_OWNER)=:P_OWNER AND LOB_NAME=:P_NAME ORDER BY 3"), localVariableTable, this._stdout);
      break;
    case 12: 
    case 13: 
    case 14: 
    default: 
      localVariableTable.setValue("P_TYPE", arrayOfString1[0].toUpperCase());
      executeSQL(this.database, new Command(0, 7, "SELECT /* AnySQL */ OBJECT_TYPE TYPE,OBJECT_ID ID,OWNER,OBJECT_NAME, \n      TO_CHAR(CREATED,'YYYY/MM/DD') CREATED, \n      TO_CHAR(LAST_DDL_TIME,'YYYY/MM/DD') MODIFIED,STATUS \n  FROM ALL_OBJECTS \n  WHERE OBJECT_TYPE = :P_TYPE \n    AND (:P_OWNER IS NULL OR UPPER(OWNER) = :P_OWNER) \n    AND OBJECT_NAME LIKE :P_NAME"), localVariableTable, this._stdout);
    }
  }
  
  private void procDepend(String paramString)
  {
    if (!isConnected())
    {
      this._stdout.println("Database not connected!");
      return;
    }
    DBRowCache localDBRowCache = null;
    int i = TextUtils.getWords(this._cmdtype.getDBCommand()[5]).size();
    String str = skipWord(paramString, i);
    str = str.trim();
    String[] arrayOfString = TextUtils.toStringArray(TextUtils.getWords(str, new String[] { "." }));
    if (arrayOfString.length == 0)
    {
      this._stdout.println("Object name pattern required.");
      return;
    }
    VariableTable localVariableTable = new VariableTable();
    localVariableTable.add("P_OWNER", 12);
    localVariableTable.add("P_NAME", 12);
    if ((arrayOfString.length == 1) || (arrayOfString.length == 2))
    {
      if (arrayOfString.length == 1) {
        localVariableTable.setValue("P_NAME", arrayOfString[0].toUpperCase());
      }
      if (arrayOfString.length == 2)
      {
        localVariableTable.setValue("P_OWNER", arrayOfString[0].toUpperCase());
        localVariableTable.setValue("P_NAME", arrayOfString[1].toUpperCase());
      }
    }
    try
    {
      localDBRowCache = executeQuery(this.database, "SELECT /* AnySQL */ TYPE,REFERENCED_OWNER D_OWNER, \n      REFERENCED_NAME D_NAME,REFERENCED_TYPE D_TYPE, \n      REFERENCED_LINK_NAME DBLINK, DEPENDENCY_TYPE DEPEND\n  FROM ALL_DEPENDENCIES \n  WHERE \n    UPPER(OWNER) = NVL(:P_OWNER,USER) \n    AND NAME  = :P_NAME", localVariableTable, 2000);
      if (localDBRowCache.getRowCount() >= 0)
      {
        this._stdout.println("Reference:");
        showDBRowCache(localDBRowCache, true);
        this._stdout.println();
      }
      else
      {
        this._stdout.println("No dependency founded for " + str + ".");
      }
    }
    catch (SQLException localSQLException1)
    {
      this._stdout.print(localSQLException1);
    }
    try
    {
      localDBRowCache = executeQuery(this.database, "SELECT /* AnySQL */  REFERENCED_TYPE TYPE,OWNER R_OWNER,\n       NAME R_NAME, TYPE R_TYPE,DEPENDENCY_TYPE DEPEND \n  FROM ALL_DEPENDENCIES \n  WHERE \n    UPPER(REFERENCED_OWNER) = NVL(:P_OWNER,USER) \n    AND REFERENCED_NAME  = :P_NAME AND REFERENCED_LINK_NAME IS NULL", localVariableTable, 2000);
      if (localDBRowCache.getRowCount() >= 0)
      {
        this._stdout.println("Referenced By:");
        showDBRowCache(localDBRowCache, true);
      }
      else
      {
        this._stdout.println("No dependency founded for " + str + ".");
      }
    }
    catch (SQLException localSQLException2)
    {
      this._stdout.print(localSQLException2);
    }
  }
  
  private void procVariable(String paramString)
  {
    String str1 = "%";
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[9]).size();
    String str2 = skipWord(paramString, i);
    String[] arrayOfString = TextUtils.toStringArray(TextUtils.getWords(str2));
    if (arrayOfString.length < 2)
    {
      this._stdout.println("Usage:");
      this._stdout.println("  VAR varname vartype");
      this._stdout.println("");
      this._stdout.println("  CHAR VARCHAR LONGVARCHAR BINARY VARBINARY LONGVARBINARY");
      this._stdout.println("  NUMERIC DECIMAL BIT TINYINT SMALLINT INTEGER BIGINT REAL");
      this._stdout.println("  FLOAT DOUBLE DATE TIME TIMESTAMP BLOB CLOB");
      return;
    }
    if (this.sysvariable.exists(arrayOfString[0]))
    {
      this._stdout.println("Variable " + arrayOfString[0] + " already defined.");
      return;
    }
    this.sysvariable.add(arrayOfString[0], SQLTypes.getTypeID(arrayOfString[1]));
  }
  
  private void procUnvariable(String paramString)
  {
    String str1 = "%";
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[10]).size();
    String str2 = skipWord(paramString, i);
    String[] arrayOfString = TextUtils.toStringArray(TextUtils.getWords(str2));
    if (arrayOfString.length == 0)
    {
      this._stdout.println("Usage: UNVAR varname");
      return;
    }
    if (!this.sysvariable.exists(arrayOfString[0]))
    {
      this._stdout.println("Variable " + arrayOfString[0] + " not exist.");
      return;
    }
    this.sysvariable.remove(arrayOfString[0]);
  }
  
  private void procPrint(String paramString)
  {
    String str1 = "%";
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[11]).size();
    String str2 = skipWord(paramString, i);
    this._stdout.println(this.sysvariable.parseString(str2));
  }
  
  private void procShowSpace(String paramString)
  {
    if (!isConnected())
    {
      this._stdout.println("Database not connected.");
      return;
    }
    VariableTable localVariableTable1 = new VariableTable();
    localVariableTable1.add("P_OWNER", 12);
    localVariableTable1.add("P_NAME", 12);
    localVariableTable1.add("P_LIMIT", 4);
    int j = TextUtils.getWords(this.oracle_show_keys[8]).size();
    String str = skipWord(paramString, j);
    String[] arrayOfString = TextUtils.toStringArray(TextUtils.getWords(str, new String[] { "." }));
    if (arrayOfString.length == 0)
    {
      this._stdout.println("Usage: SHOW SPACE user.pattern");
      return;
    }
    if (arrayOfString.length > 1)
    {
      localVariableTable1.setValue("P_OWNER", arrayOfString[0].toUpperCase());
      localVariableTable1.setValue("P_NAME", arrayOfString[1].toUpperCase());
    }
    else
    {
      localVariableTable1.setValue("P_NAME", arrayOfString[0].toUpperCase());
    }
    localVariableTable1.setValue("P_LIMIT", String.valueOf(this.scan_limit));
    DBRowCache localDBRowCache = null;
    SQLCallable localSQLCallable1 = null;
    SQLCallable localSQLCallable2 = null;
    try
    {
      localDBRowCache = executeQuery(this.database, "SELECT OWNER,SEGMENT_NAME,PARTITION_NAME,SEGMENT_TYPE\n  FROM DBA_SEGMENTS \n  WHERE UPPER(OWNER)=NVL(:P_OWNER,USER) AND SEGMENT_NAME LIKE :P_NAME \n    AND SEGMENT_TYPE IN ('TABLE','INDEX','CLUSTER',\n          'TABLE PARTITION','INDEX PARTITION',\n          'TABLE SUBPARTITION','INDEX SUBPARTITION','LOB') \n  ORDER BY 1,4,2,3", localVariableTable1, 1000);
    }
    catch (SQLException localSQLException1)
    {
      this._stdout.print(localSQLException1);
      return;
    }
    SimpleDBRowCache localSimpleDBRowCache = new SimpleDBRowCache();
    localSimpleDBRowCache.addColumn("OWNER", 12);
    localSimpleDBRowCache.addColumn("SEG_NAME", 12);
    localSimpleDBRowCache.addColumn("SUB_NAME", 12);
    localSimpleDBRowCache.addColumn("SEG_TYPE", 12);
    localSimpleDBRowCache.addColumn("FLG0", -5);
    localSimpleDBRowCache.addColumn("BLKS", -5);
    localSimpleDBRowCache.addColumn("BYTES", -5);
    localSimpleDBRowCache.addColumn("UBLKS", -5);
    localSimpleDBRowCache.addColumn("UBYTES", -5);
    localSimpleDBRowCache.addColumn("FID", -5);
    localSimpleDBRowCache.addColumn("BID", -5);
    localSimpleDBRowCache.addColumn("OFF", -5);
    VariableTable localVariableTable2 = new VariableTable();
    localVariableTable2.add("OWNER", 12);
    localVariableTable2.add("SEG_NAME", 12);
    localVariableTable2.add("SUB_NAME", 12);
    localVariableTable2.add("SEG_TYPE", 12);
    localVariableTable2.add("FLG0", -5);
    localVariableTable2.add("BLKS", -5);
    localVariableTable2.add("BYTES", -5);
    localVariableTable2.add("UBLKS", -5);
    localVariableTable2.add("UBYTES", -5);
    localVariableTable2.add("FID", -5);
    localVariableTable2.add("BID", -5);
    localVariableTable2.add("OFF", -5);
    localVariableTable2.add("P_LIMIT", 4);
    localVariableTable2.setValue("P_LIMIT", String.valueOf(this.scan_limit));
    try
    {
      localSQLCallable1 = prepareCall(this.database, "DBMS_SPACE.FREE_BLOCKS(SEGMENT_OWNER => :OWNER,\n    SEGMENT_NAME => :SEG_NAME,SEGMENT_TYPE => :SEG_TYPE,\n    PARTITION_NAME => :SUB_NAME,FREELIST_GROUP_ID => 0,\n    FREE_BLKS => :FLG0 OUT,SCAN_LIMIT=>:P_LIMIT)", localVariableTable2);
      localSQLCallable2 = prepareCall(this.database, "DBMS_SPACE.UNUSED_SPACE(SEGMENT_OWNER => :OWNER,\n    SEGMENT_NAME => :SEG_NAME,SEGMENT_TYPE => :SEG_TYPE,\n    PARTITION_NAME=>:SUB_NAME,TOTAL_BLOCKS => :BLKS OUT,\n    TOTAL_BYTES => :BYTES OUT,UNUSED_BLOCKS => :UBLKS OUT,\n    UNUSED_BYTES => :UBYTES OUT,LAST_USED_EXTENT_FILE_ID => :FID OUT,\n    LAST_USED_EXTENT_BLOCK_ID => :BID OUT,LAST_USED_BLOCK => :OFF OUT)", localVariableTable2);
    }
    catch (SQLException localSQLException2)
    {
      this._stdout.print(localSQLException2);
      return;
    }
    for (int k = 1; k <= localDBRowCache.getRowCount(); k++)
    {
      localVariableTable2.setValue("OWNER", localDBRowCache.getItem(k, 1));
      localVariableTable2.setValue("SEG_NAME", localDBRowCache.getItem(k, 2));
      localVariableTable2.setValue("SUB_NAME", localDBRowCache.getItem(k, 3));
      localVariableTable2.setValue("SEG_TYPE", localDBRowCache.getItem(k, 4));
      try
      {
        localSQLCallable1.bind(localVariableTable2);
        localSQLCallable1.stmt.execute();
        localSQLCallable1.fetch(localVariableTable2);
        localSQLCallable2.bind(localVariableTable2);
        localSQLCallable2.stmt.execute();
        localSQLCallable2.fetch(localVariableTable2);
        int i = localSimpleDBRowCache.appendRow();
        for (int m = 1; m <= localSimpleDBRowCache.getColumnCount(); m++) {
          localSimpleDBRowCache.setItem(i, m, localVariableTable2.getValue(localSimpleDBRowCache.getColumnName(m)));
        }
      }
      catch (SQLException localSQLException4)
      {
        this._stdout.print(localSQLException4);
      }
    }
    try
    {
      localSQLCallable1.close();
      localSQLCallable2.close();
    }
    catch (SQLException localSQLException3)
    {
      this._stdout.print(localSQLException3);
    }
    this._stdout.print(localSimpleDBRowCache);
  }
  
  protected void procDisabledCommand(Command paramCommand)
  {
    this._stdout.println("Query Only mode, DML/DDL/Script disabled.!");
  }
  
  protected void procUnknownCommand(Command paramCommand)
  {
    this._stdout.println("Unknown command!");
  }
  
  private void procCross(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLMultiple()[2]).size();
    String str = skipWord(paramString, i);
    if (!isConnected())
    {
      this._stdout.println("Database not connected.");
      return;
    }
    try
    {
      DBRowCache localDBRowCache = DBOperation.crossQuery(this.database, str, this.sysvariable);
      if (localDBRowCache.getColumnCount() > 0)
      {
        localDBRowCache.getWidth(false);
        this._stdout.print(localDBRowCache);
      }
      else
      {
        this._stdout.println("Cross query SQL should return three columns!");
      }
    }
    catch (SQLException localSQLException)
    {
      this._stdout.print(localSQLException);
    }
  }
  
  private void procExplainPlan(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLMultiple()[4]).size();
    String str = skipWord(paramString, i);
    if (!isConnected())
    {
      this._stdout.println("Database not connected.");
      return;
    }
    DBRowCache localDBRowCache = getExplainPlan(str);
    if ((localDBRowCache != null) && (localDBRowCache.getRowCount() > 0)) {
      showDBRowCache(localDBRowCache, true);
    }
  }
  
  public final void procExplainMView(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLMultiple()[8]).size();
    VariableTable localVariableTable = new VariableTable();
    String str1 = skipWord(paramString, i);
    String str2 = "P" + Math.random();
    DBRowCache localDBRowCache = null;
    SQLStatement localSQLStatement = null;
    SQLCallable localSQLCallable = null;
    if (!isConnected())
    {
      this._stdout.println("Database not connected.");
      return;
    }
    try
    {
      localVariableTable.add("PLAN_STMT_ID", 12);
      localVariableTable.setValue("PLAN_STMT_ID", str2);
      localVariableTable.add("PLAN_STMT_SQL", 12);
      localVariableTable.setValue("PLAN_STMT_SQL", str1);
      localSQLStatement = prepareStatement(this.database, "DELETE FROM MV_CAPABILITIES_TABLE WHERE STATEMENT_ID = :PLAN_STMT_ID", this.sysvariable);
      if (localSQLStatement != null)
      {
        localSQLStatement.bind(localVariableTable);
        localSQLStatement.stmt.execute();
      }
      localSQLCallable = prepareCall(this.database, "DBMS_MVIEW.EXPLAIN_MVIEW(MV=>:PLAN_STMT_SQL,STMT_ID=>:PLAN_STMT_ID)", localVariableTable);
      localSQLCallable.bind(localVariableTable);
      localSQLCallable.stmt.execute();
      localDBRowCache = executeQuery(this.database, "select seq,CAPABILITY_NAME,POSSIBLE Y,MSGTXT from MV_CAPABILITIES_TABLE WHERE STATEMENT_ID = :PLAN_STMT_ID order by seq", localVariableTable);
      showDBRowCache(localDBRowCache, true);
      localSQLCallable.close();
      if (localSQLStatement != null)
      {
        localSQLStatement.bind(localVariableTable);
        localSQLStatement.stmt.execute();
      }
      localSQLStatement.close();
      this.database.commit();
    }
    catch (SQLException localSQLException1)
    {
      this._stdout.print(localSQLException1);
    }
    try
    {
      if (localSQLStatement != null) {
        localSQLStatement.close();
      }
    }
    catch (SQLException localSQLException2) {}
    try
    {
      if (localSQLCallable != null) {
        localSQLCallable.close();
      }
    }
    catch (SQLException localSQLException3) {}
  }
  
  public final void procExplainRewrite(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLMultiple()[9]).size();
    VariableTable localVariableTable = new VariableTable();
    String str1 = skipWord(paramString, i);
    String str2 = "P" + Math.random();
    DBRowCache localDBRowCache = null;
    SQLStatement localSQLStatement = null;
    SQLCallable localSQLCallable = null;
    if (!isConnected())
    {
      this._stdout.println("Database not connected.");
      return;
    }
    try
    {
      localVariableTable.add("PLAN_STMT_ID", 12);
      localVariableTable.setValue("PLAN_STMT_ID", str2);
      localVariableTable.add("PLAN_STMT_SQL", 12);
      localVariableTable.setValue("PLAN_STMT_SQL", str1);
      localSQLStatement = prepareStatement(this.database, "DELETE FROM REWRITE_TABLE WHERE STATEMENT_ID = :PLAN_STMT_ID", this.sysvariable);
      if (localSQLStatement != null)
      {
        localSQLStatement.bind(localVariableTable);
        localSQLStatement.stmt.execute();
      }
      localSQLCallable = prepareCall(this.database, "DBMS_MVIEW.EXPLAIN_REWRITE(QUERY=>:PLAN_STMT_SQL,STATEMENT_ID=>:PLAN_STMT_ID)", localVariableTable);
      localSQLCallable.bind(localVariableTable);
      localSQLCallable.stmt.execute();
      localDBRowCache = executeQuery(this.database, "select MESSAGE from REWRITE_TABLE WHERE STATEMENT_ID = :PLAN_STMT_ID", localVariableTable);
      showDBRowCache(localDBRowCache, true);
      localSQLCallable.close();
      if (localSQLStatement != null)
      {
        localSQLStatement.bind(localVariableTable);
        localSQLStatement.stmt.execute();
      }
      localSQLStatement.close();
      this.database.commit();
    }
    catch (SQLException localSQLException1)
    {
      this._stdout.print(localSQLException1);
    }
    try
    {
      if (localSQLStatement != null) {
        localSQLStatement.close();
      }
    }
    catch (SQLException localSQLException2) {}
    try
    {
      if (localSQLCallable != null) {
        localSQLCallable.close();
      }
    }
    catch (SQLException localSQLException3) {}
  }
  
  private void procLOB(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLMultiple()[0]).size();
    String str1 = skipWord(paramString, i);
    String str2 = null;
    String str3 = null;
    int j = str1.indexOf("<<");
    if (j >= 0)
    {
      str3 = str1.substring(0, j).trim();
      str2 = str1.substring(j + 2).trim();
      procLOBWRITE(str3, str2);
    }
    else
    {
      j = str1.indexOf(">>");
      if (j >= 0)
      {
        str3 = str1.substring(0, j).trim();
        str2 = str1.substring(j + 2).trim();
        procLOBREAD(str3, str2);
      }
      else
      {
        this._stdout.println("Usage:");
        this._stdout.println("  LOB query >> file");
        this._stdout.println("  LOB query << file");
        this._stdout.println("Note :");
        this._stdout.println("  >> mean export long/long raw/blob/clob to a file ");
        this._stdout.println("  << mean import a file to blob/clob field, the query");
        this._stdout.println("     should include the for update clause");
      }
    }
  }
  
  private void procLoad(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLMultiple()[7]).size();
    String str1 = skipWord(paramString, i);
    OptionCommand localOptionCommand = new OptionCommand(str1);
    str1 = localOptionCommand.getCommand();
    String str2 = localOptionCommand.getOption("F", "|");
    int j = localOptionCommand.getInt("S", 0);
    String str3 = null;
    String str4 = null;
    if (!isConnected())
    {
      this._stdout.println("Database not connected.");
      return;
    }
    if (j < 0) {
      j = 0;
    }
    int k = str1.indexOf("<<");
    if (k >= 0)
    {
      str4 = str1.substring(0, k).trim();
      str3 = str1.substring(k + 2).trim();
    }
    else
    {
      this._stdout.println("Usage:");
      this._stdout.println("  LOAD -option val query << file");
      this._stdout.println("Note :");
      this._stdout.println("  -F change field seperator(Default:|)");
      this._stdout.println("  -S skip lines (values > 0)");
      return;
    }
    str3 = str3.trim();
    str4 = str4.trim();
    if ((str4.length() == 0) || (str3.length() == 0))
    {
      this._stdout.println("Usage:");
      this._stdout.println("  LOAD -option val query << file");
      this._stdout.println("Note :");
      this._stdout.println("  -F change field seperator(Default:|)");
      this._stdout.println("  -S skip lines (values > 0)");
      return;
    }
    str3 = this.sysvariable.parseString(str3);
    SQLStatement localSQLStatement = null;
    BufferedReader localBufferedReader = null;
    int m = 0;
    try
    {
      localBufferedReader = new BufferedReader(new FileReader(str3));
      for (int n = 0; n < j; n++) {
        localBufferedReader.readLine();
      }
    }
    catch (IOException localIOException1)
    {
      this._stdout.println(localIOException1.getMessage());
      return;
    }
    try
    {
      localSQLStatement = prepareStatement(this.database, str4, this.sysvariable);
      do
      {
        this.load_buffer.deleteAllRow();
        this.load_buffer.read(localBufferedReader, str2, 200);
        localSQLStatement.executeBatch(this.sysvariable, this.load_buffer, 1, this.load_buffer.getRowCount());
        this.database.commit();
        m += this.load_buffer.getRowCount();
      } while (this.load_buffer.getRowCount() == 200);
      this._stdout.println("Command Completed.");
    }
    catch (SQLException localSQLException1)
    {
      this._stdout.print(localSQLException1);
    }
    catch (Exception localException)
    {
      this._stdout.println(localException.getMessage());
    }
    try
    {
      if (localSQLStatement != null) {
        localSQLStatement.close();
      }
    }
    catch (SQLException localSQLException2) {}
    try
    {
      if (localBufferedReader != null) {
        localBufferedReader.close();
      }
    }
    catch (IOException localIOException2) {}
    this._stdout.println(m + " rows loaded!");
  }
  
  private void procUnload(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLMultiple()[5]).size();
    String str1 = skipWord(paramString, i);
    OptionCommand localOptionCommand = new OptionCommand(str1);
    str1 = localOptionCommand.getCommand();
    String str2 = localOptionCommand.getOption("F", "|");
    String str3 = localOptionCommand.getOption("R", "\\r\\n");
    boolean bool = localOptionCommand.getBoolean("H", true);
    String str4 = null;
    String str5 = null;
    if (!isConnected())
    {
      this._stdout.println("Database not connected.");
      return;
    }
    int j = str1.indexOf(">>");
    if (j >= 0)
    {
      str5 = str1.substring(0, j).trim();
      str4 = str1.substring(j + 2).trim();
    }
    else
    {
      this._stdout.println("Usage:");
      this._stdout.println("  UNLOAD -option val query >> file");
      this._stdout.println("Note :");
      this._stdout.println("  -F change field seperator(Default:|)");
      this._stdout.println("  -R change record seperator(Default:\\r\\n)");
      this._stdout.println("  -H display field name {ON|OFF}");
      return;
    }
    str4 = str4.trim();
    str5 = str5.trim();
    if ((str5.length() == 0) || (str4.length() == 0))
    {
      this._stdout.println("Usage:");
      this._stdout.println("  UNLOAD -option val query >> file");
      this._stdout.println("Note :");
      this._stdout.println("  -F change field seperator(Default:|)");
      this._stdout.println("  -R change record seperator(Default:\\r\\n)");
      this._stdout.println("  -H display field name {ON|OFF}");
      return;
    }
    str4 = this.sysvariable.parseString(str4);
    SQLStatement localSQLStatement = null;
    ResultSet localResultSet = null;
    PrintStream localPrintStream = null;
    File localFile = new File(str4);
    try
    {
      long l = System.currentTimeMillis();
      localSQLStatement = prepareStatement(this.database, str5, this.sysvariable);
      localSQLStatement.bind(this.sysvariable);
      this.current_stmt = localSQLStatement.stmt;
      localResultSet = localSQLStatement.stmt.executeQuery();
      this.current_rset = localResultSet;
      this._stdout.println("Query executed in " + DBOperation.getElapsed(System.currentTimeMillis() - l));
      if (str4.trim().endsWith(".gz")) {
        localPrintStream = new PrintStream(new BufferedOutputStream(new GZIPOutputStream(new FileOutputStream(localFile), 65536)));
      } else {
        localPrintStream = new PrintStream(new BufferedOutputStream(new FileOutputStream(localFile), 262144));
      }
      writeData(localPrintStream, localResultSet, parseRecord(str2), parseRecord(str3), bool);
      localPrintStream.close();
      localResultSet.close();
      localSQLStatement.close();
      this.current_rset = null;
      this.current_stmt = null;
      return;
    }
    catch (SQLException localSQLException1)
    {
      this._stdout.print(localSQLException1);
    }
    catch (IOException localIOException)
    {
      this._stdout.print(localIOException);
    }
    if (localPrintStream != null) {
      localPrintStream.close();
    }
    if (localResultSet != null) {
      try
      {
        localResultSet.close();
      }
      catch (SQLException localSQLException2)
      {
        this._stdout.print(localSQLException2);
      }
    }
    if (localSQLStatement != null) {
      try
      {
        localSQLStatement.close();
      }
      catch (SQLException localSQLException3)
      {
        this._stdout.print(localSQLException3);
      }
    }
  }
  
  private void procLOBREAD(String paramString1, String paramString2)
  {
    if ((JavaVM.MAIN_VERSION == 1) && (JavaVM.MINOR_VERSION < 3))
    {
      this._stdout.println("Java VM 1.3 or above required to support this feature.");
      return;
    }
    if ((paramString2 == null) || (paramString1 == null) || (paramString2.length() == 0) || (paramString1.length() == 0))
    {
      this._stdout.println("Usage:");
      this._stdout.println("  LOB query >> file");
      this._stdout.println("  LOB query << file");
      this._stdout.println("Note :");
      this._stdout.println("  >> mean export long/long raw/blob/clob to a file ");
      this._stdout.println("  << mean import a file to blob/clob field, the query");
      this._stdout.println("     should include the for update clause");
      return;
    }
    paramString2 = this.sysvariable.parseString(paramString2);
    if (!isConnected())
    {
      this._stdout.println("Database not connected.");
      return;
    }
    SQLStatement localSQLStatement = null;
    ResultSet localResultSet = null;
    File localFile = new File(paramString2);
    try
    {
      localSQLStatement = prepareStatement(this.database, paramString1, this.sysvariable);
      localSQLStatement.bind(this.sysvariable);
      localResultSet = localSQLStatement.stmt.executeQuery();
      ResultSetMetaData localResultSetMetaData = localResultSet.getMetaData();
      if (localResultSet.next())
      {
        Object localObject1;
        Object localObject2;
        Object localObject4;
        if (localResultSetMetaData.getColumnType(1) == -1)
        {
          localObject1 = localResultSet.getCharacterStream(1);
          if (localObject1 != null)
          {
            localObject2 = new char[16384];
            try
            {
              int i = 0;
              localObject4 = new FileWriter(localFile);
              while ((i = ((Reader)localObject1).read((char[])localObject2)) > 0) {
                ((FileWriter)localObject4).write((char[])localObject2, 0, i);
              }
              ((FileWriter)localObject4).close();
              ((Reader)localObject1).close();
            }
            catch (IOException localIOException1)
            {
              this._stdout.print(localIOException1);
            }
          }
        }
        else if (localResultSetMetaData.getColumnType(1) == -4)
        {
          localObject1 = localResultSet.getBinaryStream(1);
          if (localObject1 != null)
          {
            localObject2 = new byte[16384];
            try
            {
              int j = 0;
              localObject4 = new FileOutputStream(localFile);
              while ((j = ((InputStream)localObject1).read((byte[])localObject2)) > 0) {
                ((FileOutputStream)localObject4).write((byte[])localObject2, 0, j);
              }
              ((FileOutputStream)localObject4).close();
              ((InputStream)localObject1).close();
            }
            catch (IOException localIOException2)
            {
              this._stdout.print(localIOException2);
            }
          }
        }
        else
        {
          Object localObject3;
          Object localObject5;
          if (localResultSetMetaData.getColumnType(1) == 2005)
          {
            localObject1 = localResultSet.getClob(1);
            if (localObject1 != null)
            {
              localObject2 = ((Clob)localObject1).getCharacterStream();
              if (localObject2 != null)
              {
                localObject3 = new char[16384];
                try
                {
                  int k = 0;
                  localObject5 = new FileWriter(localFile);
                  while ((k = ((Reader)localObject2).read((char[])localObject3)) > 0) {
                    ((FileWriter)localObject5).write((char[])localObject3, 0, k);
                  }
                  ((FileWriter)localObject5).close();
                  ((Reader)localObject2).close();
                }
                catch (IOException localIOException3)
                {
                  this._stdout.print(localIOException3);
                }
              }
            }
          }
          else if (localResultSetMetaData.getColumnType(1) == 2004)
          {
            localObject1 = localResultSet.getBlob(1);
            if (localObject1 != null)
            {
              localObject2 = ((Blob)localObject1).getBinaryStream();
              if (localObject2 != null)
              {
                localObject3 = new byte[16384];
                try
                {
                  int m = 0;
                  localObject5 = new FileOutputStream(localFile);
                  while ((m = ((InputStream)localObject2).read((byte[])localObject3)) > 0) {
                    ((FileOutputStream)localObject5).write((byte[])localObject3, 0, m);
                  }
                  ((FileOutputStream)localObject5).close();
                  ((InputStream)localObject2).close();
                }
                catch (IOException localIOException4)
                {
                  this._stdout.print(localIOException4);
                }
              }
            }
          }
        }
        this._stdout.println("Command succeed.");
      }
      else
      {
        this._stdout.println(" 0 record returned.");
      }
    }
    catch (Exception localException)
    {
      this._stdout.print(localException);
    }
    clearWarnings(this.database, this._stdout);
    try
    {
      if (localResultSet != null) {
        localResultSet.close();
      }
    }
    catch (SQLException localSQLException1)
    {
      this._stdout.print(localSQLException1);
    }
    try
    {
      if (localSQLStatement != null) {
        localSQLStatement.close();
      }
    }
    catch (SQLException localSQLException2)
    {
      this._stdout.print(localSQLException2);
    }
  }
  
  private void procOL(String paramString)
  {
    this._stdout.println("Usage: ");
    this._stdout.println("   OL HASH   hash_value");
    this._stdout.println("   OL SQL    filename.sql");
    this._stdout.println("   OL LIST   [category]");
    this._stdout.println("   OL SHOW   ol_name");
    this._stdout.println("   OL MOVE   ol_name newcategory");
    this._stdout.println("   OL DROP   ol_name");
    this._stdout.println("   OL SHIFT  ol_name1 ol_name2");
    this._stdout.println("   OL RENAME ol_name1 ol_name2");
  }
  
  private void procOLMove(String paramString)
  {
    if (!isConnected())
    {
      this._stdout.println("Database not connected!");
      return;
    }
    Object localObject = null;
    VariableTable localVariableTable = new VariableTable();
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[41]).size();
    String str = skipWord(paramString, i);
    str = str.trim();
    String[] arrayOfString = TextUtils.toStringArray(TextUtils.getWords(str));
    if (arrayOfString.length < 1)
    {
      this._stdout.println("OL RENAME ol_name1 ol_name2");
      return;
    }
    try
    {
      SQLStatement localSQLStatement = prepareScript(this.database, "ALTER PUBLIC OUTLINE " + arrayOfString[0] + " CHANGE CATEGORY TO " + (arrayOfString.length > 1 ? arrayOfString[1] : "ANYSQLTUNING"), localVariableTable);
      localSQLStatement.stmt.execute();
      localSQLStatement.close();
      this._stdout.println("Command completed!");
    }
    catch (SQLException localSQLException)
    {
      this._stdout.print(localSQLException);
    }
  }
  
  private void procOLRename(String paramString)
  {
    if (!isConnected())
    {
      this._stdout.println("Database not connected!");
      return;
    }
    Object localObject = null;
    VariableTable localVariableTable = new VariableTable();
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[44]).size();
    String str = skipWord(paramString, i);
    str = str.trim();
    String[] arrayOfString = TextUtils.toStringArray(TextUtils.getWords(str));
    if (arrayOfString.length < 2)
    {
      this._stdout.println("OL MOVE outline category");
      return;
    }
    try
    {
      SQLStatement localSQLStatement = prepareScript(this.database, "ALTER PUBLIC OUTLINE " + arrayOfString[0] + " RENAME TO " + arrayOfString[1], localVariableTable);
      localSQLStatement.stmt.execute();
      localSQLStatement.close();
      this._stdout.println("Command completed!");
    }
    catch (SQLException localSQLException)
    {
      this._stdout.print(localSQLException);
    }
  }
  
  private void procOLDrop(String paramString)
  {
    if (!isConnected())
    {
      this._stdout.println("Database not connected!");
      return;
    }
    DBRowCache localDBRowCache = null;
    VariableTable localVariableTable = new VariableTable();
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[38]).size();
    String str = skipWord(paramString, i);
    str = str.trim();
    String[] arrayOfString = TextUtils.toStringArray(TextUtils.getWords(str));
    if (arrayOfString.length < 1)
    {
      this._stdout.println("OL DROP outline");
      return;
    }
    localVariableTable.add("P_OLNAME", 12);
    localVariableTable.setValue("P_OLNAME", arrayOfString[0]);
    try
    {
      localDBRowCache = executeQuery(this.database, "SELECT OL_NAME,CATEGORY FROM OUTLN.OL$ WHERE CATEGORY = 'ANYSQLTUNING' AND OL_NAME = UPPER(:P_OLNAME)", localVariableTable, 2);
      if (localDBRowCache.getRowCount() != 1)
      {
        this._stdout.println("The outline should exist and be in category : ANYSQLTUNING");
        localDBRowCache.getWidth(false);
        this._stdout.print(localDBRowCache);
        return;
      }
      SQLStatement localSQLStatement = prepareScript(this.database, "DROP PUBLIC OUTLINE " + arrayOfString[0], localVariableTable);
      localSQLStatement.stmt.execute();
      localSQLStatement.close();
      this._stdout.println("Command completed!");
    }
    catch (SQLException localSQLException)
    {
      this._stdout.print(localSQLException);
    }
  }
  
  private void procOLShift(String paramString)
  {
    if (!isConnected())
    {
      this._stdout.println("Database not connected!");
      return;
    }
    DBRowCache localDBRowCache = null;
    VariableTable localVariableTable = new VariableTable();
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[39]).size();
    String str = skipWord(paramString, i);
    str = str.trim();
    String[] arrayOfString = TextUtils.toStringArray(TextUtils.getWords(str));
    if (arrayOfString.length < 2)
    {
      this._stdout.println("OL SHIFT ol_name1 ol_name2");
      return;
    }
    localVariableTable.add("P_OLNAME1", 12);
    localVariableTable.add("P_OLNAME2", 12);
    localVariableTable.setValue("P_OLNAME1", arrayOfString[0]);
    localVariableTable.setValue("P_OLNAME2", arrayOfString[1]);
    try
    {
      localDBRowCache = executeQuery(this.database, "SELECT OL_NAME,CATEGORY FROM OUTLN.OL$ WHERE CATEGORY = 'ANYSQLTUNING' AND OL_NAME IN (UPPER(:P_OLNAME1),UPPER(:P_OLNAME2))", localVariableTable, 2);
      if (localDBRowCache.getRowCount() != 2)
      {
        this._stdout.println("The two outline should exist and be in category : ANYSQLTUNING");
        localDBRowCache.getWidth(false);
        this._stdout.print(localDBRowCache);
        this._stdout.println("Shift outline failured.");
        return;
      }
      SQLStatement localSQLStatement1 = prepareStatement(this.database, "       update outln.ol$ c set hintcount=( select decode( c.OL_NAME, n.ol_name, o.hintcount, o.ol_name, n.hintcount ) \n            from ( select ol_name, hintcount from outln.ol$ where ol_name = upper(:P_OLNAME1) ) n , \n                 ( select ol_name, hintcount from outln.ol$ where ol_name = upper(:P_OLNAME2) ) o ) \nwhere ol_name in (upper(:P_OLNAME1), upper(:P_OLNAME2))", localVariableTable);
      SQLStatement localSQLStatement2 = prepareStatement(this.database, "       update outln.ol$hints c set ol_name =( select decode( c.OL_NAME, n.ol_name, o.ol_name, o.ol_name, n.ol_name) \n            from ( select ol_name, hintcount from outln.ol$ where ol_name = upper(:P_OLNAME1)) n , \n                 ( select ol_name, hintcount from outln.ol$ where ol_name = upper(:P_OLNAME2)) o ) \n where ol_name in (upper(:P_OLNAME1), upper(:P_OLNAME2))", localVariableTable);
      SQLStatement localSQLStatement3 = prepareStatement(this.database, "update outln.ol$nodes c set ol_name =( select decode( c.OL_NAME, n.ol_name, o.ol_name, o.ol_name, n.ol_name) \n            from ( select ol_name, hintcount from outln.ol$ where ol_name = upper(:P_OLNAME1)) n , \n                 ( select ol_name, hintcount from outln.ol$ where ol_name = upper(:P_OLNAME2)) o ) \n where ol_name in (upper(:P_OLNAME1), upper(:P_OLNAME2))", localVariableTable);
      try
      {
        localSQLStatement1.bind(localVariableTable);
        localSQLStatement1.stmt.execute();
        localSQLStatement2.bind(localVariableTable);
        localSQLStatement2.stmt.execute();
        localSQLStatement3.bind(localVariableTable);
        localSQLStatement3.stmt.execute();
        this.database.commit();
        this._stdout.println("Command complete!");
      }
      catch (SQLException localSQLException2)
      {
        this._stdout.print(localSQLException2);
        this.database.rollback();
      }
      localSQLStatement1.close();
      localSQLStatement2.close();
      localSQLStatement3.close();
    }
    catch (SQLException localSQLException1)
    {
      this._stdout.print(localSQLException1);
    }
  }
  
  private void procOLList(String paramString)
  {
    if (!isConnected())
    {
      this._stdout.println("Database not connected!");
      return;
    }
    DBRowCache localDBRowCache = null;
    VariableTable localVariableTable = new VariableTable();
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[40]).size();
    String str1 = skipWord(paramString, i);
    str1 = str1.trim();
    String[] arrayOfString = TextUtils.toStringArray(TextUtils.getWords(str1));
    String str2 = "ANYSQLTUNING";
    if (arrayOfString.length > 0) {
      str2 = arrayOfString[0];
    }
    localVariableTable.add("P_CATEGORY", 12);
    localVariableTable.setValue("P_CATEGORY", str2);
    try
    {
      localDBRowCache = executeQuery(this.database, "SELECT CATEGORY,COUNT(*) OL_COUNT FROM OUTLN.OL$ GROUP BY CATEGORY", localVariableTable, 2000);
      localDBRowCache.getWidth(false);
      this._stdout.print(localDBRowCache);
      this._stdout.println();
    }
    catch (SQLException localSQLException1)
    {
      this._stdout.print(localSQLException1);
    }
    this._stdout.println("Outlines under Category : " + str2);
    try
    {
      localDBRowCache = executeQuery(this.database, "SELECT OL_NAME,HASH_VALUE,HASH_VALUE2,CREATOR FROM OUTLN.OL$ WHERE CATEGORY=UPPER(:P_CATEGORY)", localVariableTable, 2000);
      localDBRowCache.getWidth(false);
      this._stdout.print(localDBRowCache);
      this._stdout.println();
    }
    catch (SQLException localSQLException2)
    {
      this._stdout.print(localSQLException2);
    }
  }
  
  private void procOLShow(String paramString)
  {
    if (!isConnected())
    {
      this._stdout.println("Database not connected!");
      return;
    }
    DBRowCache localDBRowCache = null;
    VariableTable localVariableTable = new VariableTable();
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[40]).size();
    String str = skipWord(paramString, i);
    str = str.trim();
    String[] arrayOfString = TextUtils.toStringArray(TextUtils.getWords(str));
    if (arrayOfString.length == 0)
    {
      this._stdout.println("OL SHOW outline");
      return;
    }
    localVariableTable.add("P_OLNAME", 12);
    localVariableTable.setValue("P_OLNAME", arrayOfString[0]);
    try
    {
      localDBRowCache = executeQuery(this.database, "SELECT CATEGORY,HASH_VALUE,HASH_VALUE2,CREATOR FROM OUTLN.OL$ WHERE OL_NAME=UPPER(:P_OLNAME)", localVariableTable, 2000);
      localDBRowCache.getWidth(false);
      this._stdout.print(localDBRowCache);
      this._stdout.println();
    }
    catch (SQLException localSQLException1)
    {
      this._stdout.print(localSQLException1);
    }
    try
    {
      localDBRowCache = executeQuery(this.database, "SELECT SQL_TEXT FROM OUTLN.OL$ WHERE OL_NAME=UPPER(:P_OLNAME)", localVariableTable, 2000);
      localDBRowCache.getWidth(false);
      this._stdout.print(localDBRowCache);
      this._stdout.println();
    }
    catch (SQLException localSQLException2)
    {
      this._stdout.print(localSQLException2);
    }
    try
    {
      localDBRowCache = executeQuery(this.database, "SELECT CATEGORY,HINT#,HINT_TYPE,HINT_TEXT,HINT_TEXTLEN,TABLE_NAME,USER_TABLE_NAME FROM OUTLN.OL$HINTS WHERE OL_NAME=UPPER(:P_OLNAME) ORDER BY HINT#", localVariableTable, 2000);
      localDBRowCache.getWidth(false);
      this._stdout.print(localDBRowCache);
      this._stdout.println();
    }
    catch (SQLException localSQLException3)
    {
      this._stdout.print(localSQLException3);
    }
  }
  
  private void procOLHash(String paramString)
  {
    if (!isConnected())
    {
      this._stdout.println("Database not connected!");
      return;
    }
    DBRowCache localDBRowCache = null;
    StringBuffer localStringBuffer = new StringBuffer();
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[37]).size();
    String str = skipWord(paramString, i);
    str = str.trim();
    String[] arrayOfString = TextUtils.toStringArray(TextUtils.getWords(str));
    if (arrayOfString.length == 0)
    {
      this._stdout.println("OL CREATE hash_value");
      return;
    }
    VariableTable localVariableTable = new VariableTable();
    localVariableTable.add("P_HASH", 12);
    for (int j = 0; j < arrayOfString.length; j++)
    {
      localVariableTable.setValue("P_HASH", arrayOfString[j]);
      try
      {
        localDBRowCache = executeQuery(this.database, "SELECT SQL_TEXT FROM V$SQLTEXT_WITH_NEWLINES WHERE HASH_VALUE=TO_NUMBER(:P_HASH) ORDER BY PIECE", localVariableTable, 2000);
        if (localDBRowCache.getRowCount() >= 0)
        {
          localStringBuffer.append("CREATE PUBLIC OUTLINE OL_" + arrayOfString[j] + "\n");
          localStringBuffer.append("  FOR CATEGORY ANYSQLTUNING ON \n");
          for (int k = 0; k < localDBRowCache.getRowCount(); k++) {
            localStringBuffer.append(localDBRowCache.getItem(k + 1, 1).toString());
          }
          SQLStatement localSQLStatement = prepareScript(this.database, localStringBuffer.toString(), localVariableTable);
          localSQLStatement.stmt.execute();
          localSQLStatement.close();
          this._stdout.println("Command completed!");
        }
        else
        {
          this._stdout.println("Invalid SQL hash value : " + arrayOfString[j] + " , no SQL found.");
        }
      }
      catch (SQLException localSQLException)
      {
        this._stdout.print(localSQLException);
      }
    }
  }
  
  private void procOLSQL(String paramString)
  {
    if (!isConnected())
    {
      this._stdout.println("Database not connected!");
      return;
    }
    Object localObject = null;
    StringBuffer localStringBuffer = new StringBuffer();
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[43]).size();
    String str1 = skipWord(paramString, i);
    String str2 = "";
    str1 = str1.trim();
    String[] arrayOfString = TextUtils.toStringArray(TextUtils.getWords(str1));
    if (arrayOfString.length == 0)
    {
      this._stdout.println("OL SQL hash_value");
      return;
    }
    VariableTable localVariableTable = new VariableTable();
    try
    {
      str2 = "SQL_" + new Date().toString().hashCode();
      if (arrayOfString.length > 1) {
        str2 = "SQL_" + arrayOfString[1];
      }
      localStringBuffer.append("CREATE PUBLIC OUTLINE " + str2 + "\n");
      localStringBuffer.append("  FOR CATEGORY ANYSQLTUNING ON \n");
      FileReader localFileReader = new FileReader(this.sysvariable.parseString(arrayOfString[0]));
      char[] arrayOfChar = new char[65536];
      int j = localFileReader.read(arrayOfChar);
      localStringBuffer.append(arrayOfChar, 0, j);
      localFileReader.close();
    }
    catch (IOException localIOException)
    {
      this._stdout.print(localIOException);
      this._stdout.println("Error in reading SQL file. ");
      return;
    }
    try
    {
      SQLStatement localSQLStatement = prepareScript(this.database, localStringBuffer.toString(), localVariableTable);
      localSQLStatement.stmt.execute();
      localSQLStatement.close();
      this._stdout.println("Command completed!");
    }
    catch (SQLException localSQLException)
    {
      this._stdout.print(localSQLException);
    }
  }
  
  private void procLOBWRITE(String paramString1, String paramString2)
  {
    long l1 = 0L;
    if ((JavaVM.MAIN_VERSION == 1) && (JavaVM.MINOR_VERSION < 4))
    {
      this._stdout.println("Java VM 1.4 or above required to support this feature.");
      return;
    }
    if (((paramString2 == null) && (paramString1 == null)) || (paramString2.length() == 0) || (paramString1.length() == 0))
    {
      this._stdout.println("Usage:");
      this._stdout.println("  LOB query >> file");
      this._stdout.println("  LOB query << file");
      this._stdout.println("Note :");
      this._stdout.println("  >> mean export long/long raw/blob/clob to a file ");
      this._stdout.println("  << mean import a file to blob/clob field, the query");
      this._stdout.println("     should include the for update clause");
      return;
    }
    paramString2 = this.sysvariable.parseString(paramString2);
    if (!isConnected())
    {
      this._stdout.println("Database not connected.");
      return;
    }
    SQLStatement localSQLStatement = null;
    ResultSet localResultSet = null;
    File localFile = new File(paramString2);
    if (!localFile.exists())
    {
      this._stdout.println("File " + paramString2 + " does not exists!");
      return;
    }
    if (!localFile.isFile())
    {
      this._stdout.println(paramString2 + " is not a valid file!");
      return;
    }
    if (!localFile.canRead())
    {
      this._stdout.println("Cannot read file " + paramString2 + "!");
      return;
    }
    try
    {
      localSQLStatement = prepareStatement(this.database, paramString1, this.sysvariable);
      localSQLStatement.bind(this.sysvariable);
      localResultSet = localSQLStatement.stmt.executeQuery();
      ResultSetMetaData localResultSetMetaData = localResultSet.getMetaData();
      if (localResultSet.next())
      {
        Object localObject1;
        Object localObject2;
        Object localObject3;
        if (localResultSetMetaData.getColumnType(1) == 2005)
        {
          localObject1 = localResultSet.getClob(1);
          long l2 = 0L;
          if (localObject1 != null)
          {
            char[] arrayOfChar = new char[16384];
            try
            {
              int i = 0;
              ((Clob)localObject1).truncate(l1);
              localObject2 = ((Clob)localObject1).setCharacterStream(l1);
              localObject3 = new FileReader(localFile);
              while ((i = ((FileReader)localObject3).read(arrayOfChar)) > 0)
              {
                ((Writer)localObject2).write(arrayOfChar, 0, i);
                l2 += i;
              }
              ((FileReader)localObject3).close();
              ((Writer)localObject2).close();
            }
            catch (IOException localIOException1)
            {
              this._stdout.print(localIOException1);
            }
          }
        }
        else if (localResultSetMetaData.getColumnType(1) == 2004)
        {
          localObject1 = localResultSet.getBlob(1);
          if (localObject1 != null)
          {
            byte[] arrayOfByte = new byte[16384];
            long l3 = 0L;
            try
            {
              int j = 0;
              ((Blob)localObject1).truncate(l1);
              localObject2 = ((Blob)localObject1).setBinaryStream(l1);
              localObject3 = new FileInputStream(localFile);
              while ((j = ((FileInputStream)localObject3).read(arrayOfByte)) > 0)
              {
                ((OutputStream)localObject2).write(arrayOfByte, 0, j);
                l3 += j;
              }
              ((FileInputStream)localObject3).close();
              ((OutputStream)localObject2).close();
            }
            catch (IOException localIOException2)
            {
              this._stdout.print(localIOException2);
            }
          }
        }
        this._stdout.println("Command succeed.");
      }
      else
      {
        this._stdout.println(" 0 record returned.");
      }
    }
    catch (Exception localException)
    {
      this._stdout.print(localException);
    }
    clearWarnings(this.database, this._stdout);
    try
    {
      if (localResultSet != null) {
        localResultSet.close();
      }
    }
    catch (SQLException localSQLException1)
    {
      this._stdout.print(localSQLException1);
    }
    try
    {
      if (localSQLStatement != null) {
        localSQLStatement.close();
      }
    }
    catch (SQLException localSQLException2)
    {
      this._stdout.print(localSQLException2);
    }
  }
  
  private void procLOBLEN(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLMultiple()[6]).size();
    String str = skipWord(paramString, i);
    str = str.trim();
    int j = 0;
    long l = 0L;
    char[] arrayOfChar = new char[8192];
    byte[] arrayOfByte = new byte[8192];
    if ((JavaVM.MAIN_VERSION == 1) && (JavaVM.MINOR_VERSION < 3))
    {
      this._stdout.println("Java VM 1.3 required to support this feature.");
      return;
    }
    if (str.length() == 0)
    {
      this._stdout.println("Usage:");
      this._stdout.println("  LOBLEN query");
      this._stdout.println("Note :");
      this._stdout.println("  Query should return one column as following:");
      this._stdout.println("  col1 : long/long raw/blob/clob field.");
      return;
    }
    if (!isConnected())
    {
      this._stdout.println("Database not connected.");
      return;
    }
    SQLStatement localSQLStatement = null;
    ResultSet localResultSet = null;
    try
    {
      localSQLStatement = prepareStatement(this.database, str, this.sysvariable);
      localSQLStatement.bind(this.sysvariable);
      this.current_stmt = localSQLStatement.stmt;
      localResultSet = localSQLStatement.stmt.executeQuery();
      this.current_rset = localResultSet;
      ResultSetMetaData localResultSetMetaData = localResultSet.getMetaData();
      if ((localResultSetMetaData.getColumnCount() != 1) || ((localResultSetMetaData.getColumnType(1) != 12) && (localResultSetMetaData.getColumnType(1) != 1) && (localResultSetMetaData.getColumnType(1) != -1) && (localResultSetMetaData.getColumnType(1) != -4) && (localResultSetMetaData.getColumnType(1) != 2004) && (localResultSetMetaData.getColumnType(1) != 2005)))
      {
        this._stdout.println("Usage:");
        this._stdout.println("  LOBLEN query");
        this._stdout.println("Note :");
        this._stdout.println("  Query should return one column as following:");
        this._stdout.println("  col1 : long/long raw/blob/clob field.");
        try
        {
          if (localResultSet != null) {
            localResultSet.close();
          }
        }
        catch (SQLException localSQLException3)
        {
          this._stdout.print(localSQLException3);
        }
        try
        {
          if (localSQLStatement != null) {
            localSQLStatement.close();
          }
        }
        catch (SQLException localSQLException4)
        {
          this._stdout.print(localSQLException4);
        }
        return;
      }
      j = localResultSetMetaData.getColumnType(1);
      while (localResultSet.next())
      {
        l = 0L;
        Object localObject1;
        if (j == -1)
        {
          localObject1 = localResultSet.getCharacterStream(1);
          if (localObject1 != null) {
            try
            {
              int k = 0;
              while ((k = ((Reader)localObject1).read(arrayOfChar)) > 0) {
                l += k;
              }
              ((Reader)localObject1).close();
            }
            catch (IOException localIOException1)
            {
              this._stdout.println();
              this._stdout.print(localIOException1);
            }
          }
        }
        else if (j == -4)
        {
          localObject1 = localResultSet.getBinaryStream(1);
          if (localObject1 != null) {
            try
            {
              int m = 0;
              while ((m = ((InputStream)localObject1).read(arrayOfByte)) > 0) {
                l += m;
              }
              ((InputStream)localObject1).close();
            }
            catch (IOException localIOException2)
            {
              this._stdout.println();
              this._stdout.print(localIOException2);
            }
          }
        }
        else
        {
          Object localObject2;
          if (j == 2005)
          {
            localObject1 = localResultSet.getClob(1);
            if (localObject1 != null)
            {
              localObject2 = ((Clob)localObject1).getCharacterStream();
              if (localObject2 != null) {
                try
                {
                  int n = 0;
                  while ((n = ((Reader)localObject2).read(arrayOfChar)) > 0) {
                    l += n;
                  }
                  ((Reader)localObject2).close();
                }
                catch (IOException localIOException3)
                {
                  this._stdout.println();
                  this._stdout.print(localIOException3);
                }
              }
            }
          }
          else if (j == 2004)
          {
            localObject1 = localResultSet.getBlob(1);
            if (localObject1 != null)
            {
              localObject2 = ((Blob)localObject1).getBinaryStream();
              if (localObject2 != null) {
                try
                {
                  int i1 = 0;
                  while ((i1 = ((InputStream)localObject2).read(arrayOfByte)) > 0) {
                    l += i1;
                  }
                  ((InputStream)localObject2).close();
                }
                catch (IOException localIOException4)
                {
                  this._stdout.println();
                  this._stdout.print(localIOException4);
                }
              }
            }
          }
        }
        this._stdout.println(l + "," + l / 1024L);
      }
    }
    catch (Exception localException)
    {
      this._stdout.print(localException);
    }
    this.current_stmt = null;
    this.current_rset = null;
    clearWarnings(this.database, this._stdout);
    try
    {
      if (localResultSet != null) {
        localResultSet.close();
      }
    }
    catch (SQLException localSQLException1)
    {
      this._stdout.print(localSQLException1);
    }
    try
    {
      if (localSQLStatement != null) {
        localSQLStatement.close();
      }
    }
    catch (SQLException localSQLException2)
    {
      this._stdout.print(localSQLException2);
    }
  }
  
  private void procLOBEXP(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLMultiple()[1]).size();
    String str1 = skipWord(paramString, i);
    str1 = str1.trim();
    int j = 0;
    long l = 0L;
    char[] arrayOfChar = new char[8192];
    byte[] arrayOfByte = new byte[8192];
    if ((JavaVM.MAIN_VERSION == 1) && (JavaVM.MINOR_VERSION < 3))
    {
      this._stdout.println("Java VM 1.3 required to support this feature.");
      return;
    }
    if (str1.length() == 0)
    {
      this._stdout.println("Usage:");
      this._stdout.println("  LOBEXP query");
      this._stdout.println("Note :");
      this._stdout.println("  Query should return tow column as following:");
      this._stdout.println("  col1 : CHAR or VARCHAR specify the filename.");
      this._stdout.println("  col2 : long/long raw/blob/clob field.");
      return;
    }
    if (!isConnected())
    {
      this._stdout.println("Database not connected.");
      return;
    }
    SQLStatement localSQLStatement = null;
    ResultSet localResultSet = null;
    try
    {
      localSQLStatement = prepareStatement(this.database, str1, this.sysvariable);
      localSQLStatement.bind(this.sysvariable);
      this.current_stmt = localSQLStatement.stmt;
      localResultSet = localSQLStatement.stmt.executeQuery();
      this.current_rset = localResultSet;
      ResultSetMetaData localResultSetMetaData = localResultSet.getMetaData();
      if ((localResultSetMetaData.getColumnCount() != 2) || ((localResultSetMetaData.getColumnType(1) != 12) && (localResultSetMetaData.getColumnType(1) != 1)) || ((localResultSetMetaData.getColumnType(2) != -1) && (localResultSetMetaData.getColumnType(2) != -4) && (localResultSetMetaData.getColumnType(2) != 2004) && (localResultSetMetaData.getColumnType(2) != 2005)))
      {
        this._stdout.println("Usage:");
        this._stdout.println("  LOBEXP query");
        this._stdout.println("Note :");
        this._stdout.println("  Query should return tow column as following:");
        this._stdout.println("  col1 : CHAR or VARCHAR specify the filename.");
        this._stdout.println("  col2 : long/long raw/blob/clob field.");
        try
        {
          if (localResultSet != null) {
            localResultSet.close();
          }
        }
        catch (SQLException localSQLException3)
        {
          this._stdout.print(localSQLException3);
        }
        try
        {
          if (localSQLStatement != null) {
            localSQLStatement.close();
          }
        }
        catch (SQLException localSQLException4)
        {
          this._stdout.print(localSQLException4);
        }
        return;
      }
      j = localResultSetMetaData.getColumnType(2);
      while (localResultSet.next())
      {
        String str2 = localResultSet.getString(1);
        if (str2 == null)
        {
          this._stdout.println("The file name is null!");
        }
        else
        {
          this._stdout.print("Write to file: " + str2);
          l = 0L;
          File localFile = new File(str2);
          Object localObject1;
          Object localObject3;
          if (j == -1)
          {
            localObject1 = localResultSet.getCharacterStream(2);
            if (localObject1 != null) {
              try
              {
                int k = 0;
                localObject3 = new FileWriter(localFile);
                while ((k = ((Reader)localObject1).read(arrayOfChar)) > 0)
                {
                  ((FileWriter)localObject3).write(arrayOfChar, 0, k);
                  l += k;
                }
                ((FileWriter)localObject3).close();
                ((Reader)localObject1).close();
              }
              catch (IOException localIOException1)
              {
                this._stdout.println();
                this._stdout.print(localIOException1);
              }
            }
          }
          else if (j == -4)
          {
            localObject1 = localResultSet.getBinaryStream(2);
            if (localObject1 != null) {
              try
              {
                int m = 0;
                localObject3 = new FileOutputStream(localFile);
                while ((m = ((InputStream)localObject1).read(arrayOfByte)) > 0)
                {
                  ((FileOutputStream)localObject3).write(arrayOfByte, 0, m);
                  l += m;
                }
                ((FileOutputStream)localObject3).close();
                ((InputStream)localObject1).close();
              }
              catch (IOException localIOException2)
              {
                this._stdout.println();
                this._stdout.print(localIOException2);
              }
            }
          }
          else
          {
            Object localObject2;
            Object localObject4;
            if (j == 2005)
            {
              localObject1 = localResultSet.getClob(2);
              if (localObject1 != null)
              {
                localObject2 = ((Clob)localObject1).getCharacterStream();
                if (localObject2 != null) {
                  try
                  {
                    int n = 0;
                    localObject4 = new FileWriter(localFile);
                    while ((n = ((Reader)localObject2).read(arrayOfChar)) > 0)
                    {
                      ((FileWriter)localObject4).write(arrayOfChar, 0, n);
                      l += n;
                    }
                    ((FileWriter)localObject4).close();
                    ((Reader)localObject2).close();
                  }
                  catch (IOException localIOException3)
                  {
                    this._stdout.println();
                    this._stdout.print(localIOException3);
                  }
                }
              }
            }
            else if (j == 2004)
            {
              localObject1 = localResultSet.getBlob(2);
              if (localObject1 != null)
              {
                localObject2 = ((Blob)localObject1).getBinaryStream();
                if (localObject2 != null) {
                  try
                  {
                    int i1 = 0;
                    localObject4 = new FileOutputStream(localFile);
                    while ((i1 = ((InputStream)localObject2).read(arrayOfByte)) > 0)
                    {
                      ((FileOutputStream)localObject4).write(arrayOfByte, 0, i1);
                      l += i1;
                    }
                    ((FileOutputStream)localObject4).close();
                    ((InputStream)localObject2).close();
                  }
                  catch (IOException localIOException4)
                  {
                    this._stdout.println();
                    this._stdout.print(localIOException4);
                  }
                }
              }
            }
          }
          this._stdout.println(" , bytes=" + l);
        }
      }
      this._stdout.println("Command succeed.");
    }
    catch (Exception localException)
    {
      this._stdout.print(localException);
    }
    this.current_stmt = null;
    this.current_rset = null;
    clearWarnings(this.database, this._stdout);
    try
    {
      if (localResultSet != null) {
        localResultSet.close();
      }
    }
    catch (SQLException localSQLException1)
    {
      this._stdout.print(localSQLException1);
    }
    try
    {
      if (localSQLStatement != null) {
        localSQLStatement.close();
      }
    }
    catch (SQLException localSQLException2)
    {
      this._stdout.print(localSQLException2);
    }
  }
  
  private void procLOBIMP(String paramString)
  {
    long l1 = 0L;
    int i = TextUtils.getWords(this._cmdtype.getASQLMultiple()[3]).size();
    String str1 = skipWord(paramString, i);
    str1 = str1.trim();
    char[] arrayOfChar = new char[8192];
    byte[] arrayOfByte = new byte[8192];
    if ((JavaVM.MAIN_VERSION == 1) && (JavaVM.MINOR_VERSION < 4))
    {
      this._stdout.println("Java VM 1.4 required to support this feature.");
      return;
    }
    if (str1.length() == 0)
    {
      this._stdout.println("Usage:");
      this._stdout.println("  LOBIMP query");
      this._stdout.println("Note :");
      this._stdout.println("  Query should return tow column as following:");
      this._stdout.println("  col1 : CHAR or VARCHAR specify the filename.");
      this._stdout.println("  col2 : blob/clob field.");
      return;
    }
    if (!isConnected())
    {
      this._stdout.println("Database not connected.");
      return;
    }
    SQLStatement localSQLStatement = null;
    ResultSet localResultSet = null;
    try
    {
      localSQLStatement = prepareStatement(this.database, str1, this.sysvariable);
      localSQLStatement.bind(this.sysvariable);
      this.current_stmt = localSQLStatement.stmt;
      localResultSet = localSQLStatement.stmt.executeQuery();
      this.current_rset = localResultSet;
      ResultSetMetaData localResultSetMetaData = localResultSet.getMetaData();
      if ((localResultSetMetaData.getColumnCount() != 2) || ((localResultSetMetaData.getColumnType(1) != 12) && (localResultSetMetaData.getColumnType(1) != 1)) || ((localResultSetMetaData.getColumnType(2) != 2004) && (localResultSetMetaData.getColumnType(2) != 2005)))
      {
        this._stdout.println("Usage:");
        this._stdout.println("  LOBIMP query");
        this._stdout.println("Note :");
        this._stdout.println("  Query should return tow column as following:");
        this._stdout.println("  col1 : CHAR or VARCHAR specify the filename.");
        this._stdout.println("  col2 : blob/clob field.");
        try
        {
          if (localResultSet != null) {
            localResultSet.close();
          }
        }
        catch (SQLException localSQLException3)
        {
          this._stdout.print(localSQLException3);
        }
        try
        {
          if (localSQLStatement != null) {
            localSQLStatement.close();
          }
        }
        catch (SQLException localSQLException4)
        {
          this._stdout.print(localSQLException4);
        }
        return;
      }
      while (localResultSet.next())
      {
        String str2 = localResultSet.getString(1);
        File localFile = new File(str2);
        if (!localFile.exists())
        {
          this._stdout.println("File " + str2 + " does not exists!");
        }
        else if (!localFile.isFile())
        {
          this._stdout.println(str2 + " is not a valid file!");
        }
        else if (!localFile.canRead())
        {
          this._stdout.println("Cannot read file " + str2 + "!");
        }
        else
        {
          Object localObject1;
          long l2;
          Object localObject2;
          Object localObject3;
          if (localResultSetMetaData.getColumnType(2) == 2005)
          {
            localObject1 = localResultSet.getClob(2);
            l2 = 0L;
            if (localObject1 != null) {
              try
              {
                int j = 0;
                ((Clob)localObject1).truncate(l1);
                localObject2 = ((Clob)localObject1).setCharacterStream(l1);
                localObject3 = new FileReader(localFile);
                while ((j = ((FileReader)localObject3).read(arrayOfChar)) > 0)
                {
                  ((Writer)localObject2).write(arrayOfChar, 0, j);
                  l2 += j;
                }
                ((FileReader)localObject3).close();
                ((Writer)localObject2).close();
              }
              catch (IOException localIOException1)
              {
                this._stdout.print(localIOException1);
              }
            }
          }
          else if (localResultSetMetaData.getColumnType(2) == 2004)
          {
            localObject1 = localResultSet.getBlob(2);
            if (localObject1 != null)
            {
              l2 = 0L;
              try
              {
                int k = 0;
                ((Blob)localObject1).truncate(l1);
                localObject2 = ((Blob)localObject1).setBinaryStream(l1);
                localObject3 = new FileInputStream(localFile);
                while ((k = ((FileInputStream)localObject3).read(arrayOfByte)) > 0)
                {
                  ((OutputStream)localObject2).write(arrayOfByte, 0, k);
                  l2 += k;
                }
                ((FileInputStream)localObject3).close();
                ((OutputStream)localObject2).close();
              }
              catch (IOException localIOException2)
              {
                this._stdout.print(localIOException2);
              }
            }
          }
          this._stdout.println("File " + str2 + " loaded.");
        }
      }
      this._stdout.println("Command succeed.");
    }
    catch (Exception localException)
    {
      this._stdout.print(localException);
    }
    this.current_stmt = null;
    this.current_rset = null;
    clearWarnings(this.database, this._stdout);
    try
    {
      if (localResultSet != null) {
        localResultSet.close();
      }
    }
    catch (SQLException localSQLException1)
    {
      this._stdout.print(localSQLException1);
    }
    try
    {
      if (localSQLStatement != null) {
        localSQLStatement.close();
      }
    }
    catch (SQLException localSQLException2)
    {
      this._stdout.print(localSQLException2);
    }
  }
  
  private void procBUFFERADD(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[33]).size();
    String str = skipWord(paramString, i);
    String[] arrayOfString = TextUtils.toStringArray(TextUtils.getWords(str));
    for (int j = 0; j < arrayOfString.length / 2; j++) {
      this.load_buffer.addColumn(arrayOfString[(j * 2)], SQLTypes.getTypeID(arrayOfString[(j * 2 + 1)]));
    }
    this._stdout.println("Command completed.");
  }
  
  private void procBUFFERLIST(String paramString)
  {
    this._stdout.println("Structure of load buffer:");
    for (int i = 1; i <= this.load_buffer.getColumnCount(); i++) {
      this._stdout.println("  " + lpad(this.load_buffer.getColumnName(i), 20) + "    " + SQLTypes.getTypeName(this.load_buffer.getColumnType(i)));
    }
  }
  
  private void procBUFFERRESET(String paramString)
  {
    this.load_buffer.deleteAllRow();
    this.load_buffer.removeAllColumn();
    this._stdout.println("Command completed.");
  }
  
  private void procLoadTNS(String paramString)
  {
    int i = TextUtils.getWords(this._cmdtype.getASQLSingle()[7]).size();
    String str = skipWord(paramString, i);
    str = str.trim();
    if (str.length() > 0) {
      loadTNSNames(str);
    }
    String[] arrayOfString = this.tnsnames.getNames();
    this._stdout.println("Avaiable TNS entries:");
    for (int j = 0; j < arrayOfString.length; j++) {
      if ((j + 1) % 3 == 1)
      {
        this._stdout.print(" ");
        this._stdout.print(lpad(arrayOfString[j], 25));
      }
      else
      {
        this._stdout.print(lpad(arrayOfString[j], 25));
        if ((j + 1) % 3 == 0) {
          this._stdout.println();
        }
      }
    }
    if (arrayOfString.length % 3 != 0) {
      this._stdout.println();
    }
  }
  
  public void showVersion()
  {
    this._stdout.println();
    this._stdout.println(" AnySQL for Oracle(8i/9i/10g), Release 3.0.0 (Build:20060816-1013)");
    this._stdout.println();
    this._stdout.println(" (@) Copyright Lou Fangxin 2004/2005, all rights reserved.");
    this._stdout.println();
  }
  
  public final void loadTNSNames(String paramString)
  {
    try
    {
      BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(paramString)));
      loadTNSNames(localBufferedReader);
    }
    catch (IOException localIOException) {}
  }
  
  private final void loadTNSNames(BufferedReader paramBufferedReader)
  {
    int i = 0;
    int j = 0;
    String str1 = "";
    String str2 = "";
    try
    {
      if (paramBufferedReader == null) {
        return;
      }
      while ((str1 = paramBufferedReader.readLine()) != null) {
        if ((str1.trim().length() <= 0) || (!str1.trim().substring(0, 1).equals("#")))
        {
          j = 0;
          if ((str1.length() > 0) && ((str1.trim().startsWith("(")) || (str1.trim().startsWith(")"))))
          {
            if (str2.length() > 0) {
              str2 = str2 + str1.trim();
            } else {
              str2 = str1.trim();
            }
          }
          else
          {
            j = str2.indexOf("=");
            if (j > 0)
            {
              this.tnsnames.add(str2.substring(0, j).trim().toUpperCase(), 12);
              if (j == str2.length() - 1) {
                this.tnsnames.setValue(str2.substring(0, j).trim().toUpperCase(), "");
              } else {
                this.tnsnames.setValue(str2.substring(0, j).trim().toUpperCase(), str2.substring(j + 1));
              }
            }
            if (str1.length() > 0) {
              str2 = str1.trim();
            } else {
              str2 = "";
            }
          }
        }
      }
      if (str2.length() > 0)
      {
        j = str2.indexOf("=");
        if (j > 0)
        {
          this.tnsnames.add(str2.substring(0, j).trim().toUpperCase(), 12);
          if (j == str2.length() - 1) {
            this.tnsnames.setValue(str2.substring(0, j).trim().toUpperCase(), "");
          } else {
            this.tnsnames.setValue(str2.substring(0, j).trim().toUpperCase(), str2.substring(j + 1));
          }
        }
      }
    }
    catch (IOException localIOException1) {}
    try
    {
      if (paramBufferedReader != null) {
        paramBufferedReader.close();
      }
    }
    catch (IOException localIOException2) {}
  }
  
  protected void doServerMessage()
    throws SQLException
  {
    SQLCallable localSQLCallable = null;
    VariableTable localVariableTable = new VariableTable();
    localVariableTable.add("P_LINE", 12);
    localVariableTable.add("P_STATUS", 4);
    localVariableTable.setValue("P_STATUS", "0");
    localSQLCallable = prepareCall(this.database, "DBMS_OUTPUT.GET_LINE(LINE=>:P_LINE OUT,STATUS=>:P_STATUS OUT)", localVariableTable);
    for (;;)
    {
      localSQLCallable.bind(localVariableTable);
      localSQLCallable.stmt.execute();
      localSQLCallable.fetch(localVariableTable);
      if (localVariableTable.getInt("P_STATUS", 1) == 1) {
        break;
      }
      this._stdout.println(localVariableTable.getString("P_LINE"));
    }
    localSQLCallable.close();
  }
  
  public String getLastCommand()
  {
    if (this.lastcommand == null) {
      return null;
    }
    return this.lastcommand.COMMAND;
  }
  
  public long writeData(PrintStream paramPrintStream, ResultSet paramResultSet, String paramString1, String paramString2, boolean paramBoolean)
    throws SQLException, IOException
  {
    long l1 = 0L;
    String str1 = null;
    int i = 0;
    byte[] arrayOfByte1 = new byte[8192];
    char[] arrayOfChar1 = new char[4096];
    byte[] arrayOfByte2 = new byte[65536];
    char[] arrayOfChar2 = new char[65536];
    long l2 = System.currentTimeMillis();
    ResultSetMetaData localResultSetMetaData = paramResultSet.getMetaData();
    int j = localResultSetMetaData.getColumnCount();
    int[] arrayOfInt = new int[j];
    SimpleDateFormat localSimpleDateFormat1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    SimpleDateFormat localSimpleDateFormat2 = new SimpleDateFormat("HH:mm:ss");
    SimpleDateFormat localSimpleDateFormat3 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
    SimpleDateFormat localSimpleDateFormat4 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS Z");
    for (int k = 0; k < j; k++)
    {
      arrayOfInt[k] = localResultSetMetaData.getColumnType(k + 1);
      if (paramBoolean)
      {
        str1 = localResultSetMetaData.getColumnName(k + 1);
        if (str1 != null) {
          paramPrintStream.print(str1);
        }
        if (k < j - 1) {
          paramPrintStream.print(paramString1);
        }
      }
    }
    if (paramBoolean) {
      paramPrintStream.print(paramString2);
    }
    while (paramResultSet.next())
    {
      l1 += 1L;
      for (k = 1; k <= j; k++)
      {
        Object localObject1;
        Object localObject2;
        switch (arrayOfInt[(k - 1)])
        {
        case -1: 
          Reader localReader = paramResultSet.getCharacterStream(k);
          if (localReader != null) {
            try
            {
              for (i = localReader.read(arrayOfChar2); i > 0; i = localReader.read(arrayOfChar2))
              {
                paramPrintStream.print(String.valueOf(arrayOfChar2, 0, i));
                if (i < 65536) {
                  break;
                }
              }
              localReader.close();
            }
            catch (IOException localIOException1) {}
          }
          break;
        case -4: 
          InputStream localInputStream1 = paramResultSet.getBinaryStream(k);
          if (localInputStream1 != null) {
            try
            {
              for (i = localInputStream1.read(arrayOfByte2); i > 0; i = localInputStream1.read(arrayOfByte2))
              {
                paramPrintStream.write(arrayOfByte2, 0, i);
                if (i < 65536) {
                  break;
                }
              }
              localInputStream1.close();
            }
            catch (IOException localIOException2) {}
          }
          break;
        case 2005: 
          Clob localClob = paramResultSet.getClob(k);
          if (localClob != null)
          {
            localObject1 = localClob.getCharacterStream();
            if (localObject1 != null) {
              try
              {
                for (i = ((Reader)localObject1).read(arrayOfChar2); i > 0; i = ((Reader)localObject1).read(arrayOfChar2))
                {
                  paramPrintStream.print(String.valueOf(arrayOfChar2, 0, i));
                  if (i < 65536) {
                    break;
                  }
                }
                ((Reader)localObject1).close();
              }
              catch (IOException localIOException3) {}
            }
          }
          break;
        case 2004: 
          localObject1 = paramResultSet.getBlob(k);
          if (localObject1 != null)
          {
            localObject2 = ((Blob)localObject1).getBinaryStream();
            if (localObject2 != null) {
              try
              {
                for (i = ((InputStream)localObject2).read(arrayOfByte2); i > 0; i = ((InputStream)localObject2).read(arrayOfByte2))
                {
                  paramPrintStream.write(arrayOfByte2, 0, i);
                  if (i < 65536) {
                    break;
                  }
                }
                ((InputStream)localObject2).close();
              }
              catch (IOException localIOException4) {}
            }
          }
          break;
        case 1: 
        case 12: 
          localObject2 = paramResultSet.getCharacterStream(k);
          if (localObject2 != null) {
            try
            {
              i = ((Reader)localObject2).read(arrayOfChar1);
              if (arrayOfInt[(k - 1)] == 1) {
                while ((i > 0) && (arrayOfChar1[(i - 1)] == ' ')) {
                  i--;
                }
              }
              if (i > 0) {
                paramPrintStream.print(String.valueOf(arrayOfChar1, 0, i));
              }
              ((Reader)localObject2).close();
            }
            catch (IOException localIOException5) {}
          }
          break;
        case -3: 
        case -2: 
          InputStream localInputStream2 = paramResultSet.getAsciiStream(k);
          if (localInputStream2 != null) {
            try
            {
              i = localInputStream2.read(arrayOfByte1);
              if (arrayOfInt[(k - 1)] == -2) {
                while ((i > 0) && (arrayOfByte1[(i - 1)] == 32)) {
                  i--;
                }
              }
              if (i > 0) {
                paramPrintStream.write(arrayOfByte1, 0, i);
              }
              localInputStream2.close();
            }
            catch (IOException localIOException6) {}
          }
          break;
        case 91: 
          Timestamp localTimestamp1 = paramResultSet.getTimestamp(k);
          if (localTimestamp1 != null) {
            paramPrintStream.print(localSimpleDateFormat1.format(localTimestamp1));
          }
          break;
        case 92: 
          Time localTime = paramResultSet.getTime(k);
          if (localTime != null) {
            paramPrintStream.print(localSimpleDateFormat2.format(localTime));
          }
          break;
        case 93: 
          Timestamp localTimestamp2 = paramResultSet.getTimestamp(k);
          if (localTimestamp2 != null) {
            paramPrintStream.print(localSimpleDateFormat3.format(localTimestamp2));
          }
          break;
        case -102: 
        case -101: 
          Timestamp localTimestamp3 = paramResultSet.getTimestamp(k);
          if (localTimestamp3 != null) {
            paramPrintStream.print(localSimpleDateFormat4.format(localTimestamp3));
          }
          break;
        case -14: 
        case -13: 
        case -10: 
        case 0: 
        case 70: 
        case 1111: 
        case 2000: 
        case 2001: 
        case 2002: 
        case 2003: 
        case 2006: 
          break;
        default: 
          String str2 = paramResultSet.getString(k);
          if (str2 != null) {
            paramPrintStream.print(str2);
          }
          break;
        }
        if (k < j) {
          paramPrintStream.print(paramString1);
        } else {
          paramPrintStream.print(paramString2);
        }
      }
      if (l1 % 100000L == 0L) {
        getCommandLog().println(lpad(String.valueOf(l1), 12) + " rows writed in " + DBOperation.getElapsed(System.currentTimeMillis() - l2));
      }
    }
    l2 = System.currentTimeMillis() - l2;
    if (l1 % 100000L != 0L) {
      getCommandLog().println(lpad(String.valueOf(l1), 12) + " rows writed in " + DBOperation.getElapsed(l2));
    }
    if (l2 > 0L) {
      getCommandLog().println("Done, total:" + l1 + " , avg:" + l1 * 1000L / l2 + " rows/s.");
    }
    return l1;
  }
  
  public int fetch(ResultSet paramResultSet, DBRowCache paramDBRowCache)
    throws SQLException
  {
    return fetch(paramResultSet, paramDBRowCache, 100);
  }
  
  public int fetch(ResultSet paramResultSet, DBRowCache paramDBRowCache, int paramInt)
    throws SQLException
  {
    int i = 0;
    int j = 0;
    int k = 0;
    byte[] arrayOfByte1 = new byte[8192];
    char[] arrayOfChar1 = new char[4096];
    byte[] arrayOfByte2 = new byte[65536];
    char[] arrayOfChar2 = new char[65536];
    Object localObject2;
    if (paramDBRowCache.getColumnCount() == 0)
    {
      localObject2 = paramResultSet.getMetaData();
      for (i = 1; i <= ((ResultSetMetaData)localObject2).getColumnCount(); i++) {
        if (((ResultSetMetaData)localObject2).getColumnName(i) != null)
        {
          if (paramDBRowCache.findColumn(((ResultSetMetaData)localObject2).getColumnName(i)) == 0)
          {
            paramDBRowCache.addColumn(((ResultSetMetaData)localObject2).getColumnName(i), ((ResultSetMetaData)localObject2).getColumnType(i));
          }
          else
          {
            for (j = 1; paramDBRowCache.findColumn(((ResultSetMetaData)localObject2).getColumnName(i) + "_" + j) != 0; j++) {}
            paramDBRowCache.addColumn(((ResultSetMetaData)localObject2).getColumnName(i) + "_" + j, ((ResultSetMetaData)localObject2).getColumnType(i));
          }
        }
        else
        {
          for (j = 1; paramDBRowCache.findColumn("NULL" + j) != 0; j++) {}
          paramDBRowCache.addColumn("NULL" + j, ((ResultSetMetaData)localObject2).getColumnType(i));
        }
      }
    }
    if (paramDBRowCache.getColumnCount() == 0) {
      return 0;
    }
    Object[] arrayOfObject;
    for (i = paramDBRowCache.getRowCount(); (i < paramInt) && (paramResultSet.next()); i = paramDBRowCache.appendRow(arrayOfObject))
    {
      arrayOfObject = new Object[paramDBRowCache.getColumnCount()];
      for (j = 1; j <= paramDBRowCache.getColumnCount(); j++)
      {
        Object localObject1 = null;
        int m;
        Object localObject3;
        Object localObject4;
        switch (paramDBRowCache.getColumnType(j))
        {
        case -1: 
          localObject2 = paramResultSet.getCharacterStream(j);
          if (localObject2 != null) {
            try
            {
              m = ((Reader)localObject2).read(arrayOfChar2);
              if (m > 0) {
                localObject1 = String.valueOf(arrayOfChar2, 0, m);
              }
              ((Reader)localObject2).close();
            }
            catch (IOException localIOException1) {}
          }
          break;
        case -4: 
          InputStream localInputStream1 = paramResultSet.getBinaryStream(j);
          if (localInputStream1 != null) {
            try
            {
              m = localInputStream1.read(arrayOfByte2);
              if (m > 0) {
                localObject1 = new String(arrayOfByte2, 0, m);
              }
              localInputStream1.close();
            }
            catch (IOException localIOException2) {}
          }
          break;
        case 2005: 
          Clob localClob = paramResultSet.getClob(j);
          if (localClob != null)
          {
            localObject3 = localClob.getCharacterStream();
            if (localObject3 != null) {
              try
              {
                m = ((Reader)localObject3).read(arrayOfChar2);
                if (m > 0) {
                  localObject1 = String.valueOf(arrayOfChar2, 0, m);
                }
                ((Reader)localObject3).close();
              }
              catch (IOException localIOException3) {}
            }
          }
          break;
        case 2004: 
          localObject3 = paramResultSet.getBlob(j);
          if (localObject3 != null)
          {
            localObject4 = ((Blob)localObject3).getBinaryStream();
            if (localObject4 != null) {
              try
              {
                m = ((InputStream)localObject4).read(arrayOfByte2);
                if (m > 0) {
                  localObject1 = new String(arrayOfByte2, 0, m);
                }
                ((InputStream)localObject4).close();
              }
              catch (IOException localIOException4) {}
            }
          }
          break;
        case 1: 
        case 12: 
          localObject4 = paramResultSet.getCharacterStream(j);
          if (localObject4 != null) {
            try
            {
              m = ((Reader)localObject4).read(arrayOfChar1);
              if (paramDBRowCache.getColumnType(j) == 1) {
                while ((m > 0) && (arrayOfChar1[(m - 1)] == ' ')) {
                  m--;
                }
              }
              if (m > 0) {
                localObject1 = String.valueOf(arrayOfChar1, 0, m);
              }
              ((Reader)localObject4).close();
            }
            catch (IOException localIOException5) {}
          }
          break;
        case -3: 
        case -2: 
          InputStream localInputStream2 = paramResultSet.getAsciiStream(j);
          if (localInputStream2 != null) {
            try
            {
              m = localInputStream2.read(arrayOfByte1);
              if (paramDBRowCache.getColumnType(j) == -2) {
                while ((m > 0) && (arrayOfByte1[(m - 1)] == 32)) {
                  m--;
                }
              }
              if (m > 0) {
                localObject1 = new String(arrayOfByte1, 0, m);
              }
              localInputStream2.close();
            }
            catch (IOException localIOException6) {}
          }
          break;
        case 91: 
          localObject1 = paramResultSet.getTimestamp(j);
          break;
        case 92: 
          localObject1 = paramResultSet.getTime(j);
          break;
        case -102: 
        case -101: 
        case 93: 
          localObject1 = paramResultSet.getTimestamp(j);
          break;
        case -7: 
        case -6: 
        case -5: 
        case 2: 
        case 3: 
        case 4: 
        case 5: 
        case 6: 
        case 7: 
        case 8: 
        case 16: 
          localObject1 = paramResultSet.getObject(j);
          break;
        case -14: 
        case -13: 
        case -10: 
        case 0: 
        case 70: 
        case 1111: 
        case 2000: 
        case 2001: 
        case 2002: 
        case 2003: 
        case 2006: 
          localObject1 = "N/A";
          break;
        default: 
          localObject1 = paramResultSet.getString(j);
        }
        arrayOfObject[(j - 1)] = localObject1;
      }
    }
    return i;
  }
  
  class CheckNet
    extends Thread
  {
    private boolean exit_loop = false;
    private Connection db = null;
    private String conninfo = null;
    
    public CheckNet(String paramString)
    {
      this.conninfo = paramString;
    }
    
    public void stopCheck()
    {
      this.exit_loop = true;
    }
    
    public void run()
    {
      Properties localProperties = DBConnection.getProperties("ORACLE");
      while (!this.exit_loop) {
        try
        {
          if (OracleSQLExecutor.this.oracle_driver.equalsIgnoreCase("THIN")) {
            this.db = DBConnection.getConnection("ORACLE", this.conninfo, localProperties);
          } else {
            this.db = DBConnection.getConnection("ORAOCI", this.conninfo, localProperties);
          }
          try
          {
            Thread.currentThread();
            Thread.sleep(2000L);
          }
          catch (InterruptedException localInterruptedException) {}
          this.db.close();
        }
        catch (SQLException localSQLException) {}
      }
    }
  }
}


/* Location:           D:\tmp\oasql.jar
 * Qualified Name:     com.asql.oracle.OracleSQLExecutor
 * JD-Core Version:    0.7.0.1
 */