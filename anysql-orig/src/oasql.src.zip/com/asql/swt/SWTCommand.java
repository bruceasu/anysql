package com.asql.swt;

import com.asql.core.CMDType;
import com.asql.core.Command;
import com.asql.core.CommandExecutor;
import com.asql.core.CommandLog;
import com.asql.core.CommandReader;
import com.asql.core.DBRowCache;
import com.asql.core.JavaVM;
import com.asql.core.SimpleDBRowCache;
import com.asql.core.TextUtils;
import com.asql.mysql.MySQLSQLExecutor;
import com.asql.oracle.OracleSQLExecutor;
import com.asql.sybase.SybaseSQLExecutor;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.custom.StyledTextContent;
import org.eclipse.swt.dnd.Clipboard;
import org.eclipse.swt.dnd.TextTransfer;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Cursor;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Widget;

public class SWTCommand
  extends SelectionAdapter
  implements KeyListener, CommandLog, CommandReader, Runnable
{
  private Shell shell = null;
  private StyledText jsql_command = null;
  private Vector command = new Vector();
  private Vector command_history = new Vector();
  private int p_history = 0;
  private StringBuffer current_line = new StringBuffer();
  private int buffer_size = 3000;
  private int cmd_type1 = 0;
  private int cmd_type2 = 0;
  private boolean isBusy = false;
  private CommandExecutor sql_executor = null;
  private int _pagesize = 14;
  private String _seperator = " ";
  private String _record = "\r\n";
  private boolean _heading = true;
  private boolean _autotrace = false;
  private CommandLog _logfile = null;
  private boolean term_out = true;
  private Display display = null;
  private Thread current_thread = null;
  private boolean last_exit = false;
  private boolean _dispform = false;
  public static final int ANYSQL_ORACLE = 0;
  public static final int ANYSQL_MYSQL = 1;
  public static final int ANYSQL_SYBASE = 2;
  
  public SWTCommand()
  {
    this.shell.setText("AnySQL for Oracle");
    init(this.shell);
    Menu localMenu = new Menu(this.shell, 2);
    this.shell.setMenuBar(localMenu);
    createFileMenu(localMenu);
    this.sql_executor = new OracleSQLExecutor(this, this);
    this.sql_executor.showVersion();
    prompt(this.sql_executor.getCommandType().getPrompt(0));
    this.shell.open();
  }
  
  public SWTCommand(int paramInt)
  {
    switch (paramInt)
    {
    case 0: 
      this.shell.setText("AnySQL for Oracle");
      this.sql_executor = new OracleSQLExecutor(this, this);
      break;
    case 1: 
      this.shell.setText("AnySQL for MySQL");
      this.sql_executor = new MySQLSQLExecutor(this, this);
      break;
    case 2: 
      this.shell.setText("AnySQL for SQL Server/Sybase");
      this.sql_executor = new SybaseSQLExecutor(this, this);
      break;
    default: 
      this.shell.setText("AnySQL for Oracle");
      this.sql_executor = new OracleSQLExecutor(this, this);
    }
    init(this.shell);
    Menu localMenu = new Menu(this.shell, 2);
    this.shell.setMenuBar(localMenu);
    createFileMenu(localMenu);
    this.sql_executor.showVersion();
    prompt(this.sql_executor.getCommandType().getPrompt(0));
    this.shell.open();
  }
  
  public void setFormDisplay(boolean paramBoolean)
  {
    this._dispform = paramBoolean;
  }
  
  public boolean getFormDisplay()
  {
    return this._dispform;
  }
  
  public boolean isBusy()
  {
    return this.isBusy;
  }
  
  public void doCut()
  {
    this.jsql_command.copy();
  }
  
  public void doCopy()
  {
    this.jsql_command.copy();
  }
  
  public void doPaste()
  {
    doKeyPaste();
  }
  
  public void selectAll()
  {
    this.jsql_command.selectAll();
  }
  
  private void init(Composite paramComposite)
  {
    FillLayout localFillLayout = new FillLayout();
    localFillLayout.type = 512;
    this.shell.setLayout(localFillLayout);
    this.jsql_command = new StyledText(this.shell, 768);
    if (JavaVM.OS.startsWith("Windows")) {
      this.jsql_command.setFont(new Font(this.shell.getDisplay(), "Fixedsys", 12, 12));
    }
    this.jsql_command.setEditable(false);
    this.jsql_command.addKeyListener(this);
  }
  
  public final void keyPressed(KeyEvent paramKeyEvent)
  {
    Point localPoint = this.jsql_command.getSelectionRange();
    if (paramKeyEvent.stateMask == 262144)
    {
      if (paramKeyEvent.keyCode == 118) {
        doKeyPaste();
      } else if (paramKeyEvent.keyCode == 99) {
        this.sql_executor.cancel();
      }
      return;
    }
    if (localPoint.y > 0)
    {
      if (paramKeyEvent.keyCode == 13)
      {
        this.jsql_command.setCaretOffset(this.jsql_command.getCharCount());
        this.jsql_command.showSelection();
      }
      else if (paramKeyEvent.keyCode == 127)
      {
        doKeyDelete(localPoint.x, localPoint.y);
      }
      return;
    }
    if (!isBusy())
    {
      int i = this.jsql_command.getLineAtOffset(this.jsql_command.getCaretOffset());
      if ((i == this.jsql_command.getLineCount() - 1) || (paramKeyEvent.keyCode == 16777217))
      {
        if (paramKeyEvent.keyCode == 13)
        {
          doKeyEnter();
        }
        else
        {
          if (paramKeyEvent.keyCode == 8)
          {
            doKeyBackSpace();
            return;
          }
          if ((paramKeyEvent.keyCode == 16777217) && (i == this.jsql_command.getLineCount() - 2))
          {
            doKeyDownArrow();
          }
          else if (paramKeyEvent.keyCode == 16777218)
          {
            doKeyUpArrow();
          }
          else
          {
            if (paramKeyEvent.keyCode == 127)
            {
              doKeyDelete();
              return;
            }
            if (paramKeyEvent.keyCode == 16777219)
            {
              doKeyLeft();
              return;
            }
            if (paramKeyEvent.keyCode == 16777220)
            {
              doKeyRight();
              return;
            }
            if (paramKeyEvent.keyCode == 16777228)
            {
              doKeyF3();
            }
            else if (paramKeyEvent.keyCode == 16777225)
            {
              doKeyPaste();
            }
            else
            {
              if (Character.isISOControl(paramKeyEvent.character))
              {
                this.jsql_command.showSelection();
                return;
              }
              doKeyChar(paramKeyEvent);
              this.jsql_command.setCaretOffset(this.jsql_command.getCaretOffset() + 1);
              this.jsql_command.showSelection();
              return;
            }
          }
        }
        this.jsql_command.setCaretOffset(this.jsql_command.getCharCount());
      }
      else
      {
        this.jsql_command.setCaretOffset(this.jsql_command.getCharCount());
      }
      this.jsql_command.showSelection();
    }
    else
    {
      this.jsql_command.setCaretOffset(this.jsql_command.getCharCount());
      this.jsql_command.showSelection();
      this.jsql_command.getDisplay().beep();
    }
  }
  
  public final void keyReleased(KeyEvent paramKeyEvent) {}
  
  private void doKeyDownArrow()
  {
    int i = this.current_line.length();
    if (i > 0)
    {
      this.current_line.delete(0, i);
      this.jsql_command.getContent().replaceTextRange(this.jsql_command.getCharCount() - i, i, "");
    }
    if (this.command_history.size() > 0)
    {
      if (this.p_history > 0) {
        this.p_history -= 1;
      }
      if (this.p_history < 1) {
        this.p_history = this.command_history.size();
      }
      if (this.p_history < 1) {
        this.p_history = this.command_history.size();
      }
      if (this.p_history > this.command_history.size()) {
        this.p_history = 1;
      }
      this.current_line.append(this.command_history.elementAt(this.p_history - 1).toString());
      this.jsql_command.append(this.command_history.elementAt(this.p_history - 1).toString());
    }
  }
  
  private void doKeyLeft()
  {
    int i = this.jsql_command.getCharCount();
    int j = this.jsql_command.getCaretOffset();
    if (i - j >= this.current_line.length()) {
      this.jsql_command.setCaretOffset(i - this.current_line.length());
    }
  }
  
  private void doKeyRight() {}
  
  private void doKeyUpArrow()
  {
    int i = this.current_line.length();
    if (i > 0)
    {
      this.current_line.delete(0, i);
      this.jsql_command.getContent().replaceTextRange(this.jsql_command.getCharCount() - i, i, "");
    }
    if (this.command_history.size() > 0)
    {
      this.p_history += 1;
      if (this.p_history > this.command_history.size()) {
        this.p_history = 1;
      }
      if (this.p_history > this.command_history.size()) {
        this.p_history = 1;
      }
      if (this.p_history < 1) {
        this.p_history = this.command_history.size();
      }
      this.current_line.append(this.command_history.elementAt(this.p_history - 1).toString());
      this.jsql_command.append(this.command_history.elementAt(this.p_history - 1).toString());
    }
  }
  
  private void doKeyF3()
  {
    int i = this.current_line.length();
    if (this.command_history.size() > 0)
    {
      String str = this.command_history.elementAt(0).toString();
      if (str.length() > i)
      {
        this.current_line.append(str.substring(i));
        this.jsql_command.append(str.substring(i));
      }
    }
  }
  
  public final void doExecute(String paramString)
  {
    String str = paramString;
    if ((str != null) && (!isBusy()))
    {
      Vector localVector = TextUtils.getLines(str);
      if (localVector.size() > 0) {
        for (int i = 0; i < localVector.size(); i++)
        {
          this.current_line.append(localVector.elementAt(i).toString());
          print(localVector.elementAt(i).toString());
          if (i < localVector.size() - 1) {
            doKeyEnter();
          }
        }
      }
    }
  }
  
  public void run()
  {
    try
    {
      this.isBusy = true;
      Command localCommand = this.sql_executor.getCommandType().readCommand(this.sql_executor.getCommandReader());
      this.sql_executor.run(localCommand);
      this.command.removeAllElements();
      prompt(this.sql_executor.getCommandType().getPrompt(this.command.size() + 1));
      this.isBusy = false;
    }
    catch (IOException localIOException) {}
  }
  
  public final void executeQuery(String paramString)
  {
    doExecute(paramString + "\n/");
    doKeyEnter();
  }
  
  private void doKeyPaste()
  {
    String str = getPasteText();
    doExecute(str);
  }
  
  private void doKeyChar(KeyEvent paramKeyEvent)
  {
    int i = this.jsql_command.getCharCount();
    int j = this.jsql_command.getCaretOffset();
    int k = this.current_line.length() - (i - j);
    if (k >= 0)
    {
      this.current_line.insert(k, paramKeyEvent.character);
      this.jsql_command.insert(String.valueOf(paramKeyEvent.character));
    }
    else
    {
      this.jsql_command.setCaretOffset(i);
    }
  }
  
  private void doKeyBackSpace()
  {
    if (this.current_line.length() > 0)
    {
      int i = this.jsql_command.getCharCount();
      int j = this.jsql_command.getCaretOffset();
      if (i - j <= this.current_line.length())
      {
        int k = this.current_line.length() - (i - j);
        if (k > 0)
        {
          this.current_line.deleteCharAt(k - 1);
          this.jsql_command.getContent().replaceTextRange(this.jsql_command.getCaretOffset() - 1, 1, "");
        }
      }
    }
  }
  
  private void doKeyDelete()
  {
    if (this.current_line.length() > 0)
    {
      int i = this.jsql_command.getCharCount();
      int j = this.jsql_command.getCaretOffset();
      if (i - j <= this.current_line.length())
      {
        int k = this.current_line.length() - (i - j);
        if (k < this.current_line.length())
        {
          this.current_line.deleteCharAt(k);
          this.jsql_command.getContent().replaceTextRange(this.jsql_command.getCaretOffset(), 1, "");
        }
      }
    }
  }
  
  private void doKeyDelete(int paramInt1, int paramInt2)
  {
    if (this.current_line.length() > 0)
    {
      int i = this.jsql_command.getCharCount();
      if ((i - paramInt1 <= this.current_line.length()) && (paramInt2 <= this.current_line.length()))
      {
        this.current_line.delete(this.current_line.length() - (i - paramInt1), this.current_line.length() - (i - paramInt1) + paramInt2);
        this.jsql_command.showSelection();
        this.jsql_command.getContent().replaceTextRange(paramInt1, paramInt2, "");
      }
    }
  }
  
  private void doClear(int paramInt1, int paramInt2)
  {
    this.jsql_command.getContent().replaceTextRange(paramInt1, paramInt2, "");
  }
  
  private void doClear()
  {
    int i = this.jsql_command.getLineCount();
    if (i > this.buffer_size)
    {
      int j = i - (this.buffer_size - 200);
      int k = this.jsql_command.getOffsetAtLine(j);
      doClear(0, k);
    }
  }
  
  private void doKeyEnter()
  {
    if (this.sql_executor.getCommandLog().getLogFile() != null) {
      this.sql_executor.getCommandLog().getLogFile().print(this.current_line.toString());
    }
    println();
    if (!this.term_out) {
      flush("\r\n");
    }
    if (this.command.size() == 0) {
      this.cmd_type1 = this.sql_executor.getCommandType().getCommandID(this.current_line.toString());
    }
    this.cmd_type2 = this.sql_executor.getCommandType().getCommandID(this.current_line.toString());
    this.command.addElement(this.current_line.toString());
    if (this.current_line.toString().trim().length() > 0) {
      this.command_history.addElement(this.current_line.toString());
    }
    if (this.command_history.size() > 300) {
      this.command_history.remove(0);
    }
    if ((this.command.size() == 0) && (this.current_line.toString().length() == 0))
    {
      this.current_line.delete(0, this.current_line.length());
      prompt(this.sql_executor.getCommandType().getPrompt(this.command.size() + 1));
      return;
    }
    if (this.cmd_type1 == 8)
    {
      this.current_line.delete(0, this.current_line.length());
      this.shell.getShell().close();
    }
    else if ((this.cmd_type1 == 10) && ("CLEAR".equalsIgnoreCase(this.current_line.toString())))
    {
      this.current_line.delete(0, this.current_line.length());
      this.jsql_command.setText("");
      this.sql_executor.showVersion();
      this.command.removeAllElements();
      prompt(this.sql_executor.getCommandType().getPrompt(this.command.size()));
    }
    else
    {
      Object localObject1;
      Object localObject2;
      if ((this.cmd_type1 == 10) && ("EDIT".equalsIgnoreCase(this.current_line.toString())))
      {
        this.current_line.delete(0, this.current_line.length());
        localObject1 = this.sql_executor.getLastCommand();
        localObject2 = new SWTEditor(this.shell, (String)localObject1);
        localObject1 = ((SWTEditor)localObject2).open();
        this.command.removeAllElements();
        prompt(this.sql_executor.getCommandType().getPrompt(this.command.size()));
        doExecute((String)localObject1);
      }
      else if (this.sql_executor.getCommandType().isCommandReady(this.cmd_type1, this.cmd_type2, this.current_line.toString()))
      {
        this.current_line.delete(0, this.current_line.length());
        this.p_history = (this.command_history.size() + 1);
        switch (this.cmd_type1)
        {
        case 0: 
        case 1: 
        case 2: 
        case 3: 
        case 4: 
        case 6: 
        case 7: 
        case 13: 
        case 16: 
        case 17: 
          this.current_thread = new Thread(this);
          this.current_thread.start();
          localObject1 = this.shell.getDisplay();
          try
          {
            while ((this.current_thread != null) && (this.current_thread.isAlive()) && (this.shell != null) && (!this.shell.isDisposed()))
            {
              if (!((Display)localObject1).readAndDispatch()) {
                ((Display)localObject1).sleep();
              }
              localObject2 = ((Display)localObject1).getShells();
              int i = 1;
              for (int j = 0; j < localObject2.length; j++) {
                if (!localObject2[j].isDisposed())
                {
                  i = 0;
                  break;
                }
              }
              if (i != 0) {
                break;
              }
            }
          }
          catch (Throwable localThrowable) {}
        }
        run();
      }
      else
      {
        this.current_line.delete(0, this.current_line.length());
        prompt(this.sql_executor.getCommandType().getPrompt(this.command.size() + 1));
      }
    }
  }
  
  private boolean isCommandReady()
  {
    return false;
  }
  
  private void flush(String paramString)
  {
    if ((this.shell != null) && (!this.shell.isDisposed())) {
      if (this.current_thread != null)
      {
        this.shell.getDisplay().syncExec(new TextWriter(paramString));
      }
      else
      {
        this.jsql_command.append(paramString);
        doClear();
        this.jsql_command.setCaretOffset(this.jsql_command.getCharCount());
        this.jsql_command.showSelection();
      }
    }
  }
  
  public final void print(String paramString)
  {
    if (this.term_out) {
      flush(paramString);
    }
    if (this._logfile != null) {
      this._logfile.print(paramString);
    }
  }
  
  public final void prompt(String paramString)
  {
    flush(paramString);
    if (this._logfile != null) {
      this._logfile.print(paramString);
    }
  }
  
  public final void println(String paramString)
  {
    if (this.term_out) {
      flush(paramString + "\r\n");
    }
    if (this._logfile != null) {
      this._logfile.println(paramString);
    }
  }
  
  public String readPassword()
    throws Exception
  {
    PasswordReader localPasswordReader = new PasswordReader();
    this.shell.getDisplay().syncExec(localPasswordReader);
    return localPasswordReader.password;
  }
  
  public final String readline()
  {
    if (this.command.size() > 0) {
      return this.command.remove(0).toString();
    }
    return null;
  }
  
  public void println()
  {
    if (this.term_out) {
      flush("\r\n");
    }
    if (this._logfile != null) {
      this._logfile.println();
    }
  }
  
  public void close() {}
  
  private String getFixedWidth(String paramString, int paramInt, boolean paramBoolean)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    if ((paramBoolean) && (paramString != null)) {
      localStringBuffer.append(paramString);
    }
    for (int i = paramString == null ? 0 : paramString.getBytes().length; i < paramInt; i++) {
      localStringBuffer.append(" ");
    }
    if ((!paramBoolean) && (paramString != null)) {
      localStringBuffer.append(paramString);
    }
    return localStringBuffer.toString();
  }
  
  public void print(DBRowCache paramDBRowCache)
  {
    int i = 0;
    int j = 0;
    int k = 0;
    if (paramDBRowCache == null) {
      return;
    }
    if (paramDBRowCache.getColumnCount() == 0) {
      return;
    }
    if (this._seperator.equals(" ")) {
      paramDBRowCache.getWidth(false);
    }
    i = paramDBRowCache.getRowCount();
    for (int m = 1; m <= paramDBRowCache.getColumnCount(); m++) {
      if (paramDBRowCache.getColumnName(m).length() > k) {
        k = paramDBRowCache.getColumnName(m).length();
      }
    }
    if (!this._dispform) {
      for (m = 1; m <= i; m++)
      {
        if (this._heading)
        {
          if ((j == 0) || ((this._pagesize > 0) && ((m % this._pagesize == 1) || (this._pagesize == 1))))
          {
            if (j > 0)
            {
              if (this.term_out) {
                flush("\r\n");
              }
              if (this._logfile != null) {
                this._logfile.println();
              }
            }
            if (this._seperator.equals(" "))
            {
              if (this.term_out)
              {
                flush(paramDBRowCache.getFixedHeader() + "\r\n");
                flush(paramDBRowCache.getSeperator() + "\r\n");
              }
              if (this._logfile != null)
              {
                this._logfile.println(paramDBRowCache.getFixedHeader());
                this._logfile.println(paramDBRowCache.getSeperator());
              }
            }
            else
            {
              if (this.term_out) {
                flush(paramDBRowCache.getSepHeader(this._seperator) + "\r\n");
              }
              if (this._logfile != null) {
                this._logfile.println(paramDBRowCache.getSepHeader(this._seperator));
              }
            }
          }
        }
        else if (((j == 0) || ((this._pagesize > 0) && ((m % this._pagesize == 1) || (this._pagesize == 1)))) && (j > 0))
        {
          if (this.term_out) {
            flush("\r\n");
          }
          if (this._logfile != null) {
            this._logfile.println();
          }
        }
        if (this._seperator.equals(" "))
        {
          if (this.term_out) {
            flush(paramDBRowCache.getFixedRow(m) + "\r\n");
          }
          if (this._logfile != null) {
            this._logfile.println(paramDBRowCache.getFixedRow(m));
          }
        }
        else
        {
          if (this.term_out) {
            flush(paramDBRowCache.getSepRow(this._seperator, m) + "\r\n");
          }
          if (this._logfile != null) {
            this._logfile.println(paramDBRowCache.getSepRow(this._seperator, m));
          }
        }
        j++;
      }
    }
    for (m = 1; m <= i; m++)
    {
      for (int n = 1; n <= paramDBRowCache.getColumnCount(); n++)
      {
        if (this.term_out) {
          flush(getFixedWidth(paramDBRowCache.getColumnName(n), k + 1, true) + ": " + paramDBRowCache.getString(m, n) + "\r\n");
        }
        if (this._logfile != null) {
          this._logfile.println(getFixedWidth(paramDBRowCache.getColumnName(n), k + 1, true) + ": " + paramDBRowCache.getString(m, n));
        }
      }
      if (m < i)
      {
        if (this.term_out) {
          flush("\r\n");
        }
        if (this._logfile != null) {
          this._logfile.println();
        }
      }
    }
    paramDBRowCache.deleteAllRow();
    if (i > 0)
    {
      if (this.term_out) {
        flush("\r\n");
      }
      if (this._logfile != null) {
        this._logfile.println();
      }
    }
    if (this.term_out) {
      flush(j + " rows returned.\r\n");
    }
    if (this._logfile != null) {
      this._logfile.println(j + " rows returned.");
    }
  }
  
  public void print(ResultSet paramResultSet)
    throws SQLException
  {
    SimpleDBRowCache localSimpleDBRowCache = new SimpleDBRowCache();
    int i = this._pagesize > 0 ? 400 / this._pagesize * this._pagesize : 400;
    int j = 0;
    int k = 0;
    int m = 0;
    if (this._autotrace)
    {
      while (paramResultSet.next()) {
        k++;
      }
      if (this.term_out) {
        flush(k + " rows returned.\r\n");
      }
      if (this._logfile != null) {
        this._logfile.println(k + " rows returned.");
      }
      return;
    }
    while ((j = this.sql_executor.fetch(paramResultSet, localSimpleDBRowCache, i)) > 0)
    {
      if (m == 0) {
        for (n = 1; n <= localSimpleDBRowCache.getColumnCount(); n++) {
          if (localSimpleDBRowCache.getColumnName(n).length() > m) {
            m = localSimpleDBRowCache.getColumnName(n).length();
          }
        }
      }
      if (this._seperator.equals(" ")) {
        localSimpleDBRowCache.getWidth(false);
      }
      if (!this._dispform) {
        for (n = 1; n <= localSimpleDBRowCache.getRowCount(); n++)
        {
          if (this._heading)
          {
            if ((k == 0) || ((this._pagesize > 0) && ((n % this._pagesize == 1) || (this._pagesize == 1))))
            {
              if (k > 0)
              {
                if (this.term_out) {
                  flush("\r\n");
                }
                if (this._logfile != null) {
                  this._logfile.println();
                }
              }
              if (this._seperator.equals(" "))
              {
                if (this.term_out)
                {
                  flush(localSimpleDBRowCache.getFixedHeader() + "\r\n");
                  flush(localSimpleDBRowCache.getSeperator() + "\r\n");
                }
                if (this._logfile != null)
                {
                  this._logfile.println(localSimpleDBRowCache.getFixedHeader());
                  this._logfile.println(localSimpleDBRowCache.getSeperator());
                }
              }
              else
              {
                if (this.term_out) {
                  flush(localSimpleDBRowCache.getSepHeader(this._seperator) + "\r\n");
                }
                if (this._logfile != null) {
                  this._logfile.println(localSimpleDBRowCache.getSepHeader(this._seperator));
                }
              }
            }
          }
          else if (((k == 0) || ((this._pagesize > 0) && ((n % this._pagesize == 1) || (this._pagesize == 1)))) && (k > 0))
          {
            if (this.term_out) {
              flush("\r\n");
            }
            if (this._logfile != null) {
              this._logfile.println();
            }
          }
          if (this._seperator.equals(" "))
          {
            if (this.term_out) {
              flush(localSimpleDBRowCache.getFixedRow(n) + "\r\n");
            }
            if (this._logfile != null) {
              this._logfile.println(localSimpleDBRowCache.getFixedRow(n));
            }
          }
          else
          {
            if (this.term_out) {
              flush(localSimpleDBRowCache.getSepRow(this._seperator, n) + "\r\n");
            }
            if (this._logfile != null) {
              this._logfile.println(localSimpleDBRowCache.getSepRow(this._seperator, n));
            }
          }
          k++;
        }
      }
      for (int n = 1; n <= j; n++)
      {
        for (int i1 = 1; i1 <= localSimpleDBRowCache.getColumnCount(); i1++)
        {
          if (this.term_out) {
            flush(getFixedWidth(localSimpleDBRowCache.getColumnName(i1), m + 1, true) + ": " + localSimpleDBRowCache.getString(n, i1) + "\r\n");
          }
          if (this._logfile != null) {
            this._logfile.println(getFixedWidth(localSimpleDBRowCache.getColumnName(i1), m + 1, true) + ": " + localSimpleDBRowCache.getString(n, i1));
          }
        }
        if (n < j)
        {
          if (this.term_out) {
            flush("\r\n");
          }
          if (this._logfile != null) {
            this._logfile.println();
          }
        }
        k++;
      }
      localSimpleDBRowCache.deleteAllRow();
      if (j > 0)
      {
        if (this.term_out) {
          flush("\r\n");
        }
        if (this._logfile != null) {
          this._logfile.println();
        }
      }
    }
    if (this.term_out) {
      flush(k + " rows returned.\r\n");
    }
    if (this._logfile != null) {
      this._logfile.println(k + " rows returned.");
    }
  }
  
  public void print(int paramInt)
  {
    if (this.term_out) {
      flush(paramInt + " rows affected.\r\n");
    }
    if (this._logfile != null) {
      this._logfile.println(paramInt + " rows affected.");
    }
  }
  
  private String removeNewLine(String paramString)
  {
    if (paramString == null) {
      return "";
    }
    char[] arrayOfChar = paramString.toCharArray();
    for (int i = arrayOfChar.length - 1; (i >= 0) && ((arrayOfChar[i] == '\r') || (arrayOfChar[i] == '\n') || (arrayOfChar[i] == '\t') || (arrayOfChar[i] == ' ')); i--) {}
    if (i >= 0) {
      return String.valueOf(arrayOfChar, 0, i + 1);
    }
    return "";
  }
  
  public void print(Exception paramException)
  {
    String str = paramException.getMessage();
    flush(removeNewLine(str) + "\r\n");
    if (this._logfile != null) {
      this._logfile.println(removeNewLine(str));
    }
  }
  
  public void print(SQLException paramSQLException)
  {
    String str = paramSQLException.getMessage();
    flush(removeNewLine(str) + "\r\n");
    if (this._logfile != null) {
      this._logfile.println(removeNewLine(str));
    }
  }
  
  public int getPagesize()
  {
    return this._pagesize;
  }
  
  public void setPagesize(int paramInt)
  {
    if ((paramInt >= 0) && (paramInt <= 200)) {
      this._pagesize = paramInt;
    }
  }
  
  public void setSeperator(String paramString)
  {
    this._seperator = paramString;
  }
  
  public void setRecord(String paramString)
  {
    if ((paramString == null) || (paramString.length() == 0))
    {
      this._record = "\r\n";
      return;
    }
    char[] arrayOfChar = paramString.toCharArray();
    StringBuffer localStringBuffer = new StringBuffer();
    for (int i = 0; i < arrayOfChar.length; i++) {
      if (arrayOfChar[i] == '\\')
      {
        if (i + 1 < arrayOfChar.length)
        {
          if (arrayOfChar[(i + 1)] == 'r')
          {
            localStringBuffer.append('\r');
          }
          else if (arrayOfChar[(i + 1)] == 'n')
          {
            localStringBuffer.append('\n');
          }
          else
          {
            localStringBuffer.append(arrayOfChar[i]);
            localStringBuffer.append(arrayOfChar[(i + 1)]);
          }
          i += 1;
        }
        else
        {
          localStringBuffer.append(arrayOfChar[i]);
        }
      }
      else {
        localStringBuffer.append(arrayOfChar[i]);
      }
    }
    this._record = localStringBuffer.toString();
  }
  
  public String getSeperator()
  {
    return this._seperator;
  }
  
  public String getRecord()
  {
    return this._record;
  }
  
  public boolean getHeading()
  {
    return this._heading;
  }
  
  public void setAutotrace(boolean paramBoolean)
  {
    this._autotrace = paramBoolean;
  }
  
  public void setHeading(boolean paramBoolean)
  {
    this._heading = paramBoolean;
  }
  
  public void setLogFile(CommandLog paramCommandLog)
  {
    this._logfile = paramCommandLog;
  }
  
  public CommandLog getLogFile()
  {
    return this._logfile;
  }
  
  private String getPasteText()
  {
    Clipboard localClipboard = new Clipboard(this.shell.getDisplay());
    TextTransfer localTextTransfer = TextTransfer.getInstance();
    String str = (String)localClipboard.getContents(localTextTransfer);
    return str;
  }
  
  public void createFileMenu(Menu paramMenu)
  {
    MenuItem localMenuItem2 = new MenuItem(paramMenu, 64);
    localMenuItem2.setText("File");
    Menu localMenu1 = new Menu(paramMenu);
    localMenuItem2.setMenu(localMenu1);
    MenuItem localMenuItem3 = new MenuItem(localMenu1, 64);
    localMenuItem3.setText("Open Oracle");
    localMenuItem3.setData("FILE_OPEN_ORACLE");
    localMenuItem3.addSelectionListener(this);
    MenuItem localMenuItem4 = new MenuItem(localMenu1, 64);
    localMenuItem4.setText("Open MySQL");
    localMenuItem4.setData("FILE_OPEN_MYSQL");
    localMenuItem4.addSelectionListener(this);
    MenuItem localMenuItem5 = new MenuItem(localMenu1, 64);
    localMenuItem5.setText("Open SQLServer/Sybase");
    localMenuItem5.setData("FILE_OPEN_SYBASE");
    localMenuItem5.addSelectionListener(this);
    MenuItem localMenuItem1 = new MenuItem(localMenu1, 2);
    MenuItem localMenuItem6 = new MenuItem(localMenu1, 64);
    localMenuItem6.setText("Cancel");
    localMenuItem6.setData("FILE_CANCEL");
    localMenuItem6.addSelectionListener(this);
    localMenuItem1 = new MenuItem(localMenu1, 2);
    MenuItem localMenuItem7 = new MenuItem(localMenu1, 64);
    localMenuItem7.setText("Exit");
    localMenuItem7.setData("FILE_EXIT");
    localMenuItem7.addSelectionListener(this);
    MenuItem localMenuItem8 = new MenuItem(paramMenu, 64);
    localMenuItem8.setText("Edit");
    Menu localMenu2 = new Menu(paramMenu);
    localMenuItem8.setMenu(localMenu2);
    MenuItem localMenuItem9 = new MenuItem(localMenu2, 64);
    localMenuItem9.setText("Copy");
    localMenuItem9.setData("EDIT_COPY");
    localMenuItem9.addSelectionListener(this);
    MenuItem localMenuItem10 = new MenuItem(localMenu2, 64);
    localMenuItem10.setText("Paste");
    localMenuItem10.setData("EDIT_PASTE");
    localMenuItem10.addSelectionListener(this);
    MenuItem localMenuItem11 = new MenuItem(localMenu2, 64);
    localMenuItem11.setText("Select All");
    localMenuItem11.setData("EDIT_SELECTALL");
    localMenuItem11.addSelectionListener(this);
    MenuItem localMenuItem12 = new MenuItem(paramMenu, 64);
    localMenuItem12.setText("Font");
    Menu localMenu3 = new Menu(paramMenu);
    localMenuItem12.setMenu(localMenu3);
    MenuItem localMenuItem13 = new MenuItem(localMenu3, 64);
    localMenuItem13.setText("SimSun");
    localMenuItem13.setData("FONT_SIMSUN");
    localMenuItem13.addSelectionListener(this);
    MenuItem localMenuItem14 = new MenuItem(localMenu3, 64);
    localMenuItem14.setText("Fixedsys");
    localMenuItem14.setData("FONT_FIXEDSYS");
    localMenuItem14.addSelectionListener(this);
    MenuItem localMenuItem15 = new MenuItem(paramMenu, 64);
    localMenuItem15.setText("Help");
    Menu localMenu4 = new Menu(paramMenu);
    localMenuItem15.setMenu(localMenu4);
    MenuItem localMenuItem16 = new MenuItem(localMenu4, 64);
    localMenuItem16.setText("About ...");
    localMenuItem16.setData("HELP_ABOUT");
    localMenuItem16.addSelectionListener(this);
  }
  
  public void widgetSelected(SelectionEvent paramSelectionEvent)
  {
    if (paramSelectionEvent.widget.getData().toString().equals("FILE_OPEN_ORACLE"))
    {
      if (!isBusy()) {
        new SWTCommand(0);
      }
    }
    else if (paramSelectionEvent.widget.getData().toString().equals("FILE_OPEN_MYSQL"))
    {
      if (!isBusy()) {
        new SWTCommand(1);
      }
    }
    else if (paramSelectionEvent.widget.getData().toString().equals("FILE_OPEN_SYBASE"))
    {
      if (!isBusy()) {
        new SWTCommand(2);
      }
    }
    else if (paramSelectionEvent.widget.getData().toString().equals("FILE_CANCEL")) {
      this.sql_executor.cancel();
    } else if (paramSelectionEvent.widget.getData().toString().equals("FILE_EXIT")) {
      this.shell.getShell().close();
    } else if (paramSelectionEvent.widget.getData().toString().equals("EDIT_CUT")) {
      this.jsql_command.copy();
    } else if (paramSelectionEvent.widget.getData().toString().equals("EDIT_COPY")) {
      this.jsql_command.copy();
    } else if (paramSelectionEvent.widget.getData().toString().equals("EDIT_PASTE")) {
      doKeyPaste();
    } else if (paramSelectionEvent.widget.getData().toString().equals("EDIT_SELECTALL")) {
      this.jsql_command.selectAll();
    } else if (paramSelectionEvent.widget.getData().toString().equals("FONT_SIMSUN")) {
      this.jsql_command.setFont(new Font(this.shell.getDisplay(), "NSimSun", 0, 12));
    } else if (paramSelectionEvent.widget.getData().toString().equals("FONT_FIXEDSYS")) {
      this.jsql_command.setFont(new Font(this.shell.getDisplay(), "Fixedsys", 0, 12));
    }
  }
  
  public String getWorkingDir()
  {
    return JavaVM.USER_DIRECTORY;
  }
  
  public void setTermout(boolean paramBoolean)
  {
    this.term_out = paramBoolean;
    this.sql_executor.setTermout(paramBoolean);
  }
  
  public void setWorkingDir(String paramString) {}
  
  class PasswordReader
    implements Runnable
  {
    public String password = "";
    
    PasswordReader() {}
    
    public void run()
    {
      SWTPassword localSWTPassword = new SWTPassword(SWTCommand.this.shell);
      this.password = localSWTPassword.open();
    }
  }
  
  class ChangeCursor
    implements Runnable
  {
    private boolean busytag = false;
    
    public ChangeCursor(boolean paramBoolean)
    {
      this.busytag = paramBoolean;
    }
    
    public void run()
    {
      if ((SWTCommand.this.jsql_command != null) && (!SWTCommand.this.jsql_command.isDisposed())) {
        if (this.busytag) {
          SWTCommand.this.jsql_command.setCursor(new Cursor(SWTCommand.this.shell.getDisplay(), 1));
        } else {
          SWTCommand.this.jsql_command.setCursor(new Cursor(SWTCommand.this.shell.getDisplay(), 0));
        }
      }
    }
  }
  
  class TextWriter
    implements Runnable
  {
    private String message = "";
    
    public TextWriter(String paramString)
    {
      if (paramString != null) {
        this.message = paramString;
      }
    }
    
    public void run()
    {
      if ((SWTCommand.this.jsql_command != null) && (!SWTCommand.this.jsql_command.isDisposed()))
      {
        SWTCommand.this.jsql_command.append(this.message);
        SWTCommand.this.doClear();
        SWTCommand.this.jsql_command.setCaretOffset(SWTCommand.this.jsql_command.getCharCount());
        SWTCommand.this.jsql_command.showSelection();
      }
    }
  }
}


/* Location:           D:\tmp\oasql.jar
 * Qualified Name:     com.asql.swt.SWTCommand
 * JD-Core Version:    0.7.0.1
 */