package com.asql.swt;

import com.asql.core.JavaVM;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Widget;

public class SWTEditor
  extends SelectionAdapter
  implements ModifyListener, KeyListener
{
  private Shell parent = null;
  private Shell shell = null;
  private StyledText sqltext = null;
  private String sql = "";
  
  public SWTEditor(Shell paramShell, String paramString)
  {
    this.parent = paramShell;
    this.sql = paramString;
    if (this.sql == null) {
      this.sql = "";
    }
  }
  
  public SWTEditor(Shell paramShell)
  {
    this.parent = paramShell;
    this.sql = "";
  }
  
  private Shell createControl()
  {
    Shell localShell = new Shell(this.parent, 35952);
    FillLayout localFillLayout = new FillLayout();
    localFillLayout.type = 512;
    localShell.setLayout(localFillLayout);
    localShell.setText("SQL Editor");
    this.sqltext = new StyledText(localShell, 2816);
    this.sqltext.setText(this.sql);
    if (JavaVM.OS.startsWith("Windows")) {
      this.sqltext.setFont(new Font(localShell.getDisplay(), "Fixedsys", 0, 0));
    }
    this.sqltext.setData("SQL");
    this.sqltext.addModifyListener(this);
    this.sqltext.addKeyListener(this);
    Menu localMenu1 = new Menu(localShell, 2);
    MenuItem localMenuItem1 = new MenuItem(localMenu1, 64);
    localMenuItem1.setText("Edit");
    Menu localMenu2 = new Menu(localMenu1);
    localMenuItem1.setMenu(localMenu2);
    MenuItem localMenuItem2 = new MenuItem(localMenu2, 64);
    localMenuItem2.setText("Cut");
    localMenuItem2.setData("EDIT_CUT");
    localMenuItem2.addSelectionListener(this);
    MenuItem localMenuItem3 = new MenuItem(localMenu2, 64);
    localMenuItem3.setText("Copy");
    localMenuItem3.setData("EDIT_COPY");
    localMenuItem3.addSelectionListener(this);
    MenuItem localMenuItem4 = new MenuItem(localMenu2, 64);
    localMenuItem4.setText("Paste");
    localMenuItem4.setData("EDIT_PASTE");
    localMenuItem4.addSelectionListener(this);
    MenuItem localMenuItem5 = new MenuItem(localMenu2, 2);
    MenuItem localMenuItem6 = new MenuItem(localMenu2, 64);
    localMenuItem6.setText("Exit");
    localMenuItem6.setData("EDIT_EXIT");
    localMenuItem6.addSelectionListener(this);
    localShell.setMenuBar(localMenu1);
    return localShell;
  }
  
  public String open()
  {
    this.shell = createControl();
    this.shell.setBounds(250, 180, 520, 380);
    this.shell.open();
    Display localDisplay = this.shell.getDisplay();
    while (!this.shell.isDisposed()) {
      if (!localDisplay.readAndDispatch()) {
        localDisplay.sleep();
      }
    }
    return this.sql;
  }
  
  public void modifyText(ModifyEvent paramModifyEvent)
  {
    if (paramModifyEvent.widget.getData().toString().equals("SQL")) {
      this.sql = ((StyledText)paramModifyEvent.widget).getText();
    }
  }
  
  public final void keyPressed(KeyEvent paramKeyEvent) {}
  
  public final void keyReleased(KeyEvent paramKeyEvent)
  {
    int i = this.sqltext.getLineAtOffset(this.sqltext.getCaretOffset());
    int j = this.sqltext.getCaretOffset() - this.sqltext.getOffsetAtLine(i);
    this.sqltext.getShell().setText("SQL Editor (Row:" + (i + 1) + ",Col:" + j + ")");
  }
  
  public void widgetSelected(SelectionEvent paramSelectionEvent)
  {
    if (paramSelectionEvent.widget.getData().toString().equals("EDIT_CUT"))
    {
      if (this.sqltext != null) {
        this.sqltext.cut();
      }
    }
    else if (paramSelectionEvent.widget.getData().toString().equals("EDIT_COPY"))
    {
      if (this.sqltext != null) {
        this.sqltext.copy();
      }
    }
    else if (paramSelectionEvent.widget.getData().toString().equals("EDIT_PASTE"))
    {
      if (this.sqltext != null) {
        this.sqltext.paste();
      }
    }
    else if ((paramSelectionEvent.widget.getData().toString().equals("EDIT_EXIT")) && (this.shell != null)) {
      this.shell.close();
    }
  }
}


/* Location:           D:\tmp\oasql.jar
 * Qualified Name:     com.asql.swt.SWTEditor
 * JD-Core Version:    0.7.0.1
 */