package com.asql.swt;

import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Widget;

public class SWTPassword
  extends SelectionAdapter
  implements ModifyListener
{
  private Shell parent = null;
  private Shell shell = null;
  private Text sqltext = null;
  private String password = "";
  
  public SWTPassword(Shell paramShell)
  {
    this.parent = paramShell;
  }
  
  private Shell createControl()
  {
    Shell localShell = new Shell(this.parent, 34912);
    GridLayout localGridLayout = new GridLayout();
    localGridLayout.numColumns = 1;
    localGridLayout.marginHeight = 5;
    localGridLayout.marginWidth = 5;
    localGridLayout.horizontalSpacing = 5;
    localGridLayout.verticalSpacing = 5;
    GridData localGridData = new GridData();
    localGridData.horizontalAlignment = 4;
    localGridData.grabExcessHorizontalSpace = true;
    localShell.setLayout(localGridLayout);
    localShell.setText("Login");
    Label localLabel = new Label(localShell, 0);
    localLabel.setText("Enter Password:");
    this.sqltext = new Text(localShell, 2052);
    this.sqltext.setText("");
    this.sqltext.setData("SQL");
    this.sqltext.setEchoChar('*');
    this.sqltext.addModifyListener(this);
    this.sqltext.setLayoutData(localGridData);
    Composite localComposite = new Composite(localShell, 0);
    localGridData = new GridData();
    localGridData.horizontalAlignment = 4;
    localGridData.grabExcessHorizontalSpace = true;
    localComposite.setLayoutData(localGridData);
    localGridLayout = new GridLayout();
    localGridLayout.numColumns = 2;
    localGridLayout.marginHeight = 5;
    localGridLayout.marginWidth = 30;
    localGridLayout.horizontalSpacing = 30;
    localGridLayout.verticalSpacing = 5;
    localComposite.setLayout(localGridLayout);
    Button localButton = new Button(localComposite, 0);
    localButton.setText("Login");
    localButton.setData("OK");
    localButton.addSelectionListener(this);
    localButton = new Button(localComposite, 0);
    localButton.setText("Cancel");
    localButton.setData("CANCEL");
    localButton.addSelectionListener(this);
    return localShell;
  }
  
  public String open()
  {
    this.password = "";
    this.shell = createControl();
    this.shell.pack();
    Rectangle localRectangle1 = this.parent.getBounds();
    Rectangle localRectangle2 = this.shell.getBounds();
    localRectangle1.x += (localRectangle1.width - localRectangle2.width) / 2;
    localRectangle1.y += (localRectangle1.height - localRectangle2.height) / 2;
    this.shell.setBounds(localRectangle2);
    this.shell.open();
    Display localDisplay = this.shell.getDisplay();
    while (!this.shell.isDisposed()) {
      if (!localDisplay.readAndDispatch()) {
        localDisplay.sleep();
      }
    }
    return this.password;
  }
  
  public void widgetSelected(SelectionEvent paramSelectionEvent)
  {
    if (paramSelectionEvent.widget.getData().toString().equals("OK"))
    {
      this.shell.close();
    }
    else if (paramSelectionEvent.widget.getData().toString().equals("CANCEL"))
    {
      this.password = "";
      this.shell.close();
    }
  }
  
  public void modifyText(ModifyEvent paramModifyEvent)
  {
    if (paramModifyEvent.widget.getData().toString().equals("SQL")) {
      this.password = ((Text)paramModifyEvent.widget).getText();
    }
  }
}


/* Location:           D:\tmp\oasql.jar
 * Qualified Name:     com.asql.swt.SWTPassword
 * JD-Core Version:    0.7.0.1
 */