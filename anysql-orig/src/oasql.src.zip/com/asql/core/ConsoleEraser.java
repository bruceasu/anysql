package com.asql.core;

import java.io.PrintStream;

class ConsoleEraser
  extends Thread
{
  private boolean running = true;
  
  public void run()
  {
    while (this.running)
    {
      System.out.print("\b ");
      try
      {
        sleep(5L);
      }
      catch (InterruptedException localInterruptedException) {}
    }
  }
  
  public synchronized void halt()
  {
    this.running = false;
  }
}


/* Location:           D:\tmp\oasql.jar
 * Qualified Name:     com.asql.core.ConsoleEraser
 * JD-Core Version:    0.7.0.1
 */