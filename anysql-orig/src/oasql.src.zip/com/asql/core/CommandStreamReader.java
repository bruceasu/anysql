package com.asql.core;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import sun.io.ByteToCharConverter;
import sun.io.ConversionBufferFullException;

public class CommandStreamReader
  extends Reader
{
  private ByteToCharConverter btc;
  private InputStream in;
  private static final int defaultByteBufferSize = 1;
  private byte[] bb;
  private int nBytes = 0;
  private int nextByte = 0;
  
  public CommandStreamReader(InputStream paramInputStream)
  {
    this(paramInputStream, ByteToCharConverter.getDefault());
  }
  
  public CommandStreamReader(InputStream paramInputStream, String paramString)
    throws UnsupportedEncodingException
  {
    this(paramInputStream, ByteToCharConverter.getConverter(paramString));
  }
  
  private CommandStreamReader(InputStream paramInputStream, ByteToCharConverter paramByteToCharConverter)
  {
    super(paramInputStream);
    if (paramInputStream == null) {
      throw new NullPointerException("input stream is null");
    }
    this.in = paramInputStream;
    this.btc = paramByteToCharConverter;
    this.bb = new byte[1];
  }
  
  public String getEncoding()
  {
    synchronized (this.lock)
    {
      if (this.btc != null) {
        return this.btc.getCharacterEncoding();
      }
      return null;
    }
  }
  
  private void malfunction()
  {
    throw new InternalError("Converter malfunction (" + this.btc.getCharacterEncoding() + ") -- please submit a bug report via " + System.getProperty("java.vendor.url.bug"));
  }
  
  private int convertInto(char[] paramArrayOfChar, int paramInt1, int paramInt2)
    throws IOException
  {
    int i = 0;
    if (this.nextByte < this.nBytes) {
      try
      {
        i = this.btc.convert(this.bb, this.nextByte, this.nBytes, paramArrayOfChar, paramInt1, paramInt2);
        this.nextByte = this.nBytes;
        if (this.btc.nextByteIndex() != this.nextByte) {
          malfunction();
        }
      }
      catch (ConversionBufferFullException localConversionBufferFullException)
      {
        this.nextByte = this.btc.nextByteIndex();
        i = this.btc.nextCharIndex() - paramInt1;
      }
    }
    return i;
  }
  
  private int flushInto(char[] paramArrayOfChar, int paramInt1, int paramInt2)
    throws IOException
  {
    int i = 0;
    try
    {
      i = this.btc.flush(paramArrayOfChar, paramInt1, paramInt2);
    }
    catch (ConversionBufferFullException localConversionBufferFullException)
    {
      i = this.btc.nextCharIndex() - paramInt1;
    }
    return i;
  }
  
  private int fill(char[] paramArrayOfChar, int paramInt1, int paramInt2)
    throws IOException
  {
    int i = 0;
    if (this.nextByte < this.nBytes) {
      i = convertInto(paramArrayOfChar, paramInt1, paramInt2);
    }
    while (paramInt1 + i < paramInt2)
    {
      if (this.nBytes != -1)
      {
        if ((i > 0) && (!inReady())) {
          break;
        }
        this.nBytes = this.in.read(this.bb);
      }
      if (this.nBytes == -1)
      {
        this.nBytes = 0;
        i += flushInto(paramArrayOfChar, paramInt1 + i, paramInt2);
        if (i != 0) {
          break;
        }
        return -1;
      }
      this.nextByte = 0;
      i += convertInto(paramArrayOfChar, paramInt1 + i, paramInt2);
    }
    return i;
  }
  
  private boolean inReady()
  {
    try
    {
      return this.in.available() > 0;
    }
    catch (IOException localIOException) {}
    return false;
  }
  
  private void ensureOpen()
    throws IOException
  {
    if (this.in == null) {
      throw new IOException("Stream closed");
    }
  }
  
  public int read()
    throws IOException
  {
    char[] arrayOfChar = new char[1];
    if (read(arrayOfChar, 0, 1) == -1) {
      return -1;
    }
    return arrayOfChar[0];
  }
  
  public int read(char[] paramArrayOfChar, int paramInt1, int paramInt2)
    throws IOException
  {
    synchronized (this.lock)
    {
      ensureOpen();
      if ((paramInt1 < 0) || (paramInt1 > paramArrayOfChar.length) || (paramInt2 < 0) || (paramInt1 + paramInt2 > paramArrayOfChar.length) || (paramInt1 + paramInt2 < 0)) {
        throw new IndexOutOfBoundsException();
      }
      if (paramInt2 == 0) {
        return 0;
      }
      return fill(paramArrayOfChar, paramInt1, paramInt1 + paramInt2);
    }
  }
  
  public boolean ready()
    throws IOException
  {
    synchronized (this.lock)
    {
      ensureOpen();
      return (this.nextByte < this.nBytes) || (inReady());
    }
  }
  
  public void close()
    throws IOException
  {
    synchronized (this.lock)
    {
      if (this.in == null) {
        return;
      }
      this.in.close();
      this.in = null;
      this.bb = null;
      this.btc = null;
    }
  }
}


/* Location:           D:\tmp\oasql.jar
 * Qualified Name:     com.asql.core.CommandStreamReader
 * JD-Core Version:    0.7.0.1
 */