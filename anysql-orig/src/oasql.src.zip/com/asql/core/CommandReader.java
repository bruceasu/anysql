package com.asql.core;

import java.io.IOException;

public abstract interface CommandReader
{
  public abstract String readline()
    throws IOException;
  
  public abstract String readPassword()
    throws Exception;
  
  public abstract String getWorkingDir();
  
  public abstract void setWorkingDir(String paramString);
}


/* Location:           D:\tmp\oasql.jar
 * Qualified Name:     com.asql.core.CommandReader
 * JD-Core Version:    0.7.0.1
 */