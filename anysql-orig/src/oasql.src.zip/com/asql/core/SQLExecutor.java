package com.asql.core;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLWarning;

public class SQLExecutor
{
  public static final void clearWarnings(Connection paramConnection, CommandLog paramCommandLog)
  {
    try
    {
      SQLWarning localSQLWarning = paramConnection.getWarnings();
      if (localSQLWarning != null)
      {
        paramCommandLog.print(localSQLWarning);
        while ((localSQLWarning = localSQLWarning.getNextWarning()) != null) {
          paramCommandLog.print(localSQLWarning);
        }
      }
      paramConnection.clearWarnings();
    }
    catch (SQLException localSQLException)
    {
      paramCommandLog.print(localSQLException);
    }
  }
  
  private static final void doTransaction(Connection paramConnection, boolean paramBoolean, CommandLog paramCommandLog)
  {
    try
    {
      if (paramBoolean) {
        paramConnection.commit();
      } else {
        paramConnection.rollback();
      }
      if (paramBoolean) {
        paramCommandLog.println("Transaction commited.");
      } else {
        paramCommandLog.println("Transaction rollbacked.");
      }
    }
    catch (SQLException localSQLException)
    {
      paramCommandLog.print(localSQLException);
    }
    clearWarnings(paramConnection, paramCommandLog);
  }
  
  public static final void doCommit(Connection paramConnection, CommandLog paramCommandLog)
  {
    doTransaction(paramConnection, true, paramCommandLog);
  }
  
  public static final void doRollback(Connection paramConnection, CommandLog paramCommandLog)
  {
    doTransaction(paramConnection, false, paramCommandLog);
  }
  
  public static final void executeSQL(Connection paramConnection, String paramString, CommandLog paramCommandLog)
  {
    VariableTable localVariableTable = new VariableTable();
    executeSQL(paramConnection, paramString, localVariableTable, paramCommandLog);
  }
  
  public static final void executeSQL(Connection paramConnection, String paramString, VariableTable paramVariableTable, CommandLog paramCommandLog)
  {
    int i = 0;
    int j = -1;
    boolean bool = false;
    ResultSet localResultSet = null;
    SQLStatement localSQLStatement = null;
    if (paramString == null) {
      return;
    }
    if (paramString.equalsIgnoreCase("COMMIT"))
    {
      doCommit(paramConnection, paramCommandLog);
      return;
    }
    if (paramString.equalsIgnoreCase("ROLLBACK"))
    {
      doRollback(paramConnection, paramCommandLog);
      return;
    }
    try
    {
      if ((paramString.endsWith("/G")) || (paramString.endsWith("/g")))
      {
        paramCommandLog.setFormDisplay(true);
        localSQLStatement = DBOperation.prepareStatement(paramConnection, paramString.substring(1, paramString.length() - 2), paramVariableTable);
      }
      else
      {
        localSQLStatement = DBOperation.prepareStatement(paramConnection, paramString, paramVariableTable);
      }
      if (localSQLStatement.stmt == null) {
        return;
      }
      localSQLStatement.bind(paramVariableTable);
      bool = localSQLStatement.stmt.execute();
      do
      {
        if (bool)
        {
          localResultSet = localSQLStatement.stmt.getResultSet();
          paramCommandLog.print(localResultSet);
          localResultSet.close();
        }
        else
        {
          try
          {
            j = localSQLStatement.stmt.getUpdateCount();
          }
          catch (SQLException localSQLException1)
          {
            j = -1;
          }
          if (j >= 0) {
            paramCommandLog.print(j);
          } else {
            paramCommandLog.println("Command completed.");
          }
        }
        bool = localSQLStatement.stmt.getMoreResults();
      } while ((bool) || (j != -1));
    }
    catch (SQLException localSQLException2)
    {
      paramCommandLog.print(localSQLException2);
    }
    finally
    {
      if ((localSQLStatement != null) && (localSQLStatement.stmt != null)) {
        try
        {
          localSQLStatement.stmt.close();
        }
        catch (SQLException localSQLException3) {}
      }
    }
    paramCommandLog.setFormDisplay(false);
    clearWarnings(paramConnection, paramCommandLog);
  }
  
  public static final void executeCall(Connection paramConnection, String paramString, CommandLog paramCommandLog)
  {
    VariableTable localVariableTable = new VariableTable();
    executeCall(paramConnection, paramString, localVariableTable, paramCommandLog);
  }
  
  public static final void executeCall(Connection paramConnection, String paramString, VariableTable paramVariableTable, CommandLog paramCommandLog)
  {
    int i = 0;
    int j = -1;
    boolean bool = false;
    ResultSet localResultSet = null;
    SQLCallable localSQLCallable = null;
    if (paramString == null) {
      return;
    }
    if (paramString.equalsIgnoreCase("COMMIT"))
    {
      doCommit(paramConnection, paramCommandLog);
      return;
    }
    if (paramString.equalsIgnoreCase("ROLLBACK"))
    {
      doRollback(paramConnection, paramCommandLog);
      return;
    }
    try
    {
      localSQLCallable = DBOperation.prepareCall(paramConnection, paramString, paramVariableTable);
      if (localSQLCallable.stmt == null) {
        return;
      }
      localSQLCallable.bind(paramVariableTable);
      bool = localSQLCallable.stmt.execute();
      localSQLCallable.fetch(paramVariableTable);
      do
      {
        if (bool)
        {
          localResultSet = localSQLCallable.stmt.getResultSet();
          paramCommandLog.print(localResultSet);
          localResultSet.close();
        }
        else
        {
          try
          {
            j = localSQLCallable.stmt.getUpdateCount();
          }
          catch (SQLException localSQLException1)
          {
            j = -1;
          }
          if (j >= 0) {
            paramCommandLog.print(j);
          } else {
            paramCommandLog.println("Command completed.");
          }
        }
        bool = localSQLCallable.stmt.getMoreResults();
      } while ((bool) || (j != -1));
    }
    catch (SQLException localSQLException2)
    {
      paramCommandLog.print(localSQLException2);
    }
    finally
    {
      if ((localSQLCallable != null) && (localSQLCallable.stmt != null)) {
        try
        {
          localSQLCallable.stmt.close();
        }
        catch (SQLException localSQLException3) {}
      }
    }
    clearWarnings(paramConnection, paramCommandLog);
  }
}


/* Location:           D:\tmp\oasql.jar
 * Qualified Name:     com.asql.core.SQLExecutor
 * JD-Core Version:    0.7.0.1
 */