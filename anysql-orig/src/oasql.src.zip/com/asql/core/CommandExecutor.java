package com.asql.core;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.io.Reader;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import sun.misc.Signal;
import sun.misc.SignalHandler;

public abstract class CommandExecutor
{
  public static final int SQL_QUERY_TIMEOUT = 3600;
  private int _debug_level = 0;
  protected int exit_show_loop = 0;
  protected Statement current_stmt = null;
  protected ResultSet current_rset = null;
  private Process current_pid = null;
  private CtrlC signal_handler = new CtrlC();
  private boolean show_complete = true;
  private int fetch_size = 100;
  private boolean echo_on = true;
  private boolean term_out = true;
  
  public final int getDebugLevel()
  {
    return this._debug_level;
  }
  
  public final void setDebugLevel(int paramInt)
  {
    this._debug_level = paramInt;
  }
  
  public final boolean getEcho()
  {
    return this.echo_on;
  }
  
  public final void setTermout(boolean paramBoolean)
  {
    this.term_out = paramBoolean;
  }
  
  public final boolean getTermout()
  {
    return this.term_out;
  }
  
  public final void setFetchSize(int paramInt)
  {
    this.fetch_size = paramInt;
    if (paramInt < 1) {
      this.fetch_size = 1;
    }
    if (paramInt > 1000) {
      this.fetch_size = 1000;
    }
  }
  
  public abstract boolean execute(Command paramCommand);
  
  public abstract CommandLog getCommandLog();
  
  public abstract void setCommandLog(CommandLog paramCommandLog);
  
  public abstract CommandReader getCommandReader();
  
  public abstract void setCommandReader(CommandReader paramCommandReader);
  
  public abstract CMDType getCommandType();
  
  public abstract void showVersion();
  
  public abstract boolean isConnected();
  
  public abstract void disconnect();
  
  public abstract String getLastCommand();
  
  protected final String removeNewLine(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    for (int i = arrayOfChar.length - 1; (i >= 0) && ((arrayOfChar[i] == '\r') || (arrayOfChar[i] == '\n') || (arrayOfChar[i] == '\t') || (arrayOfChar[i] == ' ')); i--) {}
    if (i >= 0) {
      return String.valueOf(arrayOfChar, 0, i + 1);
    }
    return "";
  }
  
  public final void cancel()
  {
    this.exit_show_loop = 1;
    if (this.current_pid != null)
    {
      this.current_pid.destroy();
      this.current_pid = null;
    }
    if (this.current_rset != null)
    {
      try
      {
        this.current_rset.close();
      }
      catch (SQLException localSQLException1) {}
      this.current_rset = null;
    }
    if (this.current_stmt != null)
    {
      try
      {
        this.current_stmt.cancel();
      }
      catch (SQLException localSQLException2)
      {
        getCommandLog().print(localSQLException2);
      }
      this.current_stmt = null;
    }
  }
  
  public final void setShowComplete(boolean paramBoolean)
  {
    this.show_complete = paramBoolean;
  }
  
  public final void setEcho(boolean paramBoolean)
  {
    this.echo_on = paramBoolean;
  }
  
  public static final void readBuffer(RandomAccessFile paramRandomAccessFile, byte[] paramArrayOfByte, long paramLong)
    throws IOException
  {
    paramRandomAccessFile.seek(paramLong);
    paramRandomAccessFile.readFully(paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  public static final void writeBuffer(RandomAccessFile paramRandomAccessFile, byte[] paramArrayOfByte, long paramLong)
    throws IOException
  {
    paramRandomAccessFile.seek(paramLong);
    paramRandomAccessFile.write(paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  public static final byte[] hex2byte(char[] paramArrayOfChar)
  {
    if ((paramArrayOfChar == null) || (paramArrayOfChar.length < 2)) {
      return new byte[0];
    }
    byte[] arrayOfByte = new byte[paramArrayOfChar.length / 2];
    for (int i = 0; i < paramArrayOfChar.length / 2; i++) {
      arrayOfByte[i] = Byte.parseByte(String.valueOf(paramArrayOfChar, i * 2, 2), 16);
    }
    return arrayOfByte;
  }
  
  public void editHex(String paramString1, String paramString2, String paramString3)
  {
    if ((paramString2 == null) || (paramString3 == null)) {
      return;
    }
    try
    {
      long l = Long.valueOf(paramString2, 16).longValue();
      byte[] arrayOfByte = hex2byte(paramString3.trim().toCharArray());
      File localFile = new File(paramString1);
      if ((!localFile.exists()) || (!localFile.isFile()) || (!localFile.canWrite()))
      {
        getCommandLog().println("Cannot access file : " + paramString1);
        return;
      }
      RandomAccessFile localRandomAccessFile = new RandomAccessFile(localFile, "rw");
      writeBuffer(localRandomAccessFile, arrayOfByte, l);
      localRandomAccessFile.close();
    }
    catch (IOException localIOException)
    {
      getCommandLog().print(localIOException);
    }
    catch (Exception localException)
    {
      getCommandLog().println("Invalid hexial address or value.");
    }
  }
  
  public final void viewHex(String paramString, int paramInt1, int paramInt2, int paramInt3)
  {
    File localFile = new File(paramString);
    if ((!localFile.exists()) || (!localFile.isFile()) || (!localFile.canRead()))
    {
      getCommandLog().println("Cannot access file : " + paramString);
      return;
    }
    if (paramInt1 < 0) {
      paramInt1 = 0;
    }
    if (paramInt2 < 1) {
      paramInt2 = 1;
    }
    if (paramInt2 > 8) {
      paramInt2 = 8;
    }
    if (paramInt3 < 1) {
      paramInt3 = 1;
    }
    if (paramInt3 > 32) {
      paramInt3 = 32;
    }
    StringBuffer localStringBuffer1 = new StringBuffer();
    StringBuffer localStringBuffer2 = new StringBuffer();
    int i = 0;
    byte[] arrayOfByte = new byte[paramInt2 * paramInt3 * 1024];
    RandomAccessFile localRandomAccessFile = null;
    try
    {
      localRandomAccessFile = new RandomAccessFile(localFile, "r");
      localRandomAccessFile.seek(paramInt1 * paramInt3 * 1024);
      i = localRandomAccessFile.read(arrayOfByte);
      if (i > 0)
      {
        getCommandLog().println();
        getCommandLog().println("BLOCK#=0");
        getCommandLog().println("          -0 -1 -2 -3 -4 -5 -6 -7  -8 -9 -A -B -C -D -E -F  0123456789ABCDEF");
        getCommandLog().println("--------- -----------------------  -----------------------  ----------------");
        for (int j = 0; j < i; j++)
        {
          if ((j > 0) && (j % 16 == 0))
          {
            getCommandLog().print(localStringBuffer1.toString() + " ");
            getCommandLog().println(localStringBuffer2.toString());
            localStringBuffer1.delete(0, localStringBuffer1.length());
            localStringBuffer2.delete(0, localStringBuffer2.length());
            if (j % 256 == 0) {
              getCommandLog().println();
            }
            if (j % 512 == 0)
            {
              if (j % (paramInt3 * 1024) == 0) {
                getCommandLog().println("BLOCK#=" + j / (paramInt3 * 1024));
              }
              getCommandLog().println("          -0 -1 -2 -3 -4 -5 -6 -7  -8 -9 -A -B -C -D -E -F  0123456789ABCDEF");
              getCommandLog().println("--------- -----------------------  -----------------------  ----------------");
            }
          }
          else if ((j > 0) && (j % 8 == 0))
          {
            localStringBuffer1.append(" ");
          }
          if (j % 16 == 0)
          {
            localStringBuffer1.append(Integer.toHexString(j + paramInt1 * 1024 >> 28 & 0xF));
            localStringBuffer1.append(Integer.toHexString(j + paramInt1 * 1024 >> 24 & 0xF));
            localStringBuffer1.append(Integer.toHexString(j + paramInt1 * 1024 >> 20 & 0xF));
            localStringBuffer1.append(Integer.toHexString(j + paramInt1 * 1024 >> 16 & 0xF));
            localStringBuffer1.append(Integer.toHexString(j + paramInt1 * 1024 >> 12 & 0xF));
            localStringBuffer1.append(Integer.toHexString(j + paramInt1 * 1024 >> 8 & 0xF));
            localStringBuffer1.append(Integer.toHexString(j + paramInt1 * 1024 >> 4 & 0xF));
            localStringBuffer1.append("0: ");
          }
          localStringBuffer1.append(Integer.toHexString(arrayOfByte[j] >> 4 & 0xF));
          localStringBuffer1.append(Integer.toHexString(arrayOfByte[j] & 0xF));
          if ((arrayOfByte[j] != 13) && (arrayOfByte[j] != 10) && (arrayOfByte[j] != 7) && (arrayOfByte[j] != 9) && (arrayOfByte[j] != 0) && (arrayOfByte[j] < 128) && (arrayOfByte[j] > 0) && (!Character.isISOControl((char)arrayOfByte[j]))) {
            localStringBuffer2.append((char)arrayOfByte[j]);
          } else {
            localStringBuffer2.append('.');
          }
          localStringBuffer1.append(" ");
        }
        getCommandLog().print(localStringBuffer1.toString() + " ");
        getCommandLog().println(localStringBuffer2.toString());
        getCommandLog().println();
      }
      else
      {
        getCommandLog().println("Skip exceed file size.");
      }
      localRandomAccessFile.close();
      return;
    }
    catch (IOException localIOException1)
    {
      getCommandLog().print(localIOException1);
      try
      {
        if (localRandomAccessFile != null) {
          localRandomAccessFile.close();
        }
      }
      catch (IOException localIOException2) {}
    }
  }
  
  protected void host(String paramString)
    throws IOException
  {
    String[] arrayOfString = null;
    String str1 = paramString;
    if (JavaVM.OS.startsWith("Windows")) {
      str1 = "CMD /C " + paramString;
    }
    File localFile = new File(JavaVM.USER_DIRECTORY);
    Process localProcess = Runtime.getRuntime().exec(str1, arrayOfString, localFile);
    this.current_pid = localProcess;
    InputStream localInputStream1 = localProcess.getInputStream();
    InputStream localInputStream2 = localProcess.getErrorStream();
    BufferedReader localBufferedReader1 = new BufferedReader(new InputStreamReader(localInputStream1));
    BufferedReader localBufferedReader2 = new BufferedReader(new InputStreamReader(localInputStream2));
    String str2 = null;
    while ((str2 = localBufferedReader1.readLine()) != null) {
      getCommandLog().println(str2);
    }
    while ((str2 = localBufferedReader2.readLine()) != null) {
      getCommandLog().println(str2);
    }
    try
    {
      localProcess.waitFor();
    }
    catch (InterruptedException localInterruptedException)
    {
      getCommandLog().println("process was interrupted");
    }
    localProcess.destroy();
    localBufferedReader1.close();
    localBufferedReader2.close();
    this.current_pid = null;
  }
  
  public static final long getlong(String paramString, long paramLong)
  {
    try
    {
      return Long.valueOf(paramString).longValue();
    }
    catch (NumberFormatException localNumberFormatException) {}
    return paramLong;
  }
  
  public static final int getint(String paramString, int paramInt)
  {
    try
    {
      return Integer.valueOf(paramString).intValue();
    }
    catch (NumberFormatException localNumberFormatException) {}
    return paramInt;
  }
  
  protected final String lpad(String paramString, int paramInt)
  {
    return getFixedWidth(paramString, paramInt, true);
  }
  
  protected final String rpad(String paramString, int paramInt)
  {
    return getFixedWidth(paramString, paramInt, false);
  }
  
  private String getFixedWidth(String paramString, int paramInt, boolean paramBoolean)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    if ((paramBoolean) && (paramString != null)) {
      localStringBuffer.append(paramString);
    }
    for (int i = paramString == null ? 0 : paramString.getBytes().length; i < paramInt; i++) {
      localStringBuffer.append(" ");
    }
    if ((!paramBoolean) && (paramString != null)) {
      localStringBuffer.append(paramString);
    }
    return localStringBuffer.toString();
  }
  
  protected final int commandAt(String[] paramArrayOfString1, String[] paramArrayOfString2)
  {
    if (paramArrayOfString2 == null) {
      return -1;
    }
    if (paramArrayOfString2.length == 0) {
      return -1;
    }
    if (paramArrayOfString1.length == 0) {
      return -1;
    }
    int i = 0;
    int j = 0;
    int k = 0;
    for (i = 0; i < paramArrayOfString1.length; i++)
    {
      j = 0;
      String[] arrayOfString = TextUtils.toStringArray(TextUtils.getWords(paramArrayOfString1[i]));
      if (arrayOfString.length <= paramArrayOfString2.length)
      {
        k = 1;
        for (j = 0; j < arrayOfString.length; j++) {
          if (!arrayOfString[j].equalsIgnoreCase(paramArrayOfString2[j]))
          {
            k = 0;
            break;
          }
        }
        if (k != 0) {
          return i;
        }
      }
    }
    return -1;
  }
  
  protected final void debug(String paramString, SQLQuery paramSQLQuery, VariableTable paramVariableTable)
  {
    if (this._debug_level > 0)
    {
      CommandLog localCommandLog = getCommandLog();
      localCommandLog.println("==================== DEBUG L=" + this._debug_level + " ====================");
      localCommandLog.println("Time: " + new java.util.Date());
      localCommandLog.println(paramString);
      if ((this._debug_level > 1) && (paramSQLQuery != null) && (paramSQLQuery.getParamNames().length > 0))
      {
        localCommandLog.println();
        localCommandLog.println("BIND VARIABLE:");
        for (int i = 0; i < paramSQLQuery.getParamNames().length; i++)
        {
          localCommandLog.print(paramSQLQuery.getParamNames()[i]);
          localCommandLog.print(" = ");
          localCommandLog.println(paramSQLQuery.getParamTypes()[i]);
        }
      }
      if ((this._debug_level > 1) && (paramVariableTable != null))
      {
        String[] arrayOfString = paramVariableTable.getNames();
        if (arrayOfString.length > 0)
        {
          localCommandLog.println();
          localCommandLog.println("HOST VARIABLE:");
          for (int j = 0; j < arrayOfString.length; j++)
          {
            localCommandLog.print(arrayOfString[j]);
            localCommandLog.print("=");
            Object localObject = paramVariableTable.getValue(arrayOfString[j]);
            if (localObject != null) {
              localCommandLog.println(localObject.toString());
            } else {
              localCommandLog.println("(null)");
            }
          }
        }
      }
      localCommandLog.println("==================== DEBUG END ===================");
      localCommandLog.println();
    }
  }
  
  protected abstract void doServerMessage()
    throws SQLException;
  
  public abstract DBRowCache executeQuery(String paramString, VariableTable paramVariableTable)
    throws SQLException;
  
  public abstract DBRowCache executeQuery(String paramString, VariableTable paramVariableTable, int paramInt)
    throws SQLException;
  
  public final DBRowCache executeQuery(Connection paramConnection, String paramString, VariableTable paramVariableTable)
    throws SQLException
  {
    return executeQuery(paramConnection, paramString, paramVariableTable, 10000);
  }
  
  public final DBRowCache executeQuery(SQLStatement paramSQLStatement, VariableTable paramVariableTable)
    throws SQLException
  {
    return executeQuery(paramSQLStatement, paramVariableTable, 10000);
  }
  
  public int fetch(ResultSet paramResultSet, DBRowCache paramDBRowCache)
    throws SQLException
  {
    return fetch(paramResultSet, paramDBRowCache, 100);
  }
  
  public int fetch(ResultSet paramResultSet, DBRowCache paramDBRowCache, int paramInt)
    throws SQLException
  {
    int i = 0;
    int j = 0;
    int k = 0;
    byte[] arrayOfByte1 = new byte[8192];
    char[] arrayOfChar1 = new char[4096];
    byte[] arrayOfByte2 = new byte[65536];
    char[] arrayOfChar2 = new char[65536];
    Object localObject2;
    if (paramDBRowCache.getColumnCount() == 0)
    {
      localObject2 = paramResultSet.getMetaData();
      for (i = 1; i <= ((ResultSetMetaData)localObject2).getColumnCount(); i++) {
        if (((ResultSetMetaData)localObject2).getColumnName(i) != null)
        {
          if (paramDBRowCache.findColumn(((ResultSetMetaData)localObject2).getColumnName(i)) == 0)
          {
            paramDBRowCache.addColumn(((ResultSetMetaData)localObject2).getColumnName(i), ((ResultSetMetaData)localObject2).getColumnType(i));
          }
          else
          {
            for (j = 1; paramDBRowCache.findColumn(((ResultSetMetaData)localObject2).getColumnName(i) + "_" + j) != 0; j++) {}
            paramDBRowCache.addColumn(((ResultSetMetaData)localObject2).getColumnName(i) + "_" + j, ((ResultSetMetaData)localObject2).getColumnType(i));
          }
        }
        else
        {
          for (j = 1; paramDBRowCache.findColumn("NULL" + j) != 0; j++) {}
          paramDBRowCache.addColumn("NULL" + j, ((ResultSetMetaData)localObject2).getColumnType(i));
        }
      }
    }
    if (paramDBRowCache.getColumnCount() == 0) {
      return 0;
    }
    Object[] arrayOfObject;
    for (i = paramDBRowCache.getRowCount(); (i < paramInt) && (paramResultSet.next()); i = paramDBRowCache.appendRow(arrayOfObject))
    {
      arrayOfObject = new Object[paramDBRowCache.getColumnCount()];
      for (j = 1; j <= paramDBRowCache.getColumnCount(); j++)
      {
        Object localObject1 = null;
        int m;
        Object localObject3;
        Object localObject4;
        switch (paramDBRowCache.getColumnType(j))
        {
        case -1: 
          localObject2 = paramResultSet.getCharacterStream(j);
          if (localObject2 != null) {
            try
            {
              m = ((Reader)localObject2).read(arrayOfChar2);
              if (m > 0) {
                localObject1 = String.valueOf(arrayOfChar2, 0, m);
              }
              ((Reader)localObject2).close();
            }
            catch (IOException localIOException1) {}
          }
          break;
        case -4: 
          InputStream localInputStream1 = paramResultSet.getBinaryStream(j);
          if (localInputStream1 != null) {
            try
            {
              m = localInputStream1.read(arrayOfByte2);
              if (m > 0) {
                localObject1 = new String(arrayOfByte2, 0, m);
              }
              localInputStream1.close();
            }
            catch (IOException localIOException2) {}
          }
          break;
        case 2005: 
          Clob localClob = paramResultSet.getClob(j);
          if (localClob != null)
          {
            localObject3 = localClob.getCharacterStream();
            if (localObject3 != null) {
              try
              {
                m = ((Reader)localObject3).read(arrayOfChar2);
                if (m > 0) {
                  localObject1 = String.valueOf(arrayOfChar2, 0, m);
                }
                ((Reader)localObject3).close();
              }
              catch (IOException localIOException3) {}
            }
          }
          break;
        case 2004: 
          localObject3 = paramResultSet.getBlob(j);
          if (localObject3 != null)
          {
            localObject4 = ((Blob)localObject3).getBinaryStream();
            if (localObject4 != null) {
              try
              {
                m = ((InputStream)localObject4).read(arrayOfByte2);
                if (m > 0) {
                  localObject1 = new String(arrayOfByte2, 0, m);
                }
                ((InputStream)localObject4).close();
              }
              catch (IOException localIOException4) {}
            }
          }
          break;
        case 1: 
        case 12: 
          localObject4 = paramResultSet.getCharacterStream(j);
          if (localObject4 != null) {
            try
            {
              m = ((Reader)localObject4).read(arrayOfChar1);
              if (paramDBRowCache.getColumnType(j) == 1) {
                while ((m > 0) && (arrayOfChar1[(m - 1)] == ' ')) {
                  m--;
                }
              }
              if (m > 0) {
                localObject1 = String.valueOf(arrayOfChar1, 0, m);
              }
              ((Reader)localObject4).close();
            }
            catch (IOException localIOException5) {}
          }
          break;
        case -3: 
        case -2: 
          InputStream localInputStream2 = paramResultSet.getAsciiStream(j);
          if (localInputStream2 != null) {
            try
            {
              m = localInputStream2.read(arrayOfByte1);
              if (paramDBRowCache.getColumnType(j) == -2) {
                while ((m > 0) && (arrayOfByte1[(m - 1)] == 32)) {
                  m--;
                }
              }
              if (m > 0) {
                localObject1 = new String(arrayOfByte1, 0, m);
              }
              localInputStream2.close();
            }
            catch (IOException localIOException6) {}
          }
          break;
        case 91: 
          localObject1 = paramResultSet.getDate(j);
          break;
        case 92: 
          localObject1 = paramResultSet.getTime(j);
          break;
        case -102: 
        case -101: 
        case 93: 
          localObject1 = paramResultSet.getTimestamp(j);
          break;
        case -7: 
        case -6: 
        case -5: 
        case 2: 
        case 3: 
        case 4: 
        case 5: 
        case 6: 
        case 7: 
        case 8: 
        case 16: 
          localObject1 = paramResultSet.getObject(j);
          break;
        case -14: 
        case -13: 
        case -10: 
        case 0: 
        case 70: 
        case 1111: 
        case 2000: 
        case 2001: 
        case 2002: 
        case 2003: 
        case 2006: 
          localObject1 = "N/A";
          break;
        default: 
          localObject1 = paramResultSet.getString(j);
        }
        arrayOfObject[(j - 1)] = localObject1;
      }
    }
    return i;
  }
  
  public final DBRowCache executeQuery(SQLStatement paramSQLStatement, VariableTable paramVariableTable, int paramInt)
    throws SQLException
  {
    ResultSet localResultSet = null;
    Object localObject = null;
    SimpleDBRowCache localSimpleDBRowCache = new SimpleDBRowCache();
    try
    {
      debug(paramSQLStatement.getDestSQL(), null, paramVariableTable);
      paramSQLStatement.stmt.setMaxRows(paramInt);
      paramSQLStatement.bind(paramVariableTable);
      this.current_stmt = paramSQLStatement.stmt;
      localResultSet = paramSQLStatement.stmt.executeQuery();
      this.current_rset = localResultSet;
      fetch(localResultSet, localSimpleDBRowCache, paramInt);
      localResultSet.close();
      this.current_rset = null;
      this.current_stmt = null;
    }
    catch (SQLException localSQLException1)
    {
      localObject = localSQLException1;
    }
    try
    {
      if (localResultSet != null) {
        localResultSet.close();
      }
    }
    catch (SQLException localSQLException2) {}
    if (localObject != null) {
      throw localObject;
    }
    return localSimpleDBRowCache;
  }
  
  public final DBRowCache executeQuery(Connection paramConnection, String paramString, VariableTable paramVariableTable, int paramInt)
    throws SQLException
  {
    SQLStatement localSQLStatement = null;
    ResultSet localResultSet = null;
    Object localObject = null;
    SimpleDBRowCache localSimpleDBRowCache = new SimpleDBRowCache();
    try
    {
      localSQLStatement = prepareStatement(paramConnection, paramString, paramVariableTable);
      localSQLStatement.stmt.setMaxRows(paramInt);
      localSQLStatement.bind(paramVariableTable);
      this.current_stmt = localSQLStatement.stmt;
      localResultSet = localSQLStatement.stmt.executeQuery();
      this.current_rset = localResultSet;
      fetch(localResultSet, localSimpleDBRowCache, paramInt);
      localResultSet.close();
      this.current_rset = null;
      this.current_stmt = null;
    }
    catch (SQLException localSQLException1)
    {
      localObject = localSQLException1;
    }
    try
    {
      if (localResultSet != null) {
        localResultSet.close();
      }
    }
    catch (SQLException localSQLException2) {}
    try
    {
      if ((localSQLStatement != null) && (localSQLStatement.stmt != null)) {
        localSQLStatement.stmt.close();
      }
    }
    catch (SQLException localSQLException3) {}
    if (localObject != null) {
      throw localObject;
    }
    return localSimpleDBRowCache;
  }
  
  protected final SQLStatement prepareScript(Connection paramConnection, String paramString, VariableTable paramVariableTable)
    throws SQLException
  {
    PreparedStatement localPreparedStatement = null;
    String[] arrayOfString = new String[0];
    String str = paramVariableTable.parseString(paramString, '&', '\\');
    debug(str, null, paramVariableTable);
    localPreparedStatement = paramConnection.prepareStatement(str, 1003, 1007);
    localPreparedStatement.setQueryTimeout(3600);
    localPreparedStatement.setFetchSize(this.fetch_size);
    return new SQLStatement(localPreparedStatement, new SQLQuery(paramString, str, arrayOfString, arrayOfString));
  }
  
  protected final SQLStatement prepareStatement(Connection paramConnection, String paramString, VariableTable paramVariableTable)
    throws SQLException
  {
    return prepareStatement(paramConnection, paramString, paramVariableTable, 1003, 1007);
  }
  
  protected final SQLStatement prepareStatement(Connection paramConnection, String paramString, VariableTable paramVariableTable, int paramInt1, int paramInt2)
    throws SQLException
  {
    PreparedStatement localPreparedStatement = null;
    SQLQuery localSQLQuery = SQLConvert.parseSQL(paramString == null ? "" : paramString, paramVariableTable);
    debug(localSQLQuery.getDestSQL(), localSQLQuery, paramVariableTable);
    localPreparedStatement = paramConnection.prepareStatement(localSQLQuery.getDestSQL(), paramInt1, paramInt2);
    localPreparedStatement.setQueryTimeout(3600);
    localPreparedStatement.setFetchSize(this.fetch_size);
    return new SQLStatement(localPreparedStatement, localSQLQuery);
  }
  
  protected final SQLCallable prepareCall(Connection paramConnection, String paramString, VariableTable paramVariableTable)
    throws SQLException
  {
    return prepareCall(paramConnection, paramString, paramVariableTable, 1003, 1007);
  }
  
  protected final SQLCallable prepareCall(Connection paramConnection, String paramString, VariableTable paramVariableTable, int paramInt1, int paramInt2)
    throws SQLException
  {
    CallableStatement localCallableStatement = null;
    SQLQuery localSQLQuery = SQLConvert.parseCall(paramString == null ? "" : paramString, paramVariableTable);
    debug(localSQLQuery.getDestSQL(), localSQLQuery, paramVariableTable);
    localCallableStatement = paramConnection.prepareCall("{ " + localSQLQuery.getDestSQL() + " }", paramInt1, paramInt2);
    localCallableStatement.setQueryTimeout(3600);
    localCallableStatement.setFetchSize(this.fetch_size);
    return new SQLCallable(localCallableStatement, localSQLQuery);
  }
  
  protected void procDisabledCommand(Command paramCommand) {}
  
  protected void procUnknownCommand(Command paramCommand)
  {
    getCommandLog().println("Unknown command!");
  }
  
  public final void run(Command paramCommand)
    throws IOException
  {
    CommandLog localCommandLog = getCommandLog();
    CMDType localCMDType = getCommandType();
    CommandReader localCommandReader = getCommandReader();
    int i = -1;
    if (paramCommand.TYPE1 == 8) {
      return;
    }
    if ((paramCommand.TYPE1 != 11) && (paramCommand.TYPE1 != 12) && (paramCommand.TYPE1 != 14)) {
      if (paramCommand.TYPE1 == 10) {
        procUnknownCommand(paramCommand);
      } else if (paramCommand.TYPE1 == 18) {
        procDisabledCommand(paramCommand);
      } else if ((paramCommand.TYPE1 == 5) || (paramCommand.TYPE1 == 17) || (paramCommand.TYPE1 == 6))
      {
        if ((paramCommand.TYPE2 == 9) || (execute(paramCommand))) {}
      }
      else if (paramCommand.TYPE1 == 16)
      {
        if (execute(paramCommand)) {}
      }
      else if (isConnected())
      {
        if ((paramCommand.TYPE2 == 9) || (execute(paramCommand))) {}
      }
      else {
        localCommandLog.println("Database not connected!");
      }
    }
  }
  
  public final Command run(CommandReader paramCommandReader)
    throws IOException
  {
    CommandLog localCommandLog = getCommandLog();
    CMDType localCMDType = getCommandType();
    CommandReader localCommandReader = paramCommandReader;
    int i = -1;
    Command localCommand = new Command(8, 8, null);
    for (;;)
    {
      if ((this.echo_on) && (this.term_out)) {
        localCommand = localCMDType.readCommand(localCommandReader, localCommandLog, true);
      } else if (localCommandLog.getLogFile() != null) {
        localCommand = localCMDType.readCommand(localCommandReader, localCommandLog.getLogFile(), true);
      } else {
        localCommand = localCMDType.readCommand(localCommandReader);
      }
      if (localCommand.TYPE1 == 8) {
        return localCommand;
      }
      if ((localCommand.TYPE1 != 11) && (localCommand.TYPE1 != 12) && (localCommand.TYPE1 != 14)) {
        if (localCommand.TYPE1 == 10) {
          procUnknownCommand(localCommand);
        } else if (localCommand.TYPE1 == 18) {
          procDisabledCommand(localCommand);
        } else if ((localCommand.TYPE1 == 5) || (localCommand.TYPE1 == 17) || (localCommand.TYPE1 == 6))
        {
          if ((localCommand.TYPE2 != 9) && (!execute(localCommand))) {
            break;
          }
        }
        else if (localCommand.TYPE1 == 16)
        {
          if (!execute(localCommand)) {
            break;
          }
        }
        else if (isConnected())
        {
          if ((localCommand.TYPE2 != 9) && (!execute(localCommand))) {
            break;
          }
        }
        else {
          localCommandLog.println("Database not connected!");
        }
      }
    }
    return localCommand;
  }
  
  public final void run()
    throws IOException
  {
    CommandLog localCommandLog = getCommandLog();
    CMDType localCMDType = getCommandType();
    CommandReader localCommandReader = getCommandReader();
    Command localCommand = null;
    showVersion();
    int i = -1;
    try
    {
      Signal.handle(new Signal("INT"), this.signal_handler);
    }
    catch (Exception localException) {}
    for (;;)
    {
      System.runFinalization();
      localCommand = localCMDType.readCommand(localCommandReader, localCommandLog, false);
      System.gc();
      if (localCommand.TYPE1 == 8) {
        break;
      }
      if ((localCommand.TYPE1 != 11) && (localCommand.TYPE1 != 12) && (localCommand.TYPE1 != 14)) {
        if (localCommand.TYPE1 == 10) {
          procUnknownCommand(localCommand);
        } else if (localCommand.TYPE1 == 18) {
          procDisabledCommand(localCommand);
        } else if ((localCommand.TYPE1 == 5) || (localCommand.TYPE1 == 17) || (localCommand.TYPE1 == 6))
        {
          if ((localCommand.TYPE2 != 9) && (!execute(localCommand))) {
            break;
          }
        }
        else if (localCommand.TYPE1 == 16)
        {
          if (!execute(localCommand)) {
            break;
          }
        }
        else if (isConnected())
        {
          if ((localCommand.TYPE2 != 9) && (!execute(localCommand))) {
            break;
          }
        }
        else {
          localCommandLog.println("Database not connected!");
        }
      }
    }
    disconnect();
  }
  
  protected final void clearWarnings(Statement paramStatement, CommandLog paramCommandLog)
  {
    try
    {
      SQLWarning localSQLWarning = paramStatement.getWarnings();
      if (localSQLWarning != null) {
        paramCommandLog.print(localSQLWarning);
      }
      paramStatement.clearWarnings();
    }
    catch (SQLException localSQLException)
    {
      paramCommandLog.print(localSQLException);
    }
  }
  
  protected final void clearWarnings(Connection paramConnection, CommandLog paramCommandLog)
  {
    try
    {
      SQLWarning localSQLWarning = paramConnection.getWarnings();
      if (localSQLWarning != null) {
        paramCommandLog.print(localSQLWarning);
      }
      paramConnection.clearWarnings();
    }
    catch (SQLException localSQLException)
    {
      paramCommandLog.print(localSQLException);
    }
  }
  
  private final void doTransaction(Connection paramConnection, boolean paramBoolean, CommandLog paramCommandLog)
  {
    try
    {
      if (paramBoolean) {
        paramConnection.commit();
      } else {
        paramConnection.rollback();
      }
      if (paramBoolean) {
        paramCommandLog.println("Commit Succeed.");
      } else {
        paramCommandLog.println("Rollback Succeed.");
      }
    }
    catch (SQLException localSQLException)
    {
      paramCommandLog.print(localSQLException);
    }
    clearWarnings(paramConnection, paramCommandLog);
  }
  
  protected final void doCommit(Connection paramConnection, CommandLog paramCommandLog)
  {
    doTransaction(paramConnection, true, paramCommandLog);
  }
  
  protected final void doRollback(Connection paramConnection, CommandLog paramCommandLog)
  {
    doTransaction(paramConnection, false, paramCommandLog);
  }
  
  protected final void executeScript(Connection paramConnection, Command paramCommand, CommandLog paramCommandLog)
  {
    VariableTable localVariableTable = new VariableTable();
    executeScript(paramConnection, paramCommand, localVariableTable, paramCommandLog);
  }
  
  protected final void executeScript(Connection paramConnection, Command paramCommand, VariableTable paramVariableTable, CommandLog paramCommandLog)
  {
    int i = 0;
    int j = -1;
    boolean bool = false;
    ResultSet localResultSet = null;
    SQLStatement localSQLStatement = null;
    String str = paramCommand.COMMAND;
    if (str == null) {
      return;
    }
    if (str.equalsIgnoreCase("COMMIT"))
    {
      doCommit(paramConnection, paramCommandLog);
      return;
    }
    if (str.equalsIgnoreCase("ROLLBACK"))
    {
      doRollback(paramConnection, paramCommandLog);
      return;
    }
    try
    {
      localSQLStatement = prepareScript(paramConnection, str, paramVariableTable);
      if (localSQLStatement.stmt == null) {
        return;
      }
      localSQLStatement.bind(paramVariableTable);
      this.current_stmt = localSQLStatement.stmt;
      bool = localSQLStatement.stmt.execute();
      do
      {
        if (bool)
        {
          localResultSet = localSQLStatement.stmt.getResultSet();
          this.current_rset = localResultSet;
          paramCommandLog.print(localResultSet);
          this.current_rset = null;
          localResultSet.close();
        }
        else
        {
          doServerMessage();
          try
          {
            j = localSQLStatement.stmt.getUpdateCount();
          }
          catch (SQLException localSQLException1)
          {
            j = -1;
          }
          if (j >= 0)
          {
            paramCommandLog.print(j);
          }
          else if (this.show_complete)
          {
            String[] arrayOfString1 = TextUtils.toStringArray(TextUtils.getWords(paramCommand.COMMAND.substring(0, Math.min(100, paramCommand.COMMAND.length()))));
            String[] arrayOfString2 = getCommandType().getCommandHint();
            int k = commandAt(arrayOfString2, arrayOfString1);
            if (k != -1) {
              paramCommandLog.println(arrayOfString2[k] + " Succeed.");
            } else {
              paramCommandLog.println("Command completed.");
            }
          }
        }
        bool = localSQLStatement.stmt.getMoreResults();
      } while ((bool) || (j != -1));
    }
    catch (SQLException localSQLException2)
    {
      paramCommandLog.print(localSQLException2);
    }
    finally
    {
      if ((localSQLStatement != null) && (localSQLStatement.stmt != null))
      {
        clearWarnings(localSQLStatement.stmt, paramCommandLog);
        try
        {
          localSQLStatement.stmt.close();
        }
        catch (SQLException localSQLException3) {}
      }
    }
    this.current_stmt = null;
    this.current_rset = null;
    clearWarnings(paramConnection, paramCommandLog);
  }
  
  public long writeData(BufferedWriter paramBufferedWriter, ResultSet paramResultSet, String paramString1, String paramString2, boolean paramBoolean)
    throws SQLException, IOException
  {
    long l1 = 0L;
    String str1 = null;
    int i = 0;
    int j = 32768;
    byte[] arrayOfByte1 = new byte[8192];
    char[] arrayOfChar1 = new char[4096];
    byte[] arrayOfByte2 = new byte[65536];
    char[] arrayOfChar2 = new char[65536];
    long l2 = System.currentTimeMillis();
    ResultSetMetaData localResultSetMetaData = paramResultSet.getMetaData();
    int k = localResultSetMetaData.getColumnCount();
    int[] arrayOfInt = new int[k];
    SimpleDateFormat localSimpleDateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat localSimpleDateFormat2 = new SimpleDateFormat("HH:mm:ss");
    SimpleDateFormat localSimpleDateFormat3 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
    for (int m = 0; m < k; m++)
    {
      arrayOfInt[m] = localResultSetMetaData.getColumnType(m + 1);
      if (paramBoolean)
      {
        str1 = localResultSetMetaData.getColumnName(m + 1);
        if (str1 != null) {
          paramBufferedWriter.write(str1);
        }
        if (m < k - 1) {
          paramBufferedWriter.write(paramString1);
        }
      }
    }
    if (paramBoolean) {
      paramBufferedWriter.write(paramString2);
    }
    while (paramResultSet.next())
    {
      l1 += 1L;
      for (m = 1; m <= k; m++)
      {
        Object localObject1;
        Object localObject2;
        switch (arrayOfInt[(m - 1)])
        {
        case -1: 
          Reader localReader = paramResultSet.getCharacterStream(m);
          if (localReader != null) {
            try
            {
              i = localReader.read(arrayOfChar2);
              if (i > 0) {
                paramBufferedWriter.write(arrayOfChar2, 0, i);
              }
              localReader.close();
            }
            catch (IOException localIOException1) {}
          }
          break;
        case -4: 
          InputStream localInputStream1 = paramResultSet.getBinaryStream(m);
          if (localInputStream1 != null) {
            try
            {
              i = localInputStream1.read(arrayOfByte2);
              if (i > 0) {
                paramBufferedWriter.write(new String(arrayOfByte2, 0, i));
              }
              localInputStream1.close();
            }
            catch (IOException localIOException2) {}
          }
          break;
        case 2005: 
          Clob localClob = paramResultSet.getClob(m);
          if (localClob != null)
          {
            localObject1 = localClob.getCharacterStream();
            if (localObject1 != null) {
              try
              {
                i = ((Reader)localObject1).read(arrayOfChar2);
                if (i > 0) {
                  paramBufferedWriter.write(arrayOfChar2, 0, i);
                }
                ((Reader)localObject1).close();
              }
              catch (IOException localIOException3) {}
            }
          }
          break;
        case 2004: 
          localObject1 = paramResultSet.getBlob(m);
          if (localObject1 != null)
          {
            localObject2 = ((Blob)localObject1).getBinaryStream();
            if (localObject2 != null) {
              try
              {
                i = ((InputStream)localObject2).read(arrayOfByte2);
                if (i > 0) {
                  paramBufferedWriter.write(new String(arrayOfByte2, 0, i));
                }
                ((InputStream)localObject2).close();
              }
              catch (IOException localIOException4) {}
            }
          }
          break;
        case 1: 
        case 12: 
          localObject2 = paramResultSet.getCharacterStream(m);
          if (localObject2 != null) {
            try
            {
              i = ((Reader)localObject2).read(arrayOfChar1);
              if (arrayOfInt[(m - 1)] == 1) {
                while ((i > 0) && (arrayOfChar1[(i - 1)] == ' ')) {
                  i--;
                }
              }
              if (i > 0) {
                paramBufferedWriter.write(arrayOfChar1, 0, i);
              }
              ((Reader)localObject2).close();
            }
            catch (IOException localIOException5) {}
          }
          break;
        case -3: 
        case -2: 
          InputStream localInputStream2 = paramResultSet.getAsciiStream(m);
          if (localInputStream2 != null) {
            try
            {
              i = localInputStream2.read(arrayOfByte1);
              if (arrayOfInt[(m - 1)] == -2) {
                while ((i > 0) && (arrayOfByte1[(i - 1)] == 32)) {
                  i--;
                }
              }
              if (i > 0) {
                paramBufferedWriter.write(new String(arrayOfByte1, 0, i));
              }
              localInputStream2.close();
            }
            catch (IOException localIOException6) {}
          }
          break;
        case 91: 
          java.sql.Date localDate = paramResultSet.getDate(m);
          if (localDate != null) {
            paramBufferedWriter.write(localSimpleDateFormat1.format(localDate));
          }
          break;
        case 92: 
          Time localTime = paramResultSet.getTime(m);
          if (localTime != null) {
            paramBufferedWriter.write(localSimpleDateFormat2.format(localTime));
          }
          break;
        case 93: 
          Timestamp localTimestamp = paramResultSet.getTimestamp(m);
          if (localTimestamp != null) {
            paramBufferedWriter.write(localSimpleDateFormat3.format(localTimestamp));
          }
          break;
        case 0: 
        case 70: 
        case 1111: 
        case 2000: 
        case 2001: 
        case 2002: 
        case 2003: 
        case 2006: 
          break;
        default: 
          String str2 = paramResultSet.getString(m);
          if (str2 != null) {
            paramBufferedWriter.write(str2);
          }
          break;
        }
        if (m < k) {
          paramBufferedWriter.write(paramString1);
        } else {
          paramBufferedWriter.write(paramString2);
        }
      }
      if (l1 % 100000L == 0L) {
        getCommandLog().println(lpad(String.valueOf(l1), 12) + " rows writed in " + DBOperation.getElapsed(System.currentTimeMillis() - l2));
      }
    }
    if (l1 % 100000L != 0L) {
      getCommandLog().println(lpad(String.valueOf(l1), 12) + " rows writed in " + DBOperation.getElapsed(System.currentTimeMillis() - l2));
    }
    return l1;
  }
  
  protected final void executeSQL(Connection paramConnection, Command paramCommand, CommandLog paramCommandLog)
  {
    VariableTable localVariableTable = new VariableTable();
    executeSQL(paramConnection, paramCommand, localVariableTable, paramCommandLog);
  }
  
  protected final void executeSQL(Connection paramConnection, Command paramCommand, VariableTable paramVariableTable, CommandLog paramCommandLog)
  {
    int i = 0;
    int j = -1;
    boolean bool = false;
    ResultSet localResultSet = null;
    SQLStatement localSQLStatement = null;
    String str = paramCommand.COMMAND;
    if (str == null) {
      return;
    }
    if (str.equalsIgnoreCase("COMMIT"))
    {
      doCommit(paramConnection, paramCommandLog);
      return;
    }
    if (str.equalsIgnoreCase("ROLLBACK"))
    {
      doRollback(paramConnection, paramCommandLog);
      return;
    }
    try
    {
      if ((str.endsWith("/G")) || (str.endsWith("/g")) || (str.endsWith("\\G")) || (str.endsWith("\\g")))
      {
        paramCommandLog.setFormDisplay(true);
        localSQLStatement = prepareStatement(paramConnection, str.substring(0, str.length() - 2), paramVariableTable);
      }
      else
      {
        localSQLStatement = prepareStatement(paramConnection, str, paramVariableTable);
      }
      if (localSQLStatement.stmt == null) {
        return;
      }
      localSQLStatement.bind(paramVariableTable);
      this.current_stmt = localSQLStatement.stmt;
      bool = localSQLStatement.stmt.execute();
      do
      {
        if (bool)
        {
          localResultSet = localSQLStatement.stmt.getResultSet();
          this.current_rset = localResultSet;
          paramCommandLog.print(localResultSet);
          this.current_rset = null;
          localResultSet.close();
        }
        else
        {
          doServerMessage();
          try
          {
            j = localSQLStatement.stmt.getUpdateCount();
          }
          catch (SQLException localSQLException1)
          {
            j = -1;
          }
          if (j >= 0)
          {
            if ((paramCommand.TYPE1 == 0) || (paramCommand.TYPE1 == 1)) {
              paramCommandLog.print(j);
            }
          }
          else if ((paramCommand.TYPE1 != 0) && (paramCommand.TYPE1 != 1)) {
            if (paramCommand.TYPE1 == 13)
            {
              paramCommandLog.println("Procedure executed.");
            }
            else if (this.show_complete)
            {
              String[] arrayOfString1 = TextUtils.toStringArray(TextUtils.getWords(paramCommand.COMMAND.substring(0, Math.min(100, paramCommand.COMMAND.length()))));
              String[] arrayOfString2 = getCommandType().getCommandHint();
              int k = commandAt(arrayOfString2, arrayOfString1);
              if (k != -1) {
                paramCommandLog.println(arrayOfString2[k] + " Succeed.");
              } else {
                paramCommandLog.println("Command completed.");
              }
            }
          }
        }
        bool = localSQLStatement.stmt.getMoreResults();
      } while ((bool) || (j != -1));
    }
    catch (SQLException localSQLException2)
    {
      paramCommandLog.print(localSQLException2);
    }
    finally
    {
      if ((localSQLStatement != null) && (localSQLStatement.stmt != null))
      {
        clearWarnings(localSQLStatement.stmt, paramCommandLog);
        try
        {
          localSQLStatement.stmt.close();
        }
        catch (SQLException localSQLException3) {}
      }
    }
    this.current_rset = null;
    this.current_stmt = null;
    paramCommandLog.setFormDisplay(false);
    clearWarnings(paramConnection, paramCommandLog);
  }
  
  protected final void executeCall(Connection paramConnection, Command paramCommand, CommandLog paramCommandLog)
  {
    VariableTable localVariableTable = new VariableTable();
    executeCall(paramConnection, paramCommand, localVariableTable, paramCommandLog);
  }
  
  protected final void executeCall(Connection paramConnection, Command paramCommand, VariableTable paramVariableTable, CommandLog paramCommandLog)
  {
    int i = 0;
    int j = -1;
    boolean bool = false;
    ResultSet localResultSet = null;
    SQLCallable localSQLCallable = null;
    String str = paramCommand.COMMAND;
    if (str == null) {
      return;
    }
    if (str.equalsIgnoreCase("COMMIT"))
    {
      doCommit(paramConnection, paramCommandLog);
      return;
    }
    if (str.equalsIgnoreCase("ROLLBACK"))
    {
      doRollback(paramConnection, paramCommandLog);
      return;
    }
    try
    {
      localSQLCallable = prepareCall(paramConnection, str, paramVariableTable);
      if (localSQLCallable.stmt == null) {
        return;
      }
      localSQLCallable.bind(paramVariableTable);
      this.current_stmt = localSQLCallable.stmt;
      bool = localSQLCallable.stmt.execute();
      localSQLCallable.fetch(paramVariableTable);
      do
      {
        if (bool)
        {
          localResultSet = localSQLCallable.stmt.getResultSet();
          this.current_rset = localResultSet;
          paramCommandLog.print(localResultSet);
          this.current_rset = null;
          localResultSet.close();
        }
        else
        {
          doServerMessage();
          try
          {
            j = localSQLCallable.stmt.getUpdateCount();
          }
          catch (SQLException localSQLException1)
          {
            j = -1;
          }
          if (j >= 0)
          {
            if ((paramCommand.TYPE1 == 0) || (paramCommand.TYPE1 == 1)) {
              paramCommandLog.print(j);
            }
          }
          else if ((paramCommand.TYPE1 != 0) && (paramCommand.TYPE1 != 1) && (this.show_complete)) {
            paramCommandLog.println("Procedure executed.");
          }
        }
        bool = localSQLCallable.stmt.getMoreResults();
      } while ((bool) || (j != -1));
    }
    catch (SQLException localSQLException2)
    {
      paramCommandLog.print(localSQLException2);
    }
    finally
    {
      if ((localSQLCallable != null) && (localSQLCallable.stmt != null))
      {
        clearWarnings(localSQLCallable.stmt, paramCommandLog);
        try
        {
          localSQLCallable.stmt.close();
        }
        catch (SQLException localSQLException3) {}
      }
    }
    this.current_stmt = null;
    this.current_rset = null;
    clearWarnings(paramConnection, paramCommandLog);
  }
  
  protected final String parseRecord(String paramString)
  {
    if ((paramString == null) || (paramString.length() == 0)) {
      return "\r\n";
    }
    char[] arrayOfChar = paramString.toCharArray();
    StringBuffer localStringBuffer = new StringBuffer();
    for (int i = 0; i < arrayOfChar.length; i++) {
      if (arrayOfChar[i] == '\\')
      {
        if (i + 1 < arrayOfChar.length)
        {
          if (arrayOfChar[(i + 1)] == 'r')
          {
            localStringBuffer.append('\r');
          }
          else if (arrayOfChar[(i + 1)] == 'n')
          {
            localStringBuffer.append('\n');
          }
          else if (arrayOfChar[(i + 1)] == 't')
          {
            localStringBuffer.append('\t');
          }
          else if (arrayOfChar[(i + 1)] == 'b')
          {
            localStringBuffer.append('\b');
          }
          else if (arrayOfChar[(i + 1)] == 'f')
          {
            localStringBuffer.append('\f');
          }
          else if (arrayOfChar[(i + 1)] == 'x')
          {
            if (i + 3 < arrayOfChar.length) {
              try
              {
                char c = (char)Byte.parseByte(String.valueOf(arrayOfChar, i + 2, 2), 16);
                localStringBuffer.append(c);
                i += 3;
              }
              catch (NumberFormatException localNumberFormatException) {}
            }
          }
          else
          {
            localStringBuffer.append(arrayOfChar[i]);
            localStringBuffer.append(arrayOfChar[(i + 1)]);
          }
          i += 1;
        }
        else
        {
          localStringBuffer.append(arrayOfChar[i]);
        }
      }
      else {
        localStringBuffer.append(arrayOfChar[i]);
      }
    }
    return localStringBuffer.toString();
  }
  
  class CtrlC
    implements SignalHandler
  {
    CtrlC() {}
    
    public void handle(Signal paramSignal)
    {
      CommandExecutor.this.cancel();
    }
  }
}


/* Location:           D:\tmp\oasql.jar
 * Qualified Name:     com.asql.core.CommandExecutor
 * JD-Core Version:    0.7.0.1
 */