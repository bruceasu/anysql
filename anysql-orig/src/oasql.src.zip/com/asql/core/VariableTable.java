package com.asql.core;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Hashtable;

public final class VariableTable
{
  protected int var_count = 0;
  protected String[] var_name = new String[50];
  protected int[] var_type = new int[50];
  protected Object[] var_value = new Object[50];
  private Hashtable var_index = new Hashtable();
  private String date_format = "yyyy-MM-dd HH:mm:ss";
  
  private int findVariable(String paramString)
  {
    if (paramString == null) {
      return -1;
    }
    if (this.var_index.containsKey(paramString.toUpperCase()))
    {
      Integer localInteger = (Integer)this.var_index.get(paramString.toUpperCase());
      return localInteger.intValue();
    }
    for (int i = 0; (i < this.var_count) && ((this.var_name[i] == null) || (!this.var_name[i].equalsIgnoreCase(paramString))); i++) {}
    return i == this.var_count ? -1 : i;
  }
  
  public final int find(String paramString)
  {
    return findVariable(paramString);
  }
  
  public final int size()
  {
    return this.var_count;
  }
  
  public final String[] getNames()
  {
    String[] arrayOfString = new String[0];
    if (this.var_count == 0) {
      return arrayOfString;
    }
    arrayOfString = new String[this.var_count];
    System.arraycopy(this.var_name, 0, arrayOfString, 0, this.var_count);
    return arrayOfString;
  }
  
  public final String getName(int paramInt)
  {
    if ((paramInt > 0) && (paramInt <= this.var_count)) {
      return this.var_name[(paramInt - 1)];
    }
    return null;
  }
  
  public final boolean exists(String paramString)
  {
    if (paramString != null)
    {
      if (paramString.equalsIgnoreCase("SYS_DATE")) {
        return true;
      }
      if (paramString.equalsIgnoreCase("JAVA_VERSION")) {
        return true;
      }
      if (paramString.equalsIgnoreCase("FILE_ENCODING")) {
        return true;
      }
      if (paramString.equalsIgnoreCase("SYS_TIME")) {
        return true;
      }
      if (paramString.equalsIgnoreCase("SYS_DATETIME")) {
        return true;
      }
      if (paramString.equalsIgnoreCase("NLS_DATE_FORMAT")) {
        return true;
      }
      if (paramString.equalsIgnoreCase("CURRENT_DATE")) {
        return true;
      }
    }
    return findVariable(paramString) != -1;
  }
  
  public final Object getValue(String paramString)
  {
    if (paramString != null)
    {
      if (paramString.equalsIgnoreCase("SYS_DATE")) {
        return new Date(System.currentTimeMillis());
      }
      if (paramString.equalsIgnoreCase("SYS_TIME")) {
        return new Time(System.currentTimeMillis());
      }
      if (paramString.equalsIgnoreCase("JAVA_VERSION")) {
        return JavaVM.VERSION;
      }
      if (paramString.equalsIgnoreCase("FILE_ENCODING")) {
        return JavaVM.ENCODING;
      }
      if (paramString.equalsIgnoreCase("SYS_DATETIME")) {
        return new Timestamp(System.currentTimeMillis());
      }
      if (paramString.equalsIgnoreCase("NLS_DATE_FORMAT")) {
        return this.date_format;
      }
      if (paramString.equalsIgnoreCase("CURRENT_DATE")) {
        return DateOperator.getDay(this.date_format);
      }
    }
    int i = findVariable(paramString);
    if (i == -1) {
      return null;
    }
    Object localObject = this.var_value[i];
    return localObject;
  }
  
  public final String getString(String paramString)
  {
    Object localObject = getValue(paramString);
    if (localObject != null) {
      return localObject.toString();
    }
    return null;
  }
  
  public final String getString(String paramString1, String paramString2)
  {
    Object localObject = getValue(paramString1);
    if (localObject != null) {
      return localObject.toString();
    }
    return paramString2;
  }
  
  public final int getInt(String paramString, int paramInt)
  {
    String str = getString(paramString);
    if (str == null) {
      return paramInt;
    }
    try
    {
      return Integer.valueOf(str).intValue();
    }
    catch (NumberFormatException localNumberFormatException) {}
    return paramInt;
  }
  
  public final long getLong(String paramString, long paramLong)
  {
    String str = getString(paramString);
    if (str == null) {
      return paramLong;
    }
    try
    {
      return Long.valueOf(str).longValue();
    }
    catch (NumberFormatException localNumberFormatException) {}
    return paramLong;
  }
  
  public final float getFloat(String paramString, float paramFloat)
  {
    String str = getString(paramString);
    if (str == null) {
      return paramFloat;
    }
    try
    {
      return Float.valueOf(str).floatValue();
    }
    catch (NumberFormatException localNumberFormatException) {}
    return paramFloat;
  }
  
  public final double getDouble(String paramString, double paramDouble)
  {
    String str = getString(paramString);
    if (str == null) {
      return paramDouble;
    }
    try
    {
      return Double.valueOf(str).doubleValue();
    }
    catch (NumberFormatException localNumberFormatException) {}
    return paramDouble;
  }
  
  public final boolean getBoolean(String paramString, boolean paramBoolean)
  {
    String str = getString(paramString);
    if (str == null) {
      return paramBoolean;
    }
    return Boolean.valueOf(str).booleanValue();
  }
  
  public final void setType(String paramString, int paramInt)
  {
    if (paramString != null)
    {
      if (paramString.equalsIgnoreCase("SYS_DATE")) {
        return;
      }
      if (paramString.equalsIgnoreCase("SYS_TIME")) {
        return;
      }
      if (paramString.equalsIgnoreCase("JAVA_VERSION")) {
        return;
      }
      if (paramString.equalsIgnoreCase("FILE_ENCODING")) {
        return;
      }
      if (paramString.equalsIgnoreCase("SYS_DATETIME")) {
        return;
      }
      if (paramString.equalsIgnoreCase("NLS_DATE_FORMAT")) {
        return;
      }
      if (paramString.equalsIgnoreCase("CURRENT_DATE")) {
        return;
      }
    }
    int i = findVariable(paramString);
    if (i == -1) {
      return;
    }
    this.var_type[i] = paramInt;
  }
  
  public final int getType(String paramString)
  {
    if (paramString != null)
    {
      if (paramString.equalsIgnoreCase("SYS_DATE")) {
        return 91;
      }
      if (paramString.equalsIgnoreCase("SYS_TIME")) {
        return 92;
      }
      if (paramString.equalsIgnoreCase("JAVA_VERSION")) {
        return 12;
      }
      if (paramString.equalsIgnoreCase("FILE_ENCODING")) {
        return 12;
      }
      if (paramString.equalsIgnoreCase("SYS_DATETIME")) {
        return 93;
      }
      if (paramString.equalsIgnoreCase("NLS_DATE_FORMAT")) {
        return 12;
      }
      if (paramString.equalsIgnoreCase("CURRENT_DATE")) {
        return 12;
      }
    }
    int i = findVariable(paramString);
    if (i == -1) {
      return 12;
    }
    return this.var_type[i];
  }
  
  public final void setValue(String paramString, Object paramObject)
    throws NumberFormatException
  {
    if (paramString != null)
    {
      if (paramString.equalsIgnoreCase("SYS_DATE")) {
        return;
      }
      if (paramString.equalsIgnoreCase("SYS_TIME")) {
        return;
      }
      if (paramString.equalsIgnoreCase("JAVA_VERSION")) {
        return;
      }
      if (paramString.equalsIgnoreCase("FILE_ENCODING")) {
        return;
      }
      if (paramString.equalsIgnoreCase("SYS_DATETIME")) {
        return;
      }
      if (paramString.equalsIgnoreCase("CURRENT_DATE")) {
        return;
      }
      if (paramString.equalsIgnoreCase("NLS_DATE_FORMAT"))
      {
        if (paramObject != null) {
          this.date_format = paramObject.toString();
        } else {
          this.date_format = "yyyy-MM-dd HH:mm:ss";
        }
        return;
      }
    }
    int i = findVariable(paramString);
    if (i == -1) {
      return;
    }
    if (paramObject == null)
    {
      this.var_value[i] = null;
    }
    else
    {
      Object localObject = paramObject;
      if ((paramObject instanceof String)) {
        if (paramObject.toString().equals("${today}")) {
          localObject = DateOperator.getDay("yyyyMMdd");
        } else if (paramObject.toString().startsWith("${today}+")) {
          localObject = DateOperator.addDays(DateOperator.getDay("yyyyMMdd"), Integer.valueOf(paramObject.toString().substring(9)).intValue());
        } else if (paramObject.toString().startsWith("${today}-")) {
          localObject = DateOperator.addDays(DateOperator.getDay("yyyyMMdd"), Integer.valueOf(paramObject.toString().substring(8)).intValue());
        } else if (paramObject.toString().equals("${month}")) {
          localObject = DateOperator.getDay("yyyyMM");
        } else if (paramObject.toString().startsWith("${month}+")) {
          localObject = DateOperator.addMonths(DateOperator.getDay("yyyyMMdd"), Integer.valueOf(paramObject.toString().substring(9)).intValue()).substring(0, 6);
        } else if (paramObject.toString().startsWith("${month}-")) {
          localObject = DateOperator.addMonths(DateOperator.getDay("yyyyMMdd"), Integer.valueOf(paramObject.toString().substring(8)).intValue()).substring(0, 6);
        } else if (paramObject.toString().equals("${year}")) {
          localObject = DateOperator.getDay("yyyy");
        } else if (paramObject.toString().startsWith("${year}+")) {
          localObject = DateOperator.addMonths(DateOperator.getDay("yyyyMMdd"), Integer.valueOf(paramObject.toString().substring(8)).intValue() * 12).substring(0, 4);
        } else if (paramObject.toString().startsWith("${year}-")) {
          localObject = DateOperator.addMonths(DateOperator.getDay("yyyyMMdd"), Integer.valueOf(paramObject.toString().substring(7)).intValue() * 12).substring(0, 4);
        } else {
          localObject = (String)paramObject;
        }
      }
      if (this.var_type[i] != -999999) {
        this.var_value[i] = SQLTypes.getValue(this.var_type[i], localObject);
      } else {
        this.var_value[i] = localObject;
      }
    }
  }
  
  public final synchronized void add(String paramString, int paramInt)
  {
    if (paramString == null) {
      return;
    }
    if (paramString != null)
    {
      if (paramString.equalsIgnoreCase("SYS_DATE")) {
        return;
      }
      if (paramString.equalsIgnoreCase("SYS_TIME")) {
        return;
      }
      if (paramString.equalsIgnoreCase("JAVA_VERSION")) {
        return;
      }
      if (paramString.equalsIgnoreCase("FILE_ENCODING")) {
        return;
      }
      if (paramString.equalsIgnoreCase("SYS_DATETIME")) {
        return;
      }
      if (paramString.equalsIgnoreCase("NLS_DATE_FORMAT")) {
        return;
      }
      if (paramString.equalsIgnoreCase("CURRENT_DATE")) {
        return;
      }
    }
    int i = findVariable(paramString);
    if (i >= 0) {
      return;
    }
    if (this.var_count == this.var_name.length)
    {
      String[] arrayOfString = this.var_name;
      int[] arrayOfInt = this.var_type;
      Object[] arrayOfObject = this.var_value;
      this.var_name = new String[this.var_count + 50];
      this.var_type = new int[this.var_count + 50];
      this.var_value = new Object[this.var_count + 50];
      System.arraycopy(arrayOfString, 0, this.var_name, 0, this.var_count);
      System.arraycopy(arrayOfInt, 0, this.var_type, 0, this.var_count);
      System.arraycopy(arrayOfObject, 0, this.var_value, 0, this.var_count);
    }
    this.var_name[this.var_count] = paramString.toUpperCase();
    this.var_type[this.var_count] = paramInt;
    this.var_index.put(this.var_name[this.var_count], new Integer(this.var_count));
    this.var_count += 1;
  }
  
  public final synchronized void remove(String paramString)
  {
    int i = findVariable(paramString);
    if (i == -1) {
      return;
    }
    this.var_index.remove(this.var_name[i]);
    if (this.var_count - i - 1 > 0)
    {
      System.arraycopy(this.var_name, i + 1, this.var_name, i, this.var_count - i - 1);
      System.arraycopy(this.var_type, i + 1, this.var_type, i, this.var_count - i - 1);
      System.arraycopy(this.var_value, i + 1, this.var_value, i, this.var_count - i - 1);
    }
    this.var_count -= 1;
    for (int j = i; i < this.var_count; j++)
    {
      this.var_index.remove(this.var_name[i]);
      this.var_index.put(this.var_name[i], new Integer(j));
    }
    this.var_name[this.var_count] = null;
    this.var_value[this.var_count] = null;
  }
  
  public final synchronized void removeAll()
  {
    this.var_index.clear();
    this.var_name = new String[50];
    this.var_type = new int[50];
    this.var_value = new Object[50];
    this.var_count = 0;
  }
  
  public final void loadURL(String paramString)
  {
    try
    {
      URL localURL = getClass().getResource(paramString);
      if (localURL == null) {
        return;
      }
      load(new BufferedReader(new InputStreamReader(localURL.openStream())));
    }
    catch (IOException localIOException) {}
  }
  
  public final void loadFile(String paramString)
  {
    try
    {
      BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(paramString)));
      load(localBufferedReader);
    }
    catch (IOException localIOException) {}
  }
  
  public final void loadInputStream(InputStream paramInputStream)
  {
    BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(paramInputStream));
    load(localBufferedReader);
  }
  
  private final void load(BufferedReader paramBufferedReader)
  {
    int i = 0;
    int j = 0;
    String str1 = "";
    String str2 = "";
    try
    {
      if (paramBufferedReader == null) {
        return;
      }
      while ((str1 = paramBufferedReader.readLine()) != null) {
        if ((str1.trim().length() != 0) && (!str1.trim().substring(0, 1).equals("#")))
        {
          char[] arrayOfChar = str1.toCharArray();
          for (j = arrayOfChar.length; (j > 0) && ((arrayOfChar[(j - 1)] == ' ') || (arrayOfChar[(j - 1)] == '\t')); j--) {}
          str1 = String.valueOf(arrayOfChar, 0, j);
          j = 0;
          if (str1.endsWith("\\"))
          {
            str2 = str2 + str1.substring(0, str1.length() - 1) + "\n";
          }
          else
          {
            str2 = str2 + str1;
            j = str2.indexOf("=");
            if (j > 0)
            {
              add(str2.substring(0, j).trim().toUpperCase(), 12);
              if (j == str2.length() - 1) {
                setValue(str2.substring(0, j).trim().toUpperCase(), "");
              } else {
                setValue(str2.substring(0, j).trim().toUpperCase(), str2.substring(j + 1));
              }
            }
            str2 = "";
          }
        }
      }
      if (str2.length() > 0)
      {
        j = str2.indexOf("=");
        if (j > 0)
        {
          add(str2.substring(0, j).trim().toUpperCase(), 12);
          if (j == str2.length() - 1) {
            setValue(str2.substring(0, j).trim().toUpperCase(), "");
          } else {
            setValue(str2.substring(0, j).trim().toUpperCase(), str2.substring(j + 1));
          }
        }
      }
    }
    catch (IOException localIOException1) {}
    try
    {
      if (paramBufferedReader != null) {
        paramBufferedReader.close();
      }
    }
    catch (IOException localIOException2) {}
  }
  
  private final boolean isVariableFirst(char paramChar)
  {
    if (paramChar == '_') {
      return true;
    }
    if ((paramChar >= 'a') && (paramChar <= 'z')) {
      return true;
    }
    return (paramChar >= 'A') && (paramChar <= 'Z');
  }
  
  private final boolean isVariableChar(char paramChar)
  {
    if (paramChar == '_') {
      return true;
    }
    if ((paramChar >= '0') && (paramChar <= '9')) {
      return true;
    }
    if ((paramChar >= 'a') && (paramChar <= 'z')) {
      return true;
    }
    return (paramChar >= 'A') && (paramChar <= 'Z');
  }
  
  public final String parseString(String paramString, char paramChar1, char paramChar2)
  {
    if (paramString == null) {
      return null;
    }
    String str = "";
    StringBuffer localStringBuffer = new StringBuffer();
    char[] arrayOfChar = paramString.toCharArray();
    int i = 0;
    while (i < arrayOfChar.length) {
      if ((arrayOfChar[i] != paramChar1) && (arrayOfChar[i] != paramChar2))
      {
        localStringBuffer.append(arrayOfChar[i]);
        i++;
      }
      else if (arrayOfChar[i] == paramChar2)
      {
        if (i + 1 < arrayOfChar.length)
        {
          if (arrayOfChar[(i + 1)] == paramChar1)
          {
            localStringBuffer.append(arrayOfChar[(i + 1)]);
            i += 2;
          }
          else
          {
            localStringBuffer.append(arrayOfChar[i]);
            i++;
          }
        }
        else
        {
          localStringBuffer.append(arrayOfChar[i]);
          i++;
        }
      }
      else if (i + 1 < arrayOfChar.length)
      {
        int j;
        int k;
        if (arrayOfChar[(i + 1)] == '{')
        {
          j = i + 2;
          for (k = i + 2; (k < arrayOfChar.length) && (arrayOfChar[k] != '}'); k++) {}
          if (j < arrayOfChar.length) {
            if (k < arrayOfChar.length)
            {
              str = String.valueOf(arrayOfChar, j, k - j);
              if (exists(str))
              {
                localStringBuffer.append(getString(str, ""));
              }
              else
              {
                localStringBuffer.append("&{");
                localStringBuffer.append(str);
                localStringBuffer.append("}");
              }
            }
            else
            {
              str = String.valueOf(arrayOfChar, j, arrayOfChar.length - j);
              if (exists(str))
              {
                localStringBuffer.append(getString(str, ""));
              }
              else
              {
                localStringBuffer.append("&{");
                localStringBuffer.append(str);
                localStringBuffer.append("}");
              }
            }
          }
          i = k + 1;
        }
        else if (isVariableFirst(arrayOfChar[(i + 1)]))
        {
          j = i + 1;
          for (k = i + 1; (k < arrayOfChar.length) && (isVariableChar(arrayOfChar[k])); k++) {}
          if (j < arrayOfChar.length) {
            if (k < arrayOfChar.length)
            {
              str = String.valueOf(arrayOfChar, j, k - j);
              if (exists(str))
              {
                localStringBuffer.append(getString(str, ""));
              }
              else
              {
                localStringBuffer.append("&");
                localStringBuffer.append(str);
              }
            }
            else
            {
              str = String.valueOf(arrayOfChar, j, arrayOfChar.length - j);
              if (exists(str))
              {
                localStringBuffer.append(getString(str, ""));
              }
              else
              {
                localStringBuffer.append("&");
                localStringBuffer.append(str);
              }
            }
          }
          if ((k < arrayOfChar.length) && (arrayOfChar[k] == '.')) {
            i = k + 1;
          } else {
            i = k;
          }
        }
        else
        {
          localStringBuffer.append(arrayOfChar[i]);
          i++;
        }
      }
      else
      {
        i++;
      }
    }
    return localStringBuffer.toString();
  }
  
  public final String parseString(String paramString, char paramChar)
  {
    return parseString(paramString, paramChar, '\\');
  }
  
  public final String parseString(String paramString)
  {
    return parseString(paramString, '$', '\\');
  }
}


/* Location:           D:\tmp\oasql.jar
 * Qualified Name:     com.asql.core.VariableTable
 * JD-Core Version:    0.7.0.1
 */