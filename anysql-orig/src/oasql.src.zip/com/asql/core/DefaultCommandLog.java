package com.asql.core;

public class DefaultCommandLog
  extends OutputCommandLog
{
  public DefaultCommandLog(CommandExecutor paramCommandExecutor)
  {
    super(paramCommandExecutor, System.out);
  }
  
  public void close() {}
}


/* Location:           D:\tmp\oasql.jar
 * Qualified Name:     com.asql.core.DefaultCommandLog
 * JD-Core Version:    0.7.0.1
 */