package com.asql.core;

public class DefaultCommandReader
  extends InputCommandReader
{
  public DefaultCommandReader()
  {
    super(System.in);
  }
  
  public void close() {}
  
  public String readPassword()
    throws Exception
  {
    return PasswordReader.readPassword("Password: ");
  }
  
  public void setWorkingDir(String paramString) {}
}


/* Location:           D:\tmp\oasql.jar
 * Qualified Name:     com.asql.core.DefaultCommandReader
 * JD-Core Version:    0.7.0.1
 */