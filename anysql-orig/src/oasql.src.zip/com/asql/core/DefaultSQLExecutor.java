package com.asql.core;

import java.sql.Connection;
import java.sql.SQLException;

public class DefaultSQLExecutor
  extends CommandExecutor
{
  private CMDType _cmdtype = null;
  private CommandLog _stdout = null;
  private CommandReader _stdin = null;
  protected VariableTable sysvariable = new VariableTable();
  protected Connection database = null;
  protected boolean timing = false;
  protected boolean autocommit = false;
  
  public DefaultSQLExecutor(CMDType paramCMDType)
  {
    this._stdout = new DefaultCommandLog(this);
    this._stdin = new DefaultCommandReader();
    this._cmdtype = paramCMDType;
  }
  
  public DefaultSQLExecutor(CMDType paramCMDType, CommandReader paramCommandReader, CommandLog paramCommandLog)
  {
    this._cmdtype = paramCMDType;
    this._stdin = paramCommandReader;
    this._stdout = paramCommandLog;
  }
  
  public final DBRowCache executeQuery(String paramString, VariableTable paramVariableTable)
    throws SQLException
  {
    if (!isConnected()) {
      return null;
    }
    return executeQuery(this.database, paramString, paramVariableTable);
  }
  
  public final DBRowCache executeQuery(String paramString, VariableTable paramVariableTable, int paramInt)
    throws SQLException
  {
    if (!isConnected()) {
      return null;
    }
    return executeQuery(this.database, paramString, paramVariableTable, paramInt);
  }
  
  public final boolean isConnected()
  {
    if (this.database == null) {
      return false;
    }
    try
    {
      return !this.database.isClosed();
    }
    catch (SQLException localSQLException) {}
    return false;
  }
  
  protected final void procDisconnect(String paramString)
  {
    if (!isConnected())
    {
      this._stdout.println("Database not connected.");
      return;
    }
    try
    {
      this.database.rollback();
    }
    catch (SQLException localSQLException1)
    {
      this._stdout.print(localSQLException1);
    }
    try
    {
      this.database.close();
      this.database = null;
      this._stdout.println("Disconnect from database!");
    }
    catch (SQLException localSQLException2)
    {
      this._stdout.print(localSQLException2);
    }
  }
  
  public final void disconnect()
  {
    if (!isConnected())
    {
      this._stdout.println();
      this._stdout.println("Database not connected.");
      this._stdout.println();
      return;
    }
    try
    {
      this.database.rollback();
    }
    catch (SQLException localSQLException1)
    {
      this._stdout.print(localSQLException1);
    }
    try
    {
      this.database.close();
      this.database = null;
      this._stdout.println();
      this._stdout.println("Disconnect from database!");
      this._stdout.println();
    }
    catch (SQLException localSQLException2)
    {
      this._stdout.println();
      this._stdout.print(localSQLException2);
      this._stdout.println();
    }
  }
  
  protected final int getSingleID(String paramString)
  {
    String[] arrayOfString = TextUtils.toStringArray(TextUtils.getWords(paramString));
    return commandAt(this._cmdtype.getASQLSingle(), arrayOfString);
  }
  
  protected final int getDBCommandID(String paramString)
  {
    String[] arrayOfString = TextUtils.toStringArray(TextUtils.getWords(paramString));
    return commandAt(this._cmdtype.getDBCommand(), arrayOfString);
  }
  
  protected final int getMultipleID(String paramString)
  {
    String[] arrayOfString = TextUtils.toStringArray(TextUtils.getWords(paramString));
    return commandAt(this._cmdtype.getASQLMultiple(), arrayOfString);
  }
  
  protected final String skipWord(String paramString, int paramInt)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = 0;
    int j = 0;
    int k = 0;
    while ((j < paramInt) && (i < arrayOfChar.length))
    {
      while ((i < arrayOfChar.length) && ((arrayOfChar[i] == ' ') || (arrayOfChar[i] == '\t') || (arrayOfChar[i] == '\r') || (arrayOfChar[i] == '\n'))) {
        i++;
      }
      while ((i < arrayOfChar.length) && (arrayOfChar[i] != ' ') && (arrayOfChar[i] != '\t') && (arrayOfChar[i] != '\r') && (arrayOfChar[i] != '\n')) {
        i++;
      }
      j++;
    }
    i++;
    if (i < arrayOfChar.length) {
      return String.valueOf(arrayOfChar, i, arrayOfChar.length - i);
    }
    return "";
  }
  
  public boolean execute(Command paramCommand)
  {
    this._stdout.println();
    this._stdout.println("Command executed!");
    this._stdout.println();
    return true;
  }
  
  public void showVersion()
  {
    this._stdout.println();
    this._stdout.println(" Default Command Executor, version 1.0 -- " + DateOperator.getDay("yyyy-MM-dd HH:mm:ss"));
    this._stdout.println();
    this._stdout.println(" (@) Copyright Lou Fangxin, all rights reserved.");
    this._stdout.println();
  }
  
  public final CommandLog getCommandLog()
  {
    return this._stdout;
  }
  
  public final void setCommandLog(CommandLog paramCommandLog)
  {
    this._stdout = paramCommandLog;
  }
  
  public final CommandReader getCommandReader()
  {
    return this._stdin;
  }
  
  public final void setCommandReader(CommandReader paramCommandReader)
  {
    this._stdin = paramCommandReader;
  }
  
  public final CMDType getCommandType()
  {
    return this._cmdtype;
  }
  
  protected void doServerMessage()
    throws SQLException
  {}
  
  public String getLastCommand()
  {
    return null;
  }
}


/* Location:           D:\tmp\oasql.jar
 * Qualified Name:     com.asql.core.DefaultSQLExecutor
 * JD-Core Version:    0.7.0.1
 */