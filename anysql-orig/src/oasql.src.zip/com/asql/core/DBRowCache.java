package com.asql.core;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintStream;
import java.io.Writer;

public abstract interface DBRowCache
{
  public abstract int getColumnCount();
  
  public abstract int getRowCount();
  
  public abstract void addColumn(String paramString, int paramInt);
  
  public abstract void removeAllColumn();
  
  public abstract int findColumn(String paramString);
  
  public abstract String getColumnName(int paramInt);
  
  public abstract String getColumnLabel(int paramInt);
  
  public abstract String getColumnLabel(String paramString);
  
  public abstract void setColumnLabel(int paramInt, String paramString);
  
  public abstract void setColumnLabel(String paramString1, String paramString2);
  
  public abstract void setColumnType(int paramInt1, int paramInt2);
  
  public abstract void setColumnType(String paramString, int paramInt);
  
  public abstract void setColumnSize(int paramInt1, int paramInt2);
  
  public abstract void setColumnSize(String paramString, int paramInt);
  
  public abstract int getColumnType(int paramInt);
  
  public abstract int getColumnType(String paramString);
  
  public abstract int getColumnSize(int paramInt);
  
  public abstract int getColumnSize(String paramString);
  
  public abstract void setItem(int paramInt1, int paramInt2, Object paramObject);
  
  public abstract void setItem(int paramInt, String paramString, Object paramObject);
  
  public abstract Object getItem(int paramInt1, int paramInt2);
  
  public abstract Object getItem(int paramInt, String paramString);
  
  public abstract String getString(int paramInt1, int paramInt2);
  
  public abstract String getString(int paramInt, String paramString);
  
  public abstract int getWidth(boolean paramBoolean);
  
  public abstract Object[] getRow(int paramInt);
  
  public abstract void setRow(int paramInt, Object[] paramArrayOfObject);
  
  public abstract int insertRow(int paramInt);
  
  public abstract int insertRow(int paramInt, Object[] paramArrayOfObject);
  
  public abstract int appendRow();
  
  public abstract int appendRow(Object[] paramArrayOfObject);
  
  public abstract void deleteRow(int paramInt);
  
  public abstract void deleteRow(int paramInt1, int paramInt2);
  
  public abstract void deleteAllRow();
  
  public abstract double min(String paramString, double paramDouble);
  
  public abstract double min(String[] paramArrayOfString, double paramDouble);
  
  public abstract double max(String paramString, double paramDouble);
  
  public abstract double max(String[] paramArrayOfString, double paramDouble);
  
  public abstract double avg(String paramString);
  
  public abstract double sum(String paramString);
  
  public abstract int count(String paramString);
  
  public abstract int count();
  
  public abstract int read(BufferedReader paramBufferedReader, int paramInt)
    throws IOException;
  
  public abstract int read(BufferedReader paramBufferedReader, String paramString, int paramInt)
    throws IOException;
  
  public abstract int read(BufferedReader paramBufferedReader, String paramString1, String paramString2, int paramInt)
    throws IOException;
  
  public abstract void write(PrintStream paramPrintStream);
  
  public abstract void write(PrintStream paramPrintStream, int paramInt);
  
  public abstract void write(PrintStream paramPrintStream, String paramString);
  
  public abstract void write(PrintStream paramPrintStream, String paramString1, String paramString2);
  
  public abstract void write(PrintStream paramPrintStream, String paramString, int paramInt);
  
  public abstract void write(PrintStream paramPrintStream, String paramString1, String paramString2, int paramInt);
  
  public abstract void write(Writer paramWriter)
    throws IOException;
  
  public abstract void write(Writer paramWriter, int paramInt)
    throws IOException;
  
  public abstract void write(Writer paramWriter, String paramString)
    throws IOException;
  
  public abstract void write(Writer paramWriter, String paramString1, String paramString2)
    throws IOException;
  
  public abstract void write(Writer paramWriter, String paramString, int paramInt)
    throws IOException;
  
  public abstract void write(Writer paramWriter, String paramString1, String paramString2, int paramInt)
    throws IOException;
  
  public abstract String getFixedHeader();
  
  public abstract String getFixedRow(int paramInt);
  
  public abstract String getSeperator();
  
  public abstract String getSepHeader(String paramString);
  
  public abstract String getSepRow(String paramString, int paramInt);
  
  public abstract void shiftRow(int paramInt1, int paramInt2);
  
  public abstract void copyStruct(DBRowCache paramDBRowCache);
  
  public abstract void quicksort(int paramInt, boolean paramBoolean);
  
  public abstract void quicksort(String paramString, boolean paramBoolean);
  
  public abstract void quicksort(int paramInt);
  
  public abstract void quicksort(String paramString);
  
  public abstract String getString(int paramInt);
  
  public abstract String getString(String paramString, int paramInt);
  
  public abstract int find(int paramInt, Object paramObject);
  
  public abstract int find(int paramInt1, Object paramObject, int paramInt2);
  
  public abstract int find(int[] paramArrayOfInt, Object[] paramArrayOfObject);
  
  public abstract int find(int[] paramArrayOfInt, Object[] paramArrayOfObject, int paramInt);
  
  public abstract int count(int paramInt, Object paramObject);
  
  public abstract int[] filter(int paramInt, Object paramObject);
  
  public abstract Object[] distinct(int paramInt);
  
  public abstract Object[] distinct(String paramString);
  
  public abstract void addCrosstab(DBRowCache paramDBRowCache, int paramInt1, int paramInt2, int paramInt3);
  
  public abstract void addCrosstab(DBRowCache paramDBRowCache, String paramString1, String paramString2, String paramString3);
  
  public abstract void addCrosstab(DBRowCache paramDBRowCache, int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public abstract void addCrosstab(DBRowCache paramDBRowCache, String paramString, String[] paramArrayOfString1, String[] paramArrayOfString2);
  
  public abstract void addCrosstab(DBRowCache paramDBRowCache, int[] paramArrayOfInt, int paramInt1, int paramInt2);
  
  public abstract void addCrosstab(DBRowCache paramDBRowCache, String[] paramArrayOfString, String paramString1, String paramString2);
  
  public abstract void addCrosstab(DBRowCache paramDBRowCache, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3);
  
  public abstract void addCrosstab(DBRowCache paramDBRowCache, String[] paramArrayOfString1, String[] paramArrayOfString2, String[] paramArrayOfString3);
  
  public abstract DBRowCache getCrosstab(int paramInt1, int paramInt2, int paramInt3);
  
  public abstract DBRowCache getCrosstab(String paramString1, String paramString2, String paramString3);
  
  public abstract DBRowCache getCrosstab(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public abstract DBRowCache getCrosstab(String paramString, String[] paramArrayOfString1, String[] paramArrayOfString2);
  
  public abstract void writeXMLBody(Writer paramWriter)
    throws IOException;
  
  public abstract void writeXMLBody(Writer paramWriter, int paramInt)
    throws IOException;
  
  public abstract void writeXMLBody(Writer paramWriter, String paramString, int paramInt)
    throws IOException;
  
  public abstract void writeXMLBody(Writer paramWriter, String paramString1, String paramString2, int paramInt)
    throws IOException;
}


/* Location:           D:\tmp\oasql.jar
 * Qualified Name:     com.asql.core.DBRowCache
 * JD-Core Version:    0.7.0.1
 */