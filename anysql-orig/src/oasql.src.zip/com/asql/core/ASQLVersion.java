package com.asql.core;

public class ASQLVersion
{
  public static final String BUILD_DATE = "20060816-1013";
}


/* Location:           D:\tmp\oasql.jar
 * Qualified Name:     com.asql.core.ASQLVersion
 * JD-Core Version:    0.7.0.1
 */