package com.asql.core;

public class Command
{
  public int TYPE1 = -1;
  public int TYPE2 = -1;
  public String COMMAND = null;
  public String WORKINGDIR = null;
  
  public Command(int paramInt1, int paramInt2, String paramString)
  {
    this.TYPE1 = paramInt1;
    this.TYPE2 = paramInt2;
    this.COMMAND = paramString;
    this.WORKINGDIR = JavaVM.USER_DIRECTORY;
  }
  
  public Command(int paramInt1, int paramInt2, String paramString1, String paramString2)
  {
    this.TYPE1 = paramInt1;
    this.TYPE2 = paramInt2;
    this.COMMAND = paramString1;
    this.WORKINGDIR = paramString2;
  }
}


/* Location:           D:\tmp\oasql.jar
 * Qualified Name:     com.asql.core.Command
 * JD-Core Version:    0.7.0.1
 */