package com.asql.core;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.ResultSet;
import java.sql.SQLException;

public final class SQLCallable
{
  private String SourceSQL = null;
  private String DestSQL = null;
  public CallableStatement stmt = null;
  private String[] paramNames = new String[0];
  private String[] paramTypes = new String[0];
  
  public SQLCallable(CallableStatement paramCallableStatement, SQLQuery paramSQLQuery)
  {
    this.stmt = paramCallableStatement;
    this.SourceSQL = paramSQLQuery.getSourceSQL();
    this.DestSQL = paramSQLQuery.getDestSQL();
    this.paramNames = paramSQLQuery.getParamNames();
    this.paramTypes = paramSQLQuery.getParamTypes();
  }
  
  public final String getSourceSQL()
  {
    return this.SourceSQL;
  }
  
  public final String getDestSQL()
  {
    return this.DestSQL;
  }
  
  public final String[] getParamNames()
  {
    return this.paramNames;
  }
  
  public final String[] getParamTypes()
  {
    return this.paramTypes;
  }
  
  public boolean getMoreResults()
    throws SQLException
  {
    return this.stmt.getMoreResults();
  }
  
  public ResultSet getResultSet()
    throws SQLException
  {
    return this.stmt.getResultSet();
  }
  
  public int getUpdateCount()
    throws SQLException
  {
    return this.stmt.getUpdateCount();
  }
  
  public boolean execute(VariableTable paramVariableTable)
    throws SQLException
  {
    boolean bool = false;
    bind(paramVariableTable);
    bool = this.stmt.execute();
    fetch(paramVariableTable);
    return bool;
  }
  
  public void close()
    throws SQLException
  {
    if (this.stmt != null)
    {
      this.stmt.close();
      this.stmt = null;
    }
  }
  
  public void bind(VariableTable paramVariableTable)
    throws SQLException
  {
    try
    {
      this.stmt.clearParameters();
    }
    catch (SQLException localSQLException) {}
    if (this.paramNames.length > 0) {
      for (int i = 0; i < this.paramNames.length; i++)
      {
        int j = paramVariableTable.getType(this.paramNames[i]);
        Object localObject1 = paramVariableTable.getValue(this.paramNames[i]);
        if ((this.paramTypes[i].equals("IN")) || (this.paramTypes[i].equals("INOUT")))
        {
          if (localObject1 == null)
          {
            this.stmt.setNull(i + 1, 1);
          }
          else
          {
            Object localObject2;
            switch (j)
            {
            case -3: 
            case -2: 
            case 1: 
            case 12: 
              this.stmt.setString(i + 1, localObject1.toString());
              break;
            case -1: 
            case 2005: 
              if (j == 2005)
              {
                localObject2 = new File(localObject1.toString());
                if ((((File)localObject2).exists()) && (((File)localObject2).isFile()) && (((File)localObject2).canRead())) {
                  try
                  {
                    BufferedReader localBufferedReader = new BufferedReader(new FileReader((File)localObject2));
                    this.stmt.setCharacterStream(i + 1, localBufferedReader, (int)((File)localObject2).length());
                  }
                  catch (IOException localIOException1) {}
                } else {
                  this.stmt.setNull(i + 1, 1);
                }
              }
              else
              {
                localObject2 = new StringReader(localObject1.toString());
                this.stmt.setCharacterStream(i + 1, (Reader)localObject2, 65536);
              }
              break;
            case -4: 
            case 2004: 
              localObject2 = new File(localObject1.toString());
              if ((((File)localObject2).exists()) && (((File)localObject2).isFile()) && (((File)localObject2).canRead())) {
                try
                {
                  FileInputStream localFileInputStream = new FileInputStream((File)localObject2);
                  this.stmt.setBinaryStream(i + 1, localFileInputStream, (int)((File)localObject2).length());
                }
                catch (IOException localIOException2) {}
              } else {
                this.stmt.setNull(i + 1, 1);
              }
              break;
            case -14: 
            case -13: 
            case -10: 
            case 0: 
            case 70: 
            case 1111: 
            case 2000: 
            case 2001: 
            case 2002: 
            case 2003: 
            case 2006: 
              this.stmt.setNull(i + 1, 1);
              break;
            default: 
              this.stmt.setObject(i + 1, localObject1);
            }
          }
          if (this.paramTypes[i].equals("INOUT")) {
            this.stmt.registerOutParameter(i + 1, paramVariableTable.getType(this.paramNames[i]));
          }
        }
        else if (this.paramTypes[i].equals("OUT"))
        {
          this.stmt.registerOutParameter(i + 1, paramVariableTable.getType(this.paramNames[i]));
        }
      }
    }
  }
  
  public final void bind(VariableTable paramVariableTable, DBRowCache paramDBRowCache, int paramInt)
    throws SQLException
  {
    int[] arrayOfInt1 = new int[0];
    int[] arrayOfInt2 = new int[0];
    int i = 0;
    int j = 1;
    Object localObject1 = null;
    if (this.paramNames.length > 0)
    {
      arrayOfInt1 = new int[this.paramNames.length];
      arrayOfInt2 = new int[this.paramNames.length];
      for (i = 0; i < this.paramNames.length; i++)
      {
        arrayOfInt1[i] = paramDBRowCache.findColumn(this.paramNames[i]);
        if (arrayOfInt1[i] > 0) {
          arrayOfInt2[i] = paramDBRowCache.getColumnType(arrayOfInt1[i]);
        } else {
          arrayOfInt2[i] = paramVariableTable.getType(this.paramNames[i]);
        }
      }
    }
    if (this.paramNames.length > 0)
    {
      Object[] arrayOfObject = paramDBRowCache.getRow(j);
      for (i = 0; i < this.paramNames.length; i++)
      {
        if (arrayOfInt1[i] > 0) {
          localObject1 = arrayOfObject[(arrayOfInt1[i] - 1)];
        } else {
          localObject1 = paramVariableTable.getValue(this.paramNames[i]);
        }
        if ((this.paramTypes[i].equals("IN")) || (this.paramTypes[i].equals("INOUT")))
        {
          if (localObject1 == null)
          {
            this.stmt.setNull(i + 1, 1);
          }
          else
          {
            Object localObject2;
            switch (arrayOfInt2[i])
            {
            case -1: 
            case 2005: 
              if (arrayOfInt2[i] == 2005)
              {
                localObject2 = new File(localObject1.toString());
                if ((((File)localObject2).exists()) && (((File)localObject2).isFile()) && (((File)localObject2).canRead())) {
                  try
                  {
                    BufferedReader localBufferedReader = new BufferedReader(new FileReader((File)localObject2));
                    this.stmt.setCharacterStream(i + 1, localBufferedReader, (int)((File)localObject2).length());
                  }
                  catch (IOException localIOException1) {}
                } else {
                  this.stmt.setNull(i + 1, 1);
                }
              }
              else
              {
                localObject2 = new StringReader(localObject1.toString());
                this.stmt.setCharacterStream(i + 1, (Reader)localObject2, 65536);
              }
              break;
            case -4: 
            case 2004: 
              localObject2 = new File(localObject1.toString());
              if ((((File)localObject2).exists()) && (((File)localObject2).isFile()) && (((File)localObject2).canRead())) {
                try
                {
                  FileInputStream localFileInputStream = new FileInputStream((File)localObject2);
                  this.stmt.setBinaryStream(i + 1, localFileInputStream, (int)((File)localObject2).length());
                }
                catch (IOException localIOException2) {}
              } else {
                this.stmt.setNull(i + 1, 1);
              }
              break;
            case -3: 
            case -2: 
            case 1: 
            case 12: 
              this.stmt.setString(i + 1, localObject1.toString());
              break;
            case -14: 
            case -13: 
            case -10: 
            case 0: 
            case 70: 
            case 1111: 
            case 2000: 
            case 2001: 
            case 2002: 
            case 2003: 
            case 2006: 
              this.stmt.setNull(i + 1, 1);
              break;
            default: 
              this.stmt.setObject(i + 1, localObject1);
            }
          }
          if (this.paramTypes[i].equals("INOUT")) {
            if (arrayOfInt1[i] > 0) {
              this.stmt.registerOutParameter(i + 1, paramDBRowCache.getColumnType(arrayOfInt1[i]));
            } else {
              this.stmt.registerOutParameter(i + 1, paramVariableTable.getType(this.paramNames[i]));
            }
          }
        }
        else if (this.paramTypes[i].equals("OUT"))
        {
          if (arrayOfInt1[i] > 0) {
            this.stmt.registerOutParameter(i + 1, paramDBRowCache.getColumnType(arrayOfInt1[i]));
          } else {
            this.stmt.registerOutParameter(i + 1, paramVariableTable.getType(this.paramNames[i]));
          }
        }
      }
    }
  }
  
  public void fetch(VariableTable paramVariableTable)
    throws SQLException
  {
    int j = 0;
    if (this.paramNames.length > 0) {
      for (int i = 0; i < this.paramNames.length; i++)
      {
        Object localObject1 = null;
        if ((this.paramTypes[i].equalsIgnoreCase("OUT")) || (this.paramTypes[i].equalsIgnoreCase("INOUT")))
        {
          int k = paramVariableTable.getType(this.paramNames[i]);
          Object localObject2;
          Object localObject3;
          switch (k)
          {
          case 2005: 
            Clob localClob = this.stmt.getClob(i + 1);
            if (localClob != null)
            {
              localObject2 = localClob.getCharacterStream();
              if (localObject2 != null)
              {
                localObject3 = new char[65536];
                try
                {
                  j = ((Reader)localObject2).read((char[])localObject3);
                  if (j > 0) {
                    localObject1 = String.valueOf((char[])localObject3, 0, j);
                  }
                  ((Reader)localObject2).close();
                }
                catch (IOException localIOException1) {}
              }
            }
            break;
          case 2004: 
            localObject2 = this.stmt.getBlob(i + 1);
            if (localObject2 != null)
            {
              localObject3 = ((Blob)localObject2).getBinaryStream();
              if (localObject3 != null)
              {
                byte[] arrayOfByte = new byte[65536];
                try
                {
                  j = ((InputStream)localObject3).read(arrayOfByte);
                  if (j > 0) {
                    localObject1 = new String(arrayOfByte, 0, j);
                  }
                  ((InputStream)localObject3).close();
                }
                catch (IOException localIOException2) {}
              }
            }
            break;
          case -3: 
          case -2: 
          case 1: 
          case 12: 
            localObject1 = this.stmt.getString(i + 1);
            break;
          case 91: 
            localObject1 = this.stmt.getDate(i + 1);
            break;
          case 92: 
            localObject1 = this.stmt.getTime(i + 1);
            break;
          case 93: 
            localObject1 = this.stmt.getTimestamp(i + 1);
            break;
          default: 
            localObject1 = this.stmt.getObject(i + 1);
            if ((localObject1 instanceof ResultSet))
            {
              try
              {
                localObject3 = (ResultSet)localObject1;
                ((ResultSet)localObject3).close();
              }
              catch (SQLException localSQLException) {}
              localObject1 = null;
            }
            break;
          }
          try
          {
            paramVariableTable.setValue(this.paramNames[i], localObject1);
          }
          catch (NumberFormatException localNumberFormatException) {}
        }
      }
    }
  }
}


/* Location:           D:\tmp\oasql.jar
 * Qualified Name:     com.asql.core.SQLCallable
 * JD-Core Version:    0.7.0.1
 */