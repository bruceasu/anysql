package com.asql.core;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Locale;
import java.util.Properties;

public final class DBConnection
{
  public static final String[] DBTYPE = { "ORACLE", "ORAOCI", "SYBASE", "DB2APP", "DB2NET", "INFX", "MSSQL", "DDORA", "DDSYB", "DDDB2", "DDMSSQL", "DDINFX", "MYSQL", "PGSQL", "SAPDB", "NCR", "AS400", "ODBC", "JTDSMSSQL", "JTDSSYB" };
  public static final String[] DBDRIVER = { "oracle.jdbc.driver.OracleDriver", "oracle.jdbc.driver.OracleDriver", "com.sybase.jdbc2.jdbc.SybDriver", "COM.ibm.db2.jdbc.app.DB2Driver", "COM.ibm.db2.jdbc.net.DB2Driver", "com.informix.jdbc.IfxDriver", "com.microsoft.jdbc.sqlserver.SQLServerDriver", "com.ddtek.jdbc.oracle.OracleDriver", "com.ddtek.jdbc.sybase.SybaseDriver", "com.ddtek.jdbc.db2.DB2Driver", "com.ddtek.jdbc.sqlserver.SQLServerDriver", "com.ddtek.jdbc.informix.InformixDriver", "com.mysql.jdbc.Driver", "org.postgresql.Driver", "com.sap.dbtech.jdbc.DriverSapDB", "com.ncr.teradata.TeraDriver", "com.ibm.as400.access.AS400JDBCDriver", "sun.jdbc.odbc.JdbcOdbcDriver", "net.sourceforge.jtds.jdbc.Driver", "net.sourceforge.jtds.jdbc.Driver" };
  public static final String[] DBURL = { "jdbc:oracle:thin:", "jdbc:oracle:oci8:", "jdbc:sybase:Tds:", "jdbc:db2:", "jdbc:db2://", "jdbc:informix-sqli://", "jdbc:sqlserver://", "jdbc:datadirect:oracle://", "jdbc:datadirect:sybase://", "jdbc:datadirect:db2://", "jdbc:datadirect:sqlserver://", "jdbc:datadirect:infomix://", "jdbc:mysql://", "jdbc:postgresql://", "jdbc:sapdb://", "jdbc:teradata://", "jdbc:as400://", "jdbc:odbc:", "jdbc:jtds:sqlserver://", "jdbc:jtds:sybase://" };
  
  public static final Properties getProperties(String paramString)
  {
    return getProperties(paramString, null, null);
  }
  
  public static final Properties getProperties(String paramString1, String paramString2, String paramString3)
  {
    Properties localProperties = new Properties();
    int i = TextUtils.indexOf(DBTYPE, paramString1);
    if ((paramString1 == null) || (i == -1)) {
      return localProperties;
    }
    if (paramString2 != null) {
      localProperties.setProperty("user", paramString2);
    }
    if (paramString3 != null) {
      localProperties.setProperty("password", paramString3);
    }
    switch (i)
    {
    case 6: 
      localProperties.setProperty("SelectMethod", "Cursor");
      break;
    case 7: 
    case 9: 
    case 11: 
      localProperties.setProperty("BatchPerformanceWorkaround", "true");
      break;
    case 8: 
    case 10: 
      localProperties.setProperty("SelectMethod", "Cursor");
      localProperties.setProperty("BatchPerformanceWorkaround", "true");
      break;
    case 12: 
      localProperties.setProperty("useUnicode", "true");
    }
    return localProperties;
  }
  
  public static final Connection getConnection(String paramString1, String paramString2)
    throws SQLException
  {
    return getConnection(paramString1, paramString2, null, null);
  }
  
  public static final Connection getConnection(String paramString1, String paramString2, String paramString3, String paramString4)
    throws SQLException
  {
    Properties localProperties = getProperties(paramString1);
    int i = TextUtils.indexOf(DBTYPE, paramString1);
    if (paramString3 != null) {
      localProperties.setProperty("user", paramString3);
    }
    if (paramString4 != null) {
      localProperties.setProperty("password", paramString4);
    }
    if ((paramString2 == null) || (paramString1 == null) || (i == -1)) {
      return null;
    }
    return DriverManager.getConnection(DBURL[i] + paramString2, localProperties);
  }
  
  public static final Connection getConnection(String paramString1, String paramString2, Properties paramProperties)
    throws SQLException
  {
    return getConnection(paramString1, paramString2, null, null, paramProperties);
  }
  
  public static final Connection getConnection(String paramString1, String paramString2, String paramString3, String paramString4, Properties paramProperties)
    throws SQLException
  {
    int i = TextUtils.indexOf(DBTYPE, paramString1);
    if (paramString3 != null) {
      paramProperties.setProperty("user", paramString3);
    }
    if (paramString4 != null) {
      paramProperties.setProperty("password", paramString4);
    }
    if ((paramString2 == null) || (paramString1 == null) || (i == -1)) {
      return null;
    }
    return DriverManager.getConnection(DBURL[i] + paramString2, paramProperties);
  }
  
  public static final void setEncoding(String paramString)
  {
    Properties localProperties = System.getProperties();
    localProperties.setProperty("file.encoding", paramString);
    System.setProperties(localProperties);
    JavaVM.refresh();
  }
  
  public static final void setLocale(String paramString)
  {
    String str = paramString;
    if (str == null) {
      return;
    }
    str = str.toUpperCase();
    if (str.equals("ENGLISH")) {
      Locale.setDefault(Locale.ENGLISH);
    } else if (str.equals("FRENCH")) {
      Locale.setDefault(Locale.FRENCH);
    } else if (str.equals("GERMAN")) {
      Locale.setDefault(Locale.GERMAN);
    } else if (str.equals("ITALIAN")) {
      Locale.setDefault(Locale.ITALIAN);
    } else if (str.equals("JAPANESE")) {
      Locale.setDefault(Locale.JAPANESE);
    } else if (str.equals("KOREAN")) {
      Locale.setDefault(Locale.KOREAN);
    } else if (str.equals("CHINESE")) {
      Locale.setDefault(Locale.CHINESE);
    } else if (str.equals("SIMPLIFIED_CHINESE")) {
      Locale.setDefault(Locale.SIMPLIFIED_CHINESE);
    } else if (str.equals("TRADITIONAL_CHINESE")) {
      Locale.setDefault(Locale.TRADITIONAL_CHINESE);
    } else if (str.equals("FRANCE")) {
      Locale.setDefault(Locale.FRANCE);
    } else if (str.equals("GERMANY")) {
      Locale.setDefault(Locale.GERMANY);
    } else if (str.equals("ITALY")) {
      Locale.setDefault(Locale.ITALY);
    } else if (str.equals("JAPAN")) {
      Locale.setDefault(Locale.JAPAN);
    } else if (str.equals("KOREA")) {
      Locale.setDefault(Locale.KOREA);
    } else if (str.equals("CHINA")) {
      Locale.setDefault(Locale.CHINA);
    } else if (str.equals("PRC")) {
      Locale.setDefault(Locale.PRC);
    } else if (str.equals("TAIWAN")) {
      Locale.setDefault(Locale.TAIWAN);
    } else if (str.equals("UK")) {
      Locale.setDefault(Locale.UK);
    } else if (str.equals("US")) {
      Locale.setDefault(Locale.US);
    } else if (str.equals("CANADA")) {
      Locale.setDefault(Locale.CANADA);
    } else if (str.equals("CANADA_FRENCH")) {
      Locale.setDefault(Locale.CANADA_FRENCH);
    }
  }
  
  static
  {
    for (int i = 0; i < DBDRIVER.length; i++) {
      try
      {
        Class.forName(DBDRIVER[i]);
      }
      catch (ClassNotFoundException localClassNotFoundException) {}
    }
  }
}


/* Location:           D:\tmp\oasql.jar
 * Qualified Name:     com.asql.core.DBConnection
 * JD-Core Version:    0.7.0.1
 */