package com.asql.core;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public final class SQLStatement
{
  private String SourceSQL = null;
  private String DestSQL = null;
  public PreparedStatement stmt = null;
  private String[] paramNames = new String[0];
  private String[] paramTypes = new String[0];
  
  public SQLStatement(PreparedStatement paramPreparedStatement, SQLQuery paramSQLQuery)
  {
    this.stmt = paramPreparedStatement;
    this.SourceSQL = paramSQLQuery.getSourceSQL();
    this.DestSQL = paramSQLQuery.getDestSQL();
    this.paramNames = paramSQLQuery.getParamNames();
    this.paramTypes = paramSQLQuery.getParamTypes();
  }
  
  public final String getSourceSQL()
  {
    return this.SourceSQL;
  }
  
  public final String getDestSQL()
  {
    return this.DestSQL;
  }
  
  public final String[] getParamNames()
  {
    return this.paramNames;
  }
  
  public final String[] getParamTypes()
  {
    return this.paramTypes;
  }
  
  public void close()
    throws SQLException
  {
    if (this.stmt != null)
    {
      this.stmt.close();
      this.stmt = null;
    }
  }
  
  public boolean getMoreResults()
    throws SQLException
  {
    return this.stmt.getMoreResults();
  }
  
  public int getUpdateCount()
    throws SQLException
  {
    return this.stmt.getUpdateCount();
  }
  
  public ResultSet getResultSet()
    throws SQLException
  {
    return this.stmt.getResultSet();
  }
  
  public boolean execute(VariableTable paramVariableTable)
    throws SQLException
  {
    bind(paramVariableTable);
    return this.stmt.execute();
  }
  
  public void bind(VariableTable paramVariableTable)
    throws SQLException
  {
    try
    {
      this.stmt.clearParameters();
    }
    catch (SQLException localSQLException) {}
    if (this.paramNames.length > 0) {
      for (int i = 0; i < this.paramNames.length; i++)
      {
        int j = paramVariableTable.getType(this.paramNames[i]);
        Object localObject1 = paramVariableTable.getValue(this.paramNames[i]);
        if (localObject1 == null)
        {
          this.stmt.setNull(i + 1, 1);
        }
        else
        {
          Object localObject2;
          switch (j)
          {
          case -3: 
          case -2: 
          case 1: 
          case 12: 
            this.stmt.setString(i + 1, localObject1.toString());
            break;
          case -1: 
          case 2005: 
            if (j == 2005)
            {
              localObject2 = new File(localObject1.toString());
              if ((((File)localObject2).exists()) && (((File)localObject2).isFile()) && (((File)localObject2).canRead())) {
                try
                {
                  BufferedReader localBufferedReader = new BufferedReader(new FileReader((File)localObject2));
                  this.stmt.setCharacterStream(i + 1, localBufferedReader, (int)((File)localObject2).length());
                }
                catch (IOException localIOException1) {}
              } else {
                this.stmt.setNull(i + 1, 1);
              }
            }
            else
            {
              localObject2 = new StringReader(localObject1.toString());
              this.stmt.setCharacterStream(i + 1, (Reader)localObject2, 65536);
            }
            break;
          case -4: 
          case 2004: 
            localObject2 = new File(localObject1.toString());
            if ((((File)localObject2).exists()) && (((File)localObject2).isFile()) && (((File)localObject2).canRead())) {
              try
              {
                FileInputStream localFileInputStream = new FileInputStream((File)localObject2);
                this.stmt.setBinaryStream(i + 1, localFileInputStream, (int)((File)localObject2).length());
              }
              catch (IOException localIOException2) {}
            } else {
              this.stmt.setNull(i + 1, 1);
            }
            break;
          case -14: 
          case -13: 
          case -10: 
          case 0: 
          case 70: 
          case 1111: 
          case 2000: 
          case 2001: 
          case 2002: 
          case 2003: 
          case 2006: 
            this.stmt.setNull(i + 1, 1);
            break;
          default: 
            this.stmt.setObject(i + 1, localObject1);
          }
        }
      }
    }
  }
  
  public final void bind(VariableTable paramVariableTable, DBRowCache paramDBRowCache, int paramInt)
    throws SQLException
  {
    int[] arrayOfInt1 = new int[0];
    int[] arrayOfInt2 = new int[0];
    int i = 0;
    int j = 1;
    Object localObject1 = null;
    if (this.paramNames.length > 0)
    {
      arrayOfInt1 = new int[this.paramNames.length];
      arrayOfInt2 = new int[this.paramNames.length];
      for (i = 0; i < this.paramNames.length; i++)
      {
        arrayOfInt1[i] = paramDBRowCache.findColumn(this.paramNames[i]);
        if (arrayOfInt1[i] > 0) {
          arrayOfInt2[i] = paramDBRowCache.getColumnType(arrayOfInt1[i]);
        } else {
          arrayOfInt2[i] = paramVariableTable.getType(this.paramNames[i]);
        }
      }
    }
    if (this.paramNames.length > 0)
    {
      Object[] arrayOfObject = paramDBRowCache.getRow(j);
      for (i = 0; i < this.paramNames.length; i++)
      {
        if (arrayOfInt1[i] > 0) {
          localObject1 = arrayOfObject[(arrayOfInt1[i] - 1)];
        } else {
          localObject1 = paramVariableTable.getValue(this.paramNames[i]);
        }
        if (localObject1 == null)
        {
          this.stmt.setNull(i + 1, 1);
        }
        else
        {
          Object localObject2;
          switch (arrayOfInt2[i])
          {
          case -1: 
          case 2005: 
            if (arrayOfInt2[i] == 2005)
            {
              localObject2 = new File(localObject1.toString());
              if ((((File)localObject2).exists()) && (((File)localObject2).isFile()) && (((File)localObject2).canRead())) {
                try
                {
                  BufferedReader localBufferedReader = new BufferedReader(new FileReader((File)localObject2));
                  this.stmt.setCharacterStream(i + 1, localBufferedReader, (int)((File)localObject2).length());
                }
                catch (IOException localIOException1) {}
              } else {
                this.stmt.setNull(i + 1, 1);
              }
            }
            else
            {
              localObject2 = new StringReader(localObject1.toString());
              this.stmt.setCharacterStream(i + 1, (Reader)localObject2, 65536);
            }
            break;
          case -4: 
          case 2004: 
            localObject2 = new File(localObject1.toString());
            if ((((File)localObject2).exists()) && (((File)localObject2).isFile()) && (((File)localObject2).canRead())) {
              try
              {
                FileInputStream localFileInputStream = new FileInputStream((File)localObject2);
                this.stmt.setBinaryStream(i + 1, localFileInputStream, (int)((File)localObject2).length());
              }
              catch (IOException localIOException2) {}
            } else {
              this.stmt.setNull(i + 1, 1);
            }
            break;
          case -3: 
          case -2: 
          case 1: 
          case 12: 
            this.stmt.setString(i + 1, localObject1.toString());
            break;
          case -14: 
          case -13: 
          case -10: 
          case 0: 
          case 70: 
          case 1111: 
          case 2000: 
          case 2001: 
          case 2002: 
          case 2003: 
          case 2006: 
            this.stmt.setNull(i + 1, 1);
            break;
          default: 
            this.stmt.setObject(i + 1, localObject1);
          }
        }
      }
    }
  }
  
  public final int[] executeBatch(DBRowCache paramDBRowCache)
    throws SQLException
  {
    return executeBatch(new VariableTable(), paramDBRowCache, 1, paramDBRowCache.getRowCount());
  }
  
  public final int[] executeBatch(DBRowCache paramDBRowCache, int paramInt1, int paramInt2)
    throws SQLException
  {
    return executeBatch(new VariableTable(), paramDBRowCache, paramInt1, paramInt2);
  }
  
  public final int[] executeBatch(VariableTable paramVariableTable, DBRowCache paramDBRowCache)
    throws SQLException
  {
    return executeBatch(paramVariableTable, paramDBRowCache, 1, paramDBRowCache.getRowCount());
  }
  
  public final int[] executeBatch(VariableTable paramVariableTable, DBRowCache paramDBRowCache, int paramInt1, int paramInt2)
    throws SQLException
  {
    int[] arrayOfInt1 = new int[0];
    int[] arrayOfInt2 = new int[0];
    int i = 0;
    int j = 1;
    Object localObject1 = null;
    if (this.paramNames.length > 0)
    {
      arrayOfInt1 = new int[this.paramNames.length];
      arrayOfInt2 = new int[this.paramNames.length];
      for (i = 0; i < this.paramNames.length; i++)
      {
        arrayOfInt1[i] = paramDBRowCache.findColumn(this.paramNames[i]);
        if (arrayOfInt1[i] > 0) {
          arrayOfInt2[i] = paramDBRowCache.getColumnType(arrayOfInt1[i]);
        } else {
          arrayOfInt2[i] = paramVariableTable.getType(this.paramNames[i]);
        }
      }
    }
    this.stmt.clearBatch();
    for (j = paramInt1; j <= paramInt2; j++) {
      try
      {
        if (this.paramNames.length > 0)
        {
          Object[] arrayOfObject = paramDBRowCache.getRow(j);
          for (i = 0; i < this.paramNames.length; i++)
          {
            if (arrayOfInt1[i] > 0) {
              localObject1 = arrayOfObject[(arrayOfInt1[i] - 1)];
            } else {
              localObject1 = paramVariableTable.getValue(this.paramNames[i]);
            }
            if (localObject1 == null)
            {
              this.stmt.setNull(i + 1, 1);
            }
            else
            {
              Object localObject2;
              switch (arrayOfInt2[i])
              {
              case -1: 
              case 2005: 
                if (arrayOfInt2[i] == 2005)
                {
                  localObject2 = new File(localObject1.toString());
                  if ((((File)localObject2).exists()) && (((File)localObject2).isFile()) && (((File)localObject2).canRead())) {
                    try
                    {
                      BufferedReader localBufferedReader = new BufferedReader(new FileReader((File)localObject2));
                      this.stmt.setCharacterStream(i + 1, localBufferedReader, (int)((File)localObject2).length());
                    }
                    catch (IOException localIOException1) {}
                  } else {
                    this.stmt.setNull(i + 1, 1);
                  }
                }
                else
                {
                  localObject2 = new StringReader(localObject1.toString());
                  this.stmt.setCharacterStream(i + 1, (Reader)localObject2, 65536);
                }
                break;
              case -4: 
              case 2004: 
                localObject2 = new File(localObject1.toString());
                if ((((File)localObject2).exists()) && (((File)localObject2).isFile()) && (((File)localObject2).canRead())) {
                  try
                  {
                    FileInputStream localFileInputStream = new FileInputStream((File)localObject2);
                    this.stmt.setBinaryStream(i + 1, localFileInputStream, (int)((File)localObject2).length());
                  }
                  catch (IOException localIOException2) {}
                } else {
                  this.stmt.setNull(i + 1, 1);
                }
                break;
              case -3: 
              case -2: 
              case 1: 
              case 12: 
                this.stmt.setString(i + 1, localObject1.toString());
                break;
              case -14: 
              case -13: 
              case -10: 
              case 0: 
              case 70: 
              case 1111: 
              case 2000: 
              case 2001: 
              case 2002: 
              case 2003: 
              case 2006: 
                this.stmt.setNull(i + 1, 1);
                break;
              default: 
                this.stmt.setObject(i + 1, localObject1);
              }
            }
          }
        }
        this.stmt.addBatch();
      }
      catch (SQLException localSQLException)
      {
        this.stmt.clearBatch();
        throw localSQLException;
      }
    }
    return this.stmt.executeBatch();
  }
}


/* Location:           D:\tmp\oasql.jar
 * Qualified Name:     com.asql.core.SQLStatement
 * JD-Core Version:    0.7.0.1
 */