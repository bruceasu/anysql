package com.asql.core;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintStream;

public class PasswordReader
{
  public static String readPassword(String paramString)
    throws Exception
  {
    ConsoleEraser localConsoleEraser = new ConsoleEraser();
    System.out.print(paramString);
    BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(System.in));
    localConsoleEraser.start();
    String str = localBufferedReader.readLine();
    localConsoleEraser.halt();
    System.out.print("\b");
    return str;
  }
}


/* Location:           D:\tmp\oasql.jar
 * Qualified Name:     com.asql.core.PasswordReader
 * JD-Core Version:    0.7.0.1
 */