package com.asql.core;

import java.io.IOException;
import java.util.Vector;

public abstract class CMDType
{
  public static final int SQL_QUERY = 0;
  public static final int SQL_DML = 1;
  public static final int SQL_DDL = 2;
  public static final int SQL_SCRIPT = 3;
  public static final int SQL_CALL = 4;
  public static final int SQL_BLOCK = 13;
  public static final int ASQL_SINGLE = 5;
  public static final int ASQL_MULTIPLE = 6;
  public static final int ASQL_END = 7;
  public static final int ASQL_EXIT = 8;
  public static final int ASQL_CANCEL = 9;
  public static final int ASQL_COMMENT = 11;
  public static final int ASQL_SQLFILE = 16;
  public static final int UNKNOWN_COMMAND = 10;
  public static final int NULL_COMMAND = 12;
  public static final int MULTI_COMMENT_START = 14;
  public static final int MULTI_COMMENT_END = 15;
  public static final int ASQL_DBCOMMAND = 17;
  public static final int DISABLED_COMMAND = 18;
  private boolean multi_comment = false;
  private boolean query_only = true;
  
  public final void setQueryOnly(boolean paramBoolean)
  {
    this.query_only = paramBoolean;
  }
  
  public final boolean getQueryOnly()
  {
    return this.query_only;
  }
  
  public static final String getName(int paramInt)
  {
    switch (paramInt)
    {
    case 0: 
      return "SQL_QUERY";
    case 1: 
      return "SQL_DML";
    case 2: 
      return "SQL_DDL";
    case 3: 
      return "SQL_SCRIPT";
    case 4: 
      return "SQL_CALL";
    case 5: 
      return "ASQL_SINGLE";
    case 6: 
      return "ASQL_MULTIPLE";
    case 7: 
      return "ASQL_END";
    case 8: 
      return "ASQL_EXIT";
    case 9: 
      return "ASQL_CANCEL";
    case 11: 
      return "ASQL_COMMENT";
    case 10: 
      return "UNKNOWN_COMMAND";
    case 12: 
      return "NULL_COMMAND";
    case 13: 
      return "SQL_BLOCK";
    case 16: 
      return "ASQL_SQLFILE";
    case 14: 
      return "/*";
    case 15: 
      return "*/";
    }
    return "UNKNOWN_COMMAND";
  }
  
  public final String getPrompt(int paramInt)
  {
    if (paramInt <= 1)
    {
      if (this.multi_comment) {
        return "ADOC> ";
      }
      return "ASQL> ";
    }
    StringBuffer localStringBuffer = new StringBuffer();
    String str = String.valueOf(paramInt);
    for (int i = 0; i < 5 - str.length(); i++) {
      localStringBuffer.append(' ');
    }
    localStringBuffer.append(str);
    localStringBuffer.append(' ');
    return localStringBuffer.toString();
  }
  
  public abstract String[] getSQLQuery();
  
  public abstract String[] getSQLDML();
  
  public abstract String[] getSQLDDL();
  
  public abstract String[] getSQLScript();
  
  public abstract String[] getSQLBlock();
  
  public abstract String[] getSQLCall();
  
  public abstract String[] getASQLSingle();
  
  public abstract String[] getASQLMultiple();
  
  public abstract String[] getEnd();
  
  public abstract String[] getCancel();
  
  public abstract String[] getDBCommand();
  
  public abstract String[] getComment();
  
  public abstract String[] getSQLFile();
  
  public abstract char getCompleteChar();
  
  public abstract char getContinueChar();
  
  public abstract String[] getMultipleStart();
  
  public abstract String[] getMultipleEnd();
  
  public abstract String[] getCommandHint();
  
  public String[] getExit()
  {
    return new String[] { "EXIT", "QUIT" };
  }
  
  public final int endsWith(String[] paramArrayOfString, String paramString)
  {
    if ((paramString == null) && (paramString.length() == 0)) {
      return -1;
    }
    int j;
    for (int i = paramString.length() - 1; (i >= 0) && (((j = paramString.charAt(i)) == ' ') || (j == 9) || (j == 13) || (j == 10)); i--) {}
    if (i == -1) {
      return -1;
    }
    for (int k = 0; k < paramArrayOfString.length; k++) {
      if (paramString.lastIndexOf(paramArrayOfString[k]) == i - paramArrayOfString[k].length() + 1) {
        return k;
      }
    }
    return -1;
  }
  
  public final int startsWith(String[] paramArrayOfString, String paramString)
  {
    if ((paramString == null) && (paramString.length() == 0)) {
      return -1;
    }
    int j;
    for (int i = 0; (i < paramString.length()) && (((j = paramString.charAt(i)) == ' ') || (j == 9)); i++) {}
    for (int k = 0; k < paramArrayOfString.length; k++) {
      if (paramString.indexOf(paramArrayOfString[k]) == i) {
        return k;
      }
    }
    return -1;
  }
  
  private final boolean commandCheck(String[] paramArrayOfString1, String[] paramArrayOfString2)
  {
    if (paramArrayOfString2 == null) {
      return false;
    }
    if (paramArrayOfString2.length == 0) {
      return false;
    }
    if (paramArrayOfString1.length == 0) {
      return false;
    }
    int i = 0;
    int j = 0;
    boolean bool = false;
    if ((paramArrayOfString1.length == 1) && (paramArrayOfString1[0].equalsIgnoreCase("*"))) {
      return true;
    }
    for (i = 0; i < paramArrayOfString1.length; i++)
    {
      j = 0;
      String[] arrayOfString = TextUtils.toStringArray(TextUtils.getWords(paramArrayOfString1[i]));
      if (arrayOfString.length <= paramArrayOfString2.length)
      {
        bool = true;
        for (j = 0; j < arrayOfString.length; j++) {
          if (!arrayOfString[j].equalsIgnoreCase(paramArrayOfString2[j]))
          {
            bool = false;
            break;
          }
        }
        if (bool) {
          return bool;
        }
      }
    }
    return false;
  }
  
  private final boolean commandEqual(String[] paramArrayOfString1, String[] paramArrayOfString2)
  {
    if (paramArrayOfString2 == null) {
      return false;
    }
    if (paramArrayOfString2.length == 0) {
      return false;
    }
    if (paramArrayOfString1.length == 0) {
      return false;
    }
    int i = 0;
    int j = 0;
    boolean bool = false;
    for (i = 0; i < paramArrayOfString1.length; i++)
    {
      j = 0;
      String[] arrayOfString = TextUtils.toStringArray(TextUtils.getWords(paramArrayOfString1[i]));
      if (arrayOfString.length == paramArrayOfString2.length)
      {
        bool = true;
        for (j = 0; j < arrayOfString.length; j++) {
          if (!arrayOfString[j].equalsIgnoreCase(paramArrayOfString2[j]))
          {
            bool = false;
            break;
          }
        }
        if (bool) {
          return bool;
        }
      }
    }
    return false;
  }
  
  public final int getCommandID(String paramString)
  {
    int i = matchLastChar(paramString, getContinueChar());
    if (i == -1) {
      i = matchLastChar(paramString, getCompleteChar());
    }
    String str = paramString;
    if (i > -1) {
      str = paramString.substring(0, i);
    }
    String[] arrayOfString = TextUtils.toStringArray(TextUtils.getWords(str));
    if (this.multi_comment) {
      return 14;
    }
    if (arrayOfString.length == 0) {
      return 12;
    }
    if (commandCheck(getASQLSingle(), arrayOfString)) {
      return 5;
    }
    if (commandCheck(getSQLQuery(), arrayOfString)) {
      return 0;
    }
    if (commandCheck(getSQLScript(), arrayOfString)) {
      return this.query_only ? 18 : 3;
    }
    if (commandCheck(getSQLDDL(), arrayOfString)) {
      return this.query_only ? 18 : 2;
    }
    if (commandCheck(getSQLDML(), arrayOfString)) {
      return this.query_only ? 18 : 1;
    }
    if (commandCheck(getSQLCall(), arrayOfString)) {
      return this.query_only ? 18 : 4;
    }
    if (commandCheck(getSQLBlock(), arrayOfString)) {
      return this.query_only ? 18 : 13;
    }
    if (commandCheck(getDBCommand(), arrayOfString)) {
      return 17;
    }
    if (startsWith(getComment(), paramString) != -1) {
      return 11;
    }
    if (startsWith(getSQLFile(), paramString) != -1) {
      return 16;
    }
    if (startsWith(getMultipleStart(), paramString) != -1) {
      return 14;
    }
    if (commandCheck(getASQLMultiple(), arrayOfString)) {
      return 6;
    }
    if (commandEqual(getEnd(), arrayOfString)) {
      return 7;
    }
    if (commandEqual(getExit(), arrayOfString)) {
      return 8;
    }
    if (commandEqual(getCancel(), arrayOfString)) {
      return 9;
    }
    return 10;
  }
  
  private int matchLastChar(String paramString, char paramChar)
  {
    if (paramString == null) {
      return -1;
    }
    if (paramChar == ' ') {
      return -1;
    }
    char[] arrayOfChar = paramString.toCharArray();
    if (arrayOfChar.length == 0) {
      return -1;
    }
    int i = arrayOfChar.length - 1;
    while ((arrayOfChar[i] == ' ') || (arrayOfChar[i] == '\t') || (arrayOfChar[i] == '\r') || (arrayOfChar[i] == '\n'))
    {
      i--;
      if (i < 0) {
        return -1;
      }
    }
    if (arrayOfChar[i] == paramChar) {
      return i;
    }
    return -1;
  }
  
  public final boolean isCommandReady(int paramInt1, int paramInt2, String paramString)
  {
    switch (paramInt1)
    {
    case 7: 
    case 8: 
    case 9: 
    case 10: 
    case 11: 
    case 12: 
    case 14: 
    case 18: 
      return true;
    case 4: 
    case 5: 
    case 16: 
    case 17: 
      return matchLastChar(paramString, getContinueChar()) < 0;
    case 3: 
    case 13: 
      return (paramInt2 == 7) || (paramInt2 == 9);
    case 0: 
    case 1: 
    case 2: 
    case 6: 
      if ((paramInt2 == 7) || (paramInt2 == 9)) {
        return true;
      }
      return matchLastChar(paramString, getCompleteChar()) >= 0;
    }
    return true;
  }
  
  public final Command readCommand(CommandReader paramCommandReader)
    throws IOException
  {
    Vector localVector = new Vector(10, 10);
    String str = null;
    int i = -1;
    int j = -1;
    int k = -1;
    while ((str = paramCommandReader.readline()) != null)
    {
      if (i == -1) {
        i = getCommandID(str);
      }
      if (i == 14) {
        this.multi_comment = true;
      }
      if (this.multi_comment)
      {
        if (endsWith(getMultipleEnd(), str) != -1)
        {
          j = 15;
          this.multi_comment = false;
        }
        else
        {
          j = getCommandID(str);
        }
      }
      else {
        j = getCommandID(str);
      }
      if (isCommandReady(i, j, str))
      {
        switch (i)
        {
        case 3: 
        case 13: 
          break;
        case 0: 
        case 1: 
        case 2: 
        case 6: 
          if ((j != 7) && (j != 9))
          {
            k = matchLastChar(str, getCompleteChar());
            if (k >= 0) {
              localVector.addElement(str.substring(0, k));
            } else {
              localVector.addElement(str);
            }
          }
          break;
        case 4: 
        case 5: 
        case 16: 
        case 17: 
          k = matchLastChar(str, getContinueChar());
          if (k == -1) {
            k = matchLastChar(str, getCompleteChar());
          }
          if (k > -1) {
            localVector.addElement(str.substring(0, k));
          } else {
            localVector.addElement(str);
          }
          break;
        case 7: 
        case 8: 
        case 9: 
        case 10: 
          k = matchLastChar(str, getContinueChar());
          if (k == -1) {
            k = matchLastChar(str, getCompleteChar());
          }
          if (k > -1) {
            localVector.addElement(str.substring(0, k));
          } else {
            localVector.addElement(str);
          }
          break;
        case 11: 
          localVector.addElement(str);
          if (j == 15) {
            this.multi_comment = false;
          }
          break;
        case 14: 
          localVector.addElement(str);
          if (j == 15) {
            this.multi_comment = false;
          }
          break;
        }
        break;
      }
      switch (i)
      {
      case 5: 
      case 7: 
      case 8: 
      case 9: 
      case 10: 
      case 11: 
      case 12: 
      case 16: 
      case 17: 
        k = matchLastChar(str, getContinueChar());
        if (k == -1) {
          k = matchLastChar(str, getCompleteChar());
        }
        if (k > -1) {
          localVector.addElement(str.substring(0, k));
        } else {
          localVector.addElement(str);
        }
        break;
      case 6: 
      case 13: 
      case 14: 
      case 15: 
      default: 
        localVector.addElement(str);
      }
    }
    if ((str == null) && (localVector.size() == 0)) {
      return new Command(8, 8, null, paramCommandReader.getWorkingDir());
    }
    StringBuffer localStringBuffer = new StringBuffer();
    for (int m = 0; m < localVector.size(); m++)
    {
      localStringBuffer.append((String)localVector.elementAt(m));
      if (m < localVector.size() - 1) {
        localStringBuffer.append("\n");
      }
    }
    return new Command(i, j, localStringBuffer.toString(), paramCommandReader.getWorkingDir());
  }
  
  public final Command readCommand(CommandReader paramCommandReader, CommandLog paramCommandLog)
    throws IOException
  {
    return readCommand(paramCommandReader, paramCommandLog, false);
  }
  
  public final Command readCommand(CommandReader paramCommandReader, CommandLog paramCommandLog, boolean paramBoolean)
    throws IOException
  {
    Vector localVector = new Vector(10, 10);
    String str = null;
    int i = -1;
    int j = -1;
    int k = -1;
    paramCommandLog.prompt(getPrompt(localVector.size() + 1));
    while ((str = paramCommandReader.readline()) != null)
    {
      if (paramBoolean) {
        paramCommandLog.println(str);
      } else if (paramCommandLog.getLogFile() != null) {
        paramCommandLog.getLogFile().println(str);
      }
      if (i == -1) {
        i = getCommandID(str);
      }
      if (i == 14) {
        this.multi_comment = true;
      }
      if (this.multi_comment)
      {
        if (endsWith(getMultipleEnd(), str) != -1)
        {
          j = 15;
          this.multi_comment = false;
        }
        else
        {
          j = getCommandID(str);
        }
      }
      else {
        j = getCommandID(str);
      }
      if (isCommandReady(i, j, str))
      {
        switch (i)
        {
        case 3: 
        case 13: 
          break;
        case 0: 
        case 1: 
        case 2: 
        case 6: 
          if ((j != 7) && (j != 9))
          {
            k = matchLastChar(str, getCompleteChar());
            if (k >= 0) {
              localVector.addElement(str.substring(0, k));
            } else {
              localVector.addElement(str);
            }
          }
          break;
        case 4: 
        case 5: 
        case 16: 
        case 17: 
          k = matchLastChar(str, getContinueChar());
          if (k == -1) {
            k = matchLastChar(str, getCompleteChar());
          }
          if (k > -1) {
            localVector.addElement(str.substring(0, k));
          } else {
            localVector.addElement(str);
          }
          break;
        case 7: 
        case 8: 
        case 9: 
        case 10: 
          k = matchLastChar(str, getContinueChar());
          if (k == -1) {
            k = matchLastChar(str, getCompleteChar());
          }
          if (k > -1) {
            localVector.addElement(str.substring(0, k));
          } else {
            localVector.addElement(str);
          }
          break;
        case 11: 
          localVector.addElement(str);
          if (j == 15) {
            this.multi_comment = false;
          }
          break;
        case 14: 
          localVector.addElement(str);
          if (j == 15) {
            this.multi_comment = false;
          }
          break;
        }
        break;
      }
      switch (i)
      {
      case 5: 
      case 7: 
      case 8: 
      case 9: 
      case 10: 
      case 11: 
      case 12: 
      case 16: 
      case 17: 
        k = matchLastChar(str, getContinueChar());
        if (k == -1) {
          k = matchLastChar(str, getCompleteChar());
        }
        if (k > -1) {
          localVector.addElement(str.substring(0, k));
        } else {
          localVector.addElement(str);
        }
        break;
      case 6: 
      case 13: 
      case 14: 
      case 15: 
      default: 
        localVector.addElement(str);
      }
      paramCommandLog.prompt(getPrompt(localVector.size() + 1));
    }
    if ((str == null) && (localVector.size() == 0))
    {
      if (paramBoolean) {
        paramCommandLog.println();
      } else if (paramCommandLog.getLogFile() != null) {
        paramCommandLog.getLogFile().println();
      }
      return new Command(8, 8, null, paramCommandReader.getWorkingDir());
    }
    StringBuffer localStringBuffer = new StringBuffer();
    for (int m = 0; m < localVector.size(); m++)
    {
      localStringBuffer.append((String)localVector.elementAt(m));
      if (m < localVector.size() - 1) {
        localStringBuffer.append("\n");
      }
    }
    return new Command(i, j, localStringBuffer.toString(), paramCommandReader.getWorkingDir());
  }
}


/* Location:           D:\tmp\oasql.jar
 * Qualified Name:     com.asql.core.CMDType
 * JD-Core Version:    0.7.0.1
 */