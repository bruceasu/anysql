package com.asql.core;

public final class SQLQuery
{
  private String source = null;
  private String dest = null;
  private String[] paramlist = null;
  private String[] paramtype = null;
  
  public SQLQuery(String paramString1, String paramString2, String[] paramArrayOfString1, String[] paramArrayOfString2)
  {
    this.source = paramString1;
    this.dest = paramString2;
    this.paramlist = paramArrayOfString1;
    this.paramtype = paramArrayOfString2;
  }
  
  public final String getSourceSQL()
  {
    return this.source;
  }
  
  public final String getDestSQL()
  {
    return this.dest;
  }
  
  public final String[] getParamNames()
  {
    return this.paramlist;
  }
  
  public final String[] getParamTypes()
  {
    return this.paramtype;
  }
}


/* Location:           D:\tmp\oasql.jar
 * Qualified Name:     com.asql.core.SQLQuery
 * JD-Core Version:    0.7.0.1
 */