package com.asql.core;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;

public final class DateOperator
{
  private static final int[] Month_Days = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
  
  private static final int getMonthDays(int paramInt1, int paramInt2)
  {
    if (((paramInt1 % 400 == 0) || ((paramInt1 % 4 == 0) && (paramInt1 % 100 != 0))) && (paramInt2 == 2)) {
      return Month_Days[(paramInt2 - 1)] + 1;
    }
    return Month_Days[(paramInt2 - 1)];
  }
  
  public static final String getDay()
  {
    String str = "";
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat();
    localSimpleDateFormat.applyPattern("yyyyMMdd");
    str = localSimpleDateFormat.format(new Date());
    localSimpleDateFormat = null;
    return str;
  }
  
  public static final String getDay(String paramString)
  {
    String str = "";
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat(paramString);
    str = localSimpleDateFormat.format(new Date());
    localSimpleDateFormat = null;
    return str;
  }
  
  public static final String firstDay(String paramString)
  {
    String str = "";
    if (paramString == null) {
      return paramString;
    }
    if (paramString.length() != 8) {
      return paramString;
    }
    if ((paramString.startsWith("-")) || (paramString.startsWith("+"))) {
      return paramString;
    }
    try
    {
      long l = Long.valueOf(paramString).longValue();
    }
    catch (NumberFormatException localNumberFormatException1)
    {
      return paramString;
    }
    int i;
    int j;
    int k;
    try
    {
      i = Integer.valueOf(paramString.substring(0, 4)).intValue();
      j = Integer.valueOf(paramString.substring(4, 6)).intValue();
      k = Integer.valueOf(paramString.substring(6, 8)).intValue();
    }
    catch (NumberFormatException localNumberFormatException2)
    {
      return paramString;
    }
    if ((j > 12) || (j < 1)) {
      return paramString;
    }
    if ((k > getMonthDays(i, j)) || (k < 1)) {
      return paramString;
    }
    str = String.valueOf(i);
    if (j < 10) {
      str = str + "0" + j;
    } else {
      str = str + j;
    }
    str = str + "01";
    return str;
  }
  
  public static final String firstQuaterDay(String paramString)
  {
    String str = "";
    if (paramString == null) {
      return paramString;
    }
    if (paramString.length() != 8) {
      return paramString;
    }
    if ((paramString.startsWith("-")) || (paramString.startsWith("+"))) {
      return paramString;
    }
    try
    {
      long l = Long.valueOf(paramString).longValue();
    }
    catch (NumberFormatException localNumberFormatException1)
    {
      return paramString;
    }
    int i;
    int k;
    try
    {
      i = Integer.valueOf(paramString.substring(0, 4)).intValue();
      j = Integer.valueOf(paramString.substring(4, 6)).intValue();
      k = Integer.valueOf(paramString.substring(6, 8)).intValue();
    }
    catch (NumberFormatException localNumberFormatException2)
    {
      return paramString;
    }
    if ((j > 12) || (j < 1)) {
      return paramString;
    }
    if ((k > getMonthDays(i, j)) || (k < 1)) {
      return paramString;
    }
    str = String.valueOf(i);
    int j = (j - 1) / 3 * 3 + 1;
    if (j < 10) {
      str = str + "0" + j;
    } else {
      str = str + j;
    }
    str = str + "01";
    return str;
  }
  
  public static final String lastQuaterDay(String paramString)
  {
    String str = "";
    if (paramString == null) {
      return paramString;
    }
    if (paramString.length() != 8) {
      return paramString;
    }
    if ((paramString.startsWith("-")) || (paramString.startsWith("+"))) {
      return paramString;
    }
    try
    {
      long l = Long.valueOf(paramString).longValue();
    }
    catch (NumberFormatException localNumberFormatException1)
    {
      return paramString;
    }
    int i;
    int k;
    try
    {
      i = Integer.valueOf(paramString.substring(0, 4)).intValue();
      j = Integer.valueOf(paramString.substring(4, 6)).intValue();
      k = Integer.valueOf(paramString.substring(6, 8)).intValue();
    }
    catch (NumberFormatException localNumberFormatException2)
    {
      return paramString;
    }
    if ((j > 12) || (j < 1)) {
      return paramString;
    }
    if ((k > getMonthDays(i, j)) || (k < 1)) {
      return paramString;
    }
    str = String.valueOf(i);
    int j = ((j - 1) / 3 + 1) * 3;
    if (j < 10) {
      str = str + "0" + j;
    } else {
      str = str + j;
    }
    str = str + getMonthDays(i, j);
    return str;
  }
  
  public static final String firstYearDay(String paramString)
  {
    String str = "";
    if (paramString == null) {
      return paramString;
    }
    if (paramString.length() != 8) {
      return paramString;
    }
    if ((paramString.startsWith("-")) || (paramString.startsWith("+"))) {
      return paramString;
    }
    try
    {
      long l = Long.valueOf(paramString).longValue();
    }
    catch (NumberFormatException localNumberFormatException1)
    {
      return paramString;
    }
    int i;
    int j;
    int k;
    try
    {
      i = Integer.valueOf(paramString.substring(0, 4)).intValue();
      j = Integer.valueOf(paramString.substring(4, 6)).intValue();
      k = Integer.valueOf(paramString.substring(6, 8)).intValue();
    }
    catch (NumberFormatException localNumberFormatException2)
    {
      return paramString;
    }
    if ((j > 12) || (j < 1)) {
      return paramString;
    }
    if ((k > getMonthDays(i, j)) || (k < 1)) {
      return paramString;
    }
    str = String.valueOf(i);
    str = str + "0101";
    return str;
  }
  
  public static final String lastYearDay(String paramString)
  {
    String str = "";
    if (paramString == null) {
      return paramString;
    }
    if (paramString.length() != 8) {
      return paramString;
    }
    if ((paramString.startsWith("-")) || (paramString.startsWith("+"))) {
      return paramString;
    }
    try
    {
      long l = Long.valueOf(paramString).longValue();
    }
    catch (NumberFormatException localNumberFormatException1)
    {
      return paramString;
    }
    int i;
    int j;
    int k;
    try
    {
      i = Integer.valueOf(paramString.substring(0, 4)).intValue();
      j = Integer.valueOf(paramString.substring(4, 6)).intValue();
      k = Integer.valueOf(paramString.substring(6, 8)).intValue();
    }
    catch (NumberFormatException localNumberFormatException2)
    {
      return paramString;
    }
    if ((j > 12) || (j < 1)) {
      return paramString;
    }
    if ((k > getMonthDays(i, j)) || (k < 1)) {
      return paramString;
    }
    str = String.valueOf(i);
    str = str + "12" + getMonthDays(i, 12);
    return str;
  }
  
  public static final String lastDay(String paramString)
  {
    String str = "";
    if (paramString == null) {
      return paramString;
    }
    if (paramString.length() != 8) {
      return paramString;
    }
    if ((paramString.startsWith("-")) || (paramString.startsWith("+"))) {
      return paramString;
    }
    try
    {
      long l = Long.valueOf(paramString).longValue();
    }
    catch (NumberFormatException localNumberFormatException1)
    {
      return paramString;
    }
    int i;
    int j;
    int k;
    try
    {
      i = Integer.valueOf(paramString.substring(0, 4)).intValue();
      j = Integer.valueOf(paramString.substring(4, 6)).intValue();
      k = Integer.valueOf(paramString.substring(6, 8)).intValue();
    }
    catch (NumberFormatException localNumberFormatException2)
    {
      return paramString;
    }
    if ((j > 12) || (j < 1)) {
      return paramString;
    }
    if ((k > getMonthDays(i, j)) || (k < 1)) {
      return paramString;
    }
    str = String.valueOf(i);
    if (j < 10) {
      str = str + "0" + j;
    } else {
      str = str + j;
    }
    str = str + getMonthDays(i, j);
    return str;
  }
  
  public static final String nextDay(String paramString)
  {
    String str = "";
    if (paramString == null) {
      return paramString;
    }
    if (paramString.length() != 8) {
      return paramString;
    }
    if ((paramString.startsWith("-")) || (paramString.startsWith("+"))) {
      return paramString;
    }
    try
    {
      long l = Long.valueOf(paramString).longValue();
    }
    catch (NumberFormatException localNumberFormatException1)
    {
      return paramString;
    }
    int i;
    int j;
    int k;
    try
    {
      i = Integer.valueOf(paramString.substring(0, 4)).intValue();
      j = Integer.valueOf(paramString.substring(4, 6)).intValue();
      k = Integer.valueOf(paramString.substring(6, 8)).intValue();
    }
    catch (NumberFormatException localNumberFormatException2)
    {
      return paramString;
    }
    if ((j > 12) || (j < 1)) {
      return paramString;
    }
    if ((k > getMonthDays(i, j)) || (k < 1)) {
      return paramString;
    }
    if (k == getMonthDays(i, j))
    {
      k = 1;
      j += 1;
    }
    else
    {
      k += 1;
    }
    if (j > 12)
    {
      j = 1;
      i += 1;
    }
    str = String.valueOf(i);
    if (j < 10) {
      str = str + "0" + j;
    } else {
      str = str + j;
    }
    if (k < 10) {
      str = str + "0" + k;
    } else {
      str = str + k;
    }
    return str;
  }
  
  public static final String prevDay(String paramString)
  {
    String str = "";
    if (paramString == null) {
      return paramString;
    }
    if (paramString.length() != 8) {
      return paramString;
    }
    if ((paramString.startsWith("-")) || (paramString.startsWith("+"))) {
      return paramString;
    }
    try
    {
      long l = Long.valueOf(paramString).longValue();
    }
    catch (NumberFormatException localNumberFormatException1)
    {
      return paramString;
    }
    int i;
    int j;
    int k;
    try
    {
      i = Integer.valueOf(paramString.substring(0, 4)).intValue();
      j = Integer.valueOf(paramString.substring(4, 6)).intValue();
      k = Integer.valueOf(paramString.substring(6, 8)).intValue();
    }
    catch (NumberFormatException localNumberFormatException2)
    {
      return paramString;
    }
    if ((j > 12) || (j < 1)) {
      return paramString;
    }
    if ((k > getMonthDays(i, j)) || (k < 1)) {
      return paramString;
    }
    if (k == 1)
    {
      j -= 1;
      if (j == 0)
      {
        j = 12;
        i -= 1;
      }
      k = getMonthDays(i, j);
    }
    else
    {
      k -= 1;
    }
    str = String.valueOf(i);
    if (j < 10) {
      str = str + "0" + j;
    } else {
      str = str + j;
    }
    if (k < 10) {
      str = str + "0" + k;
    } else {
      str = str + k;
    }
    return str;
  }
  
  public static final String addDays(String paramString, int paramInt)
  {
    int j = Math.abs(paramInt);
    String str = paramString;
    int k = paramInt > 0 ? 1 : 0;
    for (int i = 0; i < j; i++) {
      if (k != 0) {
        str = nextDay(str);
      } else {
        str = prevDay(str);
      }
    }
    return str;
  }
  
  public static final String nextMonth(String paramString)
  {
    int i = 0;
    String str = "";
    if (paramString == null) {
      return paramString;
    }
    if (paramString.length() != 8) {
      return paramString;
    }
    if ((paramString.startsWith("-")) || (paramString.startsWith("+"))) {
      return paramString;
    }
    try
    {
      long l = Long.valueOf(paramString).longValue();
    }
    catch (NumberFormatException localNumberFormatException1)
    {
      return paramString;
    }
    int j;
    int k;
    int m;
    try
    {
      j = Integer.valueOf(paramString.substring(0, 4)).intValue();
      k = Integer.valueOf(paramString.substring(4, 6)).intValue();
      m = Integer.valueOf(paramString.substring(6, 8)).intValue();
    }
    catch (NumberFormatException localNumberFormatException2)
    {
      return paramString;
    }
    if ((k > 12) || (k < 1)) {
      return paramString;
    }
    if ((m > getMonthDays(j, k)) || (m < 1)) {
      return paramString;
    }
    if (m == getMonthDays(j, k)) {
      i = 1;
    } else {
      i = 0;
    }
    k += 1;
    if (k > 12)
    {
      k = 1;
      j += 1;
    }
    if ((i != 0) || (m > getMonthDays(j, k))) {
      m = getMonthDays(j, k);
    }
    str = String.valueOf(j);
    if (k < 10) {
      str = str + "0" + k;
    } else {
      str = str + k;
    }
    if (m < 10) {
      str = str + "0" + m;
    } else {
      str = str + m;
    }
    return str;
  }
  
  public static final String prevMonth(String paramString)
  {
    int i = 0;
    String str = "";
    if (paramString == null) {
      return paramString;
    }
    if (paramString.length() != 8) {
      return paramString;
    }
    if ((paramString.startsWith("-")) || (paramString.startsWith("+"))) {
      return paramString;
    }
    try
    {
      long l = Long.valueOf(paramString).longValue();
    }
    catch (NumberFormatException localNumberFormatException1)
    {
      return paramString;
    }
    int j;
    int k;
    int m;
    try
    {
      j = Integer.valueOf(paramString.substring(0, 4)).intValue();
      k = Integer.valueOf(paramString.substring(4, 6)).intValue();
      m = Integer.valueOf(paramString.substring(6, 8)).intValue();
    }
    catch (NumberFormatException localNumberFormatException2)
    {
      return paramString;
    }
    if ((k > 12) || (k < 1)) {
      return paramString;
    }
    if ((m > getMonthDays(j, k)) || (m < 1)) {
      return paramString;
    }
    if (m == getMonthDays(j, k)) {
      i = 1;
    } else {
      i = 0;
    }
    k -= 1;
    if (k == 0)
    {
      k = 12;
      j -= 1;
    }
    if ((i != 0) || (m > getMonthDays(j, k))) {
      m = getMonthDays(j, k);
    }
    str = String.valueOf(j);
    if (k < 10) {
      str = str + "0" + k;
    } else {
      str = str + k;
    }
    if (m < 10) {
      str = str + "0" + m;
    } else {
      str = str + m;
    }
    return str;
  }
  
  public static final String addMonths(String paramString, int paramInt)
  {
    int j = Math.abs(paramInt);
    String str = paramString;
    int k = paramInt > 0 ? 1 : 0;
    for (int i = 0; i < j; i++) {
      if (k != 0) {
        str = nextMonth(str);
      } else {
        str = prevMonth(str);
      }
    }
    return str;
  }
  
  public static final String firstHarfYearDay(String paramString)
  {
    String str = "";
    if (paramString == null) {
      return paramString;
    }
    if (paramString.length() != 8) {
      return paramString;
    }
    if ((paramString.startsWith("-")) || (paramString.startsWith("+"))) {
      return paramString;
    }
    try
    {
      long l = Long.valueOf(paramString).longValue();
    }
    catch (NumberFormatException localNumberFormatException1)
    {
      return paramString;
    }
    int i;
    int j;
    int k;
    try
    {
      i = Integer.valueOf(paramString.substring(0, 4)).intValue();
      j = Integer.valueOf(paramString.substring(4, 6)).intValue();
      k = Integer.valueOf(paramString.substring(6, 8)).intValue();
    }
    catch (NumberFormatException localNumberFormatException2)
    {
      return paramString;
    }
    if ((j > 12) || (j < 1)) {
      return paramString;
    }
    if ((k > getMonthDays(i, j)) || (k < 1)) {
      return paramString;
    }
    str = String.valueOf(i);
    if (j > 6) {
      j = 7;
    } else {
      j = 1;
    }
    if (j < 10) {
      str = str + "0" + j;
    } else {
      str = str + j;
    }
    str = str + "01";
    return str;
  }
  
  public static final String lastHarfYearDay(String paramString)
  {
    String str = "";
    if (paramString == null) {
      return paramString;
    }
    if (paramString.length() != 8) {
      return paramString;
    }
    if ((paramString.startsWith("-")) || (paramString.startsWith("+"))) {
      return paramString;
    }
    try
    {
      long l = Long.valueOf(paramString).longValue();
    }
    catch (NumberFormatException localNumberFormatException1)
    {
      return paramString;
    }
    int i;
    int j;
    int k;
    try
    {
      i = Integer.valueOf(paramString.substring(0, 4)).intValue();
      j = Integer.valueOf(paramString.substring(4, 6)).intValue();
      k = Integer.valueOf(paramString.substring(6, 8)).intValue();
    }
    catch (NumberFormatException localNumberFormatException2)
    {
      return paramString;
    }
    if ((j > 12) || (j < 1)) {
      return paramString;
    }
    if ((k > getMonthDays(i, j)) || (k < 1)) {
      return paramString;
    }
    str = String.valueOf(i);
    if (j > 6) {
      j = 12;
    } else {
      j = 6;
    }
    if (j < 10) {
      str = str + "0" + j;
    } else {
      str = str + j;
    }
    str = str + getMonthDays(i, j);
    return str;
  }
  
  public static final String firstTenDay(String paramString)
  {
    String str = "";
    if (paramString == null) {
      return paramString;
    }
    if (paramString.length() != 8) {
      return paramString;
    }
    if ((paramString.startsWith("-")) || (paramString.startsWith("+"))) {
      return paramString;
    }
    try
    {
      long l = Long.valueOf(paramString).longValue();
    }
    catch (NumberFormatException localNumberFormatException1)
    {
      return paramString;
    }
    int i;
    int j;
    int k;
    try
    {
      i = Integer.valueOf(paramString.substring(0, 4)).intValue();
      j = Integer.valueOf(paramString.substring(4, 6)).intValue();
      k = Integer.valueOf(paramString.substring(6, 8)).intValue();
    }
    catch (NumberFormatException localNumberFormatException2)
    {
      return paramString;
    }
    if ((j > 12) || (j < 1)) {
      return paramString;
    }
    if ((k > getMonthDays(i, j)) || (k < 1)) {
      return paramString;
    }
    str = String.valueOf(i);
    if (j < 10) {
      str = str + "0" + j;
    } else {
      str = str + j;
    }
    if (k < 11) {
      k = 1;
    } else if (k < 21) {
      k = 11;
    } else {
      k = 21;
    }
    if (k < 10) {
      str = str + "0" + k;
    } else {
      str = str + k;
    }
    return str;
  }
  
  public static final String lastTenDay(String paramString)
  {
    String str = "";
    if (paramString == null) {
      return paramString;
    }
    if (paramString.length() != 8) {
      return paramString;
    }
    if ((paramString.startsWith("-")) || (paramString.startsWith("+"))) {
      return paramString;
    }
    try
    {
      long l = Long.valueOf(paramString).longValue();
    }
    catch (NumberFormatException localNumberFormatException1)
    {
      return paramString;
    }
    int i;
    int j;
    int k;
    try
    {
      i = Integer.valueOf(paramString.substring(0, 4)).intValue();
      j = Integer.valueOf(paramString.substring(4, 6)).intValue();
      k = Integer.valueOf(paramString.substring(6, 8)).intValue();
    }
    catch (NumberFormatException localNumberFormatException2)
    {
      return paramString;
    }
    if ((j > 12) || (j < 1)) {
      return paramString;
    }
    if ((k > getMonthDays(i, j)) || (k < 1)) {
      return paramString;
    }
    str = String.valueOf(i);
    if (j < 10) {
      str = str + "0" + j;
    } else {
      str = str + j;
    }
    if (k < 11) {
      k = 10;
    } else if (k < 21) {
      k = 20;
    } else {
      k = getMonthDays(i, j);
    }
    if (k < 10) {
      str = str + "0" + k;
    } else {
      str = str + k;
    }
    return str;
  }
  
  public static final String[] getDays(String paramString1, String paramString2)
  {
    String[] arrayOfString = new String[0];
    Vector localVector = new Vector();
    if (nextDay(paramString1).equals(paramString1)) {
      return arrayOfString;
    }
    if (nextDay(paramString2).equals(paramString2)) {
      return arrayOfString;
    }
    String str = paramString1;
    int i = str.compareTo(paramString2);
    if (i > 0) {
      return arrayOfString;
    }
    while (i <= 0)
    {
      localVector.addElement(str);
      str = nextDay(str);
      i = str.compareTo(paramString2);
    }
    arrayOfString = new String[localVector.size()];
    for (i = 0; i < localVector.size(); i++) {
      arrayOfString[i] = localVector.elementAt(i).toString();
    }
    return arrayOfString;
  }
  
  public static final String[] getTenDays(String paramString1, String paramString2)
  {
    String[] arrayOfString = getDays(paramString1, paramString2);
    Vector localVector = new Vector();
    String str = "xxxxxxxx";
    for (int i = 0; i < arrayOfString.length; i++) {
      if (!firstTenDay(arrayOfString[i]).equals(str))
      {
        str = firstTenDay(arrayOfString[i]);
        localVector.addElement(str);
      }
    }
    arrayOfString = new String[localVector.size()];
    for (i = 0; i < localVector.size(); i++) {
      arrayOfString[i] = localVector.elementAt(i).toString();
    }
    return arrayOfString;
  }
  
  public static final String[] getMonthDays(String paramString1, String paramString2)
  {
    String[] arrayOfString = getTenDays(paramString1, paramString2);
    Vector localVector = new Vector();
    String str = "xxxxxxxx";
    for (int i = 0; i < arrayOfString.length; i++) {
      if (!firstDay(arrayOfString[i]).equals(str))
      {
        str = firstDay(arrayOfString[i]);
        localVector.addElement(str);
      }
    }
    arrayOfString = new String[localVector.size()];
    for (i = 0; i < localVector.size(); i++) {
      arrayOfString[i] = localVector.elementAt(i).toString();
    }
    return arrayOfString;
  }
  
  public static final String[] getQuaterDays(String paramString1, String paramString2)
  {
    String[] arrayOfString = getMonthDays(paramString1, paramString2);
    Vector localVector = new Vector();
    String str = "xxxxxxxx";
    for (int i = 0; i < arrayOfString.length; i++) {
      if (!firstQuaterDay(arrayOfString[i]).equals(str))
      {
        str = firstQuaterDay(arrayOfString[i]);
        localVector.addElement(str);
      }
    }
    arrayOfString = new String[localVector.size()];
    for (i = 0; i < localVector.size(); i++) {
      arrayOfString[i] = localVector.elementAt(i).toString();
    }
    return arrayOfString;
  }
  
  public static final String[] getHarfYearDays(String paramString1, String paramString2)
  {
    String[] arrayOfString = getQuaterDays(paramString1, paramString2);
    Vector localVector = new Vector();
    String str = "xxxxxxxx";
    for (int i = 0; i < arrayOfString.length; i++) {
      if (!firstHarfYearDay(arrayOfString[i]).equals(str))
      {
        str = firstHarfYearDay(arrayOfString[i]);
        localVector.addElement(str);
      }
    }
    arrayOfString = new String[localVector.size()];
    for (i = 0; i < localVector.size(); i++) {
      arrayOfString[i] = localVector.elementAt(i).toString();
    }
    return arrayOfString;
  }
  
  public static final String[] getYearDays(String paramString1, String paramString2)
  {
    String[] arrayOfString = getHarfYearDays(paramString1, paramString2);
    Vector localVector = new Vector();
    String str = "xxxxxxxx";
    for (int i = 0; i < arrayOfString.length; i++) {
      if (!firstYearDay(arrayOfString[i]).equals(str))
      {
        str = firstYearDay(arrayOfString[i]);
        localVector.addElement(str);
      }
    }
    arrayOfString = new String[localVector.size()];
    for (i = 0; i < localVector.size(); i++) {
      arrayOfString[i] = localVector.elementAt(i).toString();
    }
    return arrayOfString;
  }
}


/* Location:           D:\tmp\oasql.jar
 * Qualified Name:     com.asql.core.DateOperator
 * JD-Core Version:    0.7.0.1
 */