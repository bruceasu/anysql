package com.asql.core;

import java.sql.ResultSet;
import java.sql.SQLException;

public abstract interface CommandLog
{
  public abstract void println();
  
  public abstract void print(ResultSet paramResultSet)
    throws SQLException;
  
  public abstract void print(DBRowCache paramDBRowCache);
  
  public abstract void print(int paramInt);
  
  public abstract void print(String paramString);
  
  public abstract void println(String paramString);
  
  public abstract void print(Exception paramException);
  
  public abstract void print(SQLException paramSQLException);
  
  public abstract void prompt(String paramString);
  
  public abstract int getPagesize();
  
  public abstract void setPagesize(int paramInt);
  
  public abstract void setSeperator(String paramString);
  
  public abstract void setRecord(String paramString);
  
  public abstract void setHeading(boolean paramBoolean);
  
  public abstract String getSeperator();
  
  public abstract String getRecord();
  
  public abstract boolean getHeading();
  
  public abstract void setAutotrace(boolean paramBoolean);
  
  public abstract void setTermout(boolean paramBoolean);
  
  public abstract void close();
  
  public abstract void setLogFile(CommandLog paramCommandLog);
  
  public abstract CommandLog getLogFile();
  
  public abstract void setFormDisplay(boolean paramBoolean);
  
  public abstract boolean getFormDisplay();
}


/* Location:           D:\tmp\oasql.jar
 * Qualified Name:     com.asql.core.CommandLog
 * JD-Core Version:    0.7.0.1
 */