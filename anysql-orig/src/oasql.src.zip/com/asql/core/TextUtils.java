package com.asql.core;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.Vector;

public final class TextUtils
{
  public static final Vector getFields(String paramString)
  {
    return getFields(paramString, ",", "\"");
  }
  
  public static final Vector getFields(String paramString1, String paramString2)
  {
    return getFields(paramString1, paramString2, "\"");
  }
  
  public static final Vector getFields(String paramString1, String paramString2, String paramString3)
  {
    Vector localVector = new Vector();
    if (paramString1 == null) {
      return localVector;
    }
    int i = 0;
    FieldTokenizer localFieldTokenizer = new FieldTokenizer(paramString1, paramString2, true);
    Object localObject = "";
    int j = 0;
    while (localFieldTokenizer.hasMoreTokens())
    {
      String str = localFieldTokenizer.nextToken();
      if (i != 0)
      {
        localObject = (String)localObject + str;
      }
      else
      {
        if (str.equals(paramString2))
        {
          if (j == 0) {
            localVector.addElement(null);
          }
          j = 0;
          continue;
        }
        localObject = str;
      }
      if (((String)localObject).startsWith(paramString3)) {
        i = 1;
      }
      if ((i == 0) || ((((String)localObject).endsWith(paramString3)) && (((String)localObject).length() != paramString3.length())))
      {
        if (((String)localObject).endsWith(paramString3)) {
          i = 0;
        }
        if ((((String)localObject).length() > paramString3.length()) && (((String)localObject).startsWith(paramString3)) && (((String)localObject).endsWith(paramString3)))
        {
          localObject = ((String)localObject).substring(paramString3.length());
          if (((String)localObject).length() >= paramString3.length()) {
            localObject = ((String)localObject).substring(0, ((String)localObject).length() - paramString3.length());
          }
        }
        if (i == 0)
        {
          localVector.addElement(localObject);
          j = 1;
        }
        localObject = "";
      }
    }
    if (j == 0) {
      localVector.addElement(null);
    }
    return localVector;
  }
  
  public static final Vector getWords(String paramString)
  {
    String[] arrayOfString = { " ", "\t", "\r", "\n" };
    return getWords(paramString, arrayOfString, "\"");
  }
  
  public static final Vector getWords(String paramString, String[] paramArrayOfString)
  {
    return getWords(paramString, paramArrayOfString, "\"");
  }
  
  public static final Vector getWords(String paramString1, String[] paramArrayOfString, String paramString2)
  {
    Vector localVector = new Vector();
    int i = 0;
    CommandTokenizer localCommandTokenizer = new CommandTokenizer(paramString1, paramArrayOfString, true);
    Object localObject = "";
    while (localCommandTokenizer.hasMoreTokens())
    {
      String str = localCommandTokenizer.nextToken();
      if (i != 0)
      {
        localObject = (String)localObject + str;
      }
      else
      {
        if (indexOf(paramArrayOfString, str) >= 0) {
          continue;
        }
        localObject = str;
      }
      if (((String)localObject).startsWith(paramString2)) {
        i = 1;
      }
      if ((i == 0) || (((((String)localObject).endsWith(paramString2)) || (((String)localObject).endsWith(paramString2 + "\n"))) && (((String)localObject).length() != paramString2.length())))
      {
        if ((((String)localObject).endsWith(paramString2)) || (((String)localObject).endsWith(paramString2 + "\n"))) {
          i = 0;
        }
        if ((((String)localObject).length() > paramString2.length()) && (((String)localObject).startsWith(paramString2)) && ((((String)localObject).endsWith(paramString2)) || (((String)localObject).endsWith(paramString2 + "\n"))))
        {
          localObject = ((String)localObject).substring(paramString2.length());
          if ((((String)localObject).length() >= paramString2.length()) && (((String)localObject).endsWith(paramString2))) {
            localObject = ((String)localObject).substring(0, ((String)localObject).length() - paramString2.length());
          } else if ((((String)localObject).length() >= paramString2.length()) && (((String)localObject).endsWith(paramString2 + "\n"))) {
            localObject = ((String)localObject).substring(0, ((String)localObject).length() - paramString2.length() - 1);
          }
        }
        if (i == 0)
        {
          if (((String)localObject).endsWith("\n")) {
            localObject = ((String)localObject).substring(0, ((String)localObject).length() - 1);
          }
          localVector.addElement(((String)localObject).trim());
        }
        localObject = "";
      }
    }
    if (((String)localObject).length() > 0)
    {
      if (((String)localObject).endsWith("\n")) {
        localObject = ((String)localObject).substring(0, ((String)localObject).length() - 1);
      }
      localVector.addElement(((String)localObject).trim());
    }
    return localVector;
  }
  
  public static final Vector getLines(String paramString)
  {
    String str = null;
    Vector localVector = new Vector();
    StringReader localStringReader = new StringReader(paramString);
    BufferedReader localBufferedReader = new BufferedReader(localStringReader);
    try
    {
      while ((str = localBufferedReader.readLine()) != null) {
        localVector.addElement(str);
      }
      localBufferedReader.close();
    }
    catch (IOException localIOException) {}
    return localVector;
  }
  
  public static final String[] toStringArray(Vector paramVector)
  {
    String[] arrayOfString = new String[0];
    if ((paramVector == null) || (paramVector.size() == 0)) {
      return arrayOfString;
    }
    arrayOfString = new String[paramVector.size()];
    for (int i = 0; i < paramVector.size(); i++) {
      arrayOfString[i] = paramVector.elementAt(i).toString();
    }
    return arrayOfString;
  }
  
  public static final int indexOf(Vector paramVector, String paramString)
  {
    return indexOf(paramVector, paramString, false);
  }
  
  public static final int indexOf(Vector paramVector, String paramString, boolean paramBoolean)
  {
    if (paramVector == null) {
      return -1;
    }
    if (paramVector.size() == 0) {
      return -1;
    }
    for (int i = 0; i < paramVector.size(); i++) {
      if (paramBoolean)
      {
        if (paramVector.elementAt(i).toString().equals(paramString)) {
          return i;
        }
      }
      else if (paramVector.elementAt(i).toString().equalsIgnoreCase(paramString)) {
        return i;
      }
    }
    return -1;
  }
  
  public static final int indexOf(String[] paramArrayOfString, String paramString)
  {
    return indexOf(paramArrayOfString, paramString, false);
  }
  
  public static final int indexOf(String[] paramArrayOfString, String paramString, boolean paramBoolean)
  {
    if (paramArrayOfString == null) {
      return -1;
    }
    if (paramArrayOfString.length == 0) {
      return -1;
    }
    for (int i = 0; i < paramArrayOfString.length; i++) {
      if (paramBoolean)
      {
        if (paramArrayOfString[i].equals(paramString)) {
          return i;
        }
      }
      else if (paramArrayOfString[i].equalsIgnoreCase(paramString)) {
        return i;
      }
    }
    return -1;
  }
}


/* Location:           D:\tmp\oasql.jar
 * Qualified Name:     com.asql.core.TextUtils
 * JD-Core Version:    0.7.0.1
 */