package com.asql.core;

import java.io.OutputStream;
import java.io.PrintStream;
import java.sql.ResultSet;
import java.sql.SQLException;

public class OutputCommandLog
  implements CommandLog
{
  private int _pagesize = 14;
  private String _seperator = " ";
  private String _record = "\r\n";
  private boolean _heading = true;
  private boolean _autotrace = false;
  private boolean _termout = true;
  private PrintStream _out = null;
  private CommandLog _logfile = null;
  private CommandExecutor _sql = null;
  private boolean _dispform = false;
  
  public void println()
  {
    if (this._termout) {
      this._out.println();
    }
    if (this._logfile != null) {
      this._logfile.println();
    }
  }
  
  public void setFormDisplay(boolean paramBoolean)
  {
    this._dispform = paramBoolean;
  }
  
  public boolean getFormDisplay()
  {
    return this._dispform;
  }
  
  public OutputCommandLog(CommandExecutor paramCommandExecutor, OutputStream paramOutputStream)
  {
    this._sql = paramCommandExecutor;
    this._out = new PrintStream(paramOutputStream);
  }
  
  public OutputCommandLog(CommandExecutor paramCommandExecutor, PrintStream paramPrintStream)
  {
    this._sql = paramCommandExecutor;
    this._out = paramPrintStream;
  }
  
  public void close()
  {
    this._out.close();
  }
  
  public void setTermout(boolean paramBoolean)
  {
    this._termout = paramBoolean;
  }
  
  private String getFixedWidth(String paramString, int paramInt, boolean paramBoolean)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    if ((paramBoolean) && (paramString != null)) {
      localStringBuffer.append(paramString);
    }
    for (int i = paramString == null ? 0 : paramString.getBytes().length; i < paramInt; i++) {
      localStringBuffer.append(" ");
    }
    if ((!paramBoolean) && (paramString != null)) {
      localStringBuffer.append(paramString);
    }
    return localStringBuffer.toString();
  }
  
  public void print(DBRowCache paramDBRowCache)
  {
    int i = 0;
    int j = 0;
    int k = 0;
    if (paramDBRowCache == null) {
      return;
    }
    if (paramDBRowCache.getColumnCount() == 0) {
      return;
    }
    if (this._seperator.equals(" ")) {
      paramDBRowCache.getWidth(false);
    }
    i = paramDBRowCache.getRowCount();
    for (int m = 1; m <= paramDBRowCache.getColumnCount(); m++) {
      if (paramDBRowCache.getColumnName(m).length() > k) {
        k = paramDBRowCache.getColumnName(m).length();
      }
    }
    if (!this._dispform) {
      for (m = 1; m <= i; m++)
      {
        if (this._heading)
        {
          if ((j == 0) || ((this._pagesize > 0) && ((m % this._pagesize == 1) || (this._pagesize == 1))))
          {
            if (j > 0)
            {
              if (this._termout) {
                this._out.println();
              }
              if (this._logfile != null) {
                this._logfile.println();
              }
            }
            if (this._seperator.equals(" "))
            {
              if (this._termout)
              {
                this._out.println(paramDBRowCache.getFixedHeader());
                this._out.println(paramDBRowCache.getSeperator());
              }
              if (this._logfile != null)
              {
                this._logfile.println(paramDBRowCache.getFixedHeader());
                this._logfile.println(paramDBRowCache.getSeperator());
              }
            }
            else
            {
              if (this._termout) {
                this._out.println(paramDBRowCache.getSepHeader(this._seperator));
              }
              if (this._logfile != null) {
                this._logfile.println(paramDBRowCache.getSepHeader(this._seperator));
              }
            }
          }
        }
        else if (((j == 0) || ((this._pagesize > 0) && ((m % this._pagesize == 1) || (this._pagesize == 1)))) && (j > 0))
        {
          if (this._termout) {
            this._out.println();
          }
          if (this._logfile != null) {
            this._logfile.println();
          }
        }
        if (this._seperator.equals(" "))
        {
          if (this._termout) {
            this._out.println(paramDBRowCache.getFixedRow(m));
          }
          if (this._logfile != null) {
            this._logfile.println(paramDBRowCache.getFixedRow(m));
          }
        }
        else
        {
          if (this._termout) {
            this._out.println(paramDBRowCache.getSepRow(this._seperator, m));
          }
          if (this._logfile != null) {
            this._logfile.println(paramDBRowCache.getSepRow(this._seperator, m));
          }
        }
        j++;
      }
    }
    for (m = 1; m <= i; m++)
    {
      for (int n = 1; n <= paramDBRowCache.getColumnCount(); n++)
      {
        if (this._termout) {
          this._out.println(getFixedWidth(paramDBRowCache.getColumnName(n), k + 1, true) + ": " + paramDBRowCache.getString(m, n));
        }
        if (this._logfile != null) {
          this._logfile.println(getFixedWidth(paramDBRowCache.getColumnName(n), k + 1, true) + ": " + paramDBRowCache.getString(m, n));
        }
      }
      if (m < i)
      {
        if (this._termout) {
          this._out.println();
        }
        if (this._logfile != null) {
          this._logfile.println();
        }
      }
    }
    paramDBRowCache.deleteAllRow();
    if (i > 0)
    {
      if (this._termout) {
        this._out.println();
      }
      if (this._logfile != null) {
        this._logfile.println();
      }
    }
    if (this._termout) {
      this._out.println(j + " rows returned.");
    }
    if (this._logfile != null) {
      this._logfile.println(j + " rows returned.");
    }
  }
  
  public void print(ResultSet paramResultSet)
    throws SQLException
  {
    SimpleDBRowCache localSimpleDBRowCache = new SimpleDBRowCache();
    int i = this._pagesize > 0 ? 400 / this._pagesize * this._pagesize : 400;
    int j = 0;
    int k = 0;
    int m = 0;
    if (this._autotrace)
    {
      while (paramResultSet.next()) {
        k++;
      }
      this._out.println(k + " rows returned.");
      if (this._logfile != null) {
        this._logfile.println(k + " rows returned.");
      }
      return;
    }
    while ((j = this._sql.fetch(paramResultSet, localSimpleDBRowCache, i)) > 0)
    {
      if (m == 0) {
        for (n = 1; n <= localSimpleDBRowCache.getColumnCount(); n++) {
          if (localSimpleDBRowCache.getColumnName(n).length() > m) {
            m = localSimpleDBRowCache.getColumnName(n).length();
          }
        }
      }
      if (this._seperator.equals(" ")) {
        localSimpleDBRowCache.getWidth(false);
      }
      if (!this._dispform) {
        for (n = 1; n <= localSimpleDBRowCache.getRowCount(); n++)
        {
          if (this._heading)
          {
            if ((k == 0) || ((this._pagesize > 0) && ((n % this._pagesize == 1) || (this._pagesize == 1))))
            {
              if (k > 0)
              {
                if (this._termout) {
                  this._out.println();
                }
                if (this._logfile != null) {
                  this._logfile.println();
                }
              }
              if (this._seperator.equals(" "))
              {
                if (this._termout)
                {
                  this._out.println(localSimpleDBRowCache.getFixedHeader());
                  this._out.println(localSimpleDBRowCache.getSeperator());
                }
                if (this._logfile != null)
                {
                  this._logfile.println(localSimpleDBRowCache.getFixedHeader());
                  this._logfile.println(localSimpleDBRowCache.getSeperator());
                }
              }
              else
              {
                if (this._termout) {
                  this._out.println(localSimpleDBRowCache.getSepHeader(this._seperator));
                }
                if (this._logfile != null) {
                  this._logfile.println(localSimpleDBRowCache.getSepHeader(this._seperator));
                }
              }
            }
          }
          else if (((k == 0) || ((this._pagesize > 0) && ((n % this._pagesize == 1) || (this._pagesize == 1)))) && (k > 0))
          {
            if (this._termout) {
              this._out.println();
            }
            if (this._logfile != null) {
              this._logfile.println();
            }
          }
          if (this._seperator.equals(" "))
          {
            if (this._termout) {
              this._out.println(localSimpleDBRowCache.getFixedRow(n));
            }
            if (this._logfile != null) {
              this._logfile.println(localSimpleDBRowCache.getFixedRow(n));
            }
          }
          else
          {
            if (this._termout) {
              this._out.println(localSimpleDBRowCache.getSepRow(this._seperator, n));
            }
            if (this._logfile != null) {
              this._logfile.println(localSimpleDBRowCache.getSepRow(this._seperator, n));
            }
          }
          k++;
        }
      }
      for (int n = 1; n <= j; n++)
      {
        for (int i1 = 1; i1 <= localSimpleDBRowCache.getColumnCount(); i1++)
        {
          if (this._termout) {
            this._out.println(getFixedWidth(localSimpleDBRowCache.getColumnName(i1), m + 1, true) + ": " + localSimpleDBRowCache.getString(n, i1));
          }
          if (this._logfile != null) {
            this._logfile.println(getFixedWidth(localSimpleDBRowCache.getColumnName(i1), m + 1, true) + ": " + localSimpleDBRowCache.getString(n, i1));
          }
        }
        if (n < j)
        {
          if (this._termout) {
            this._out.println();
          }
          if (this._logfile != null) {
            this._logfile.println();
          }
        }
        k++;
      }
      localSimpleDBRowCache.deleteAllRow();
      if (j > 0)
      {
        if (this._termout) {
          this._out.println();
        }
        if (this._logfile != null) {
          this._logfile.println();
        }
      }
    }
    if (this._termout) {
      this._out.println(k + " rows returned.");
    }
    if (this._logfile != null) {
      this._logfile.println(k + " rows returned.");
    }
  }
  
  public void print(int paramInt)
  {
    if (this._termout) {
      this._out.println(paramInt + " rows affected.");
    }
    if (this._logfile != null) {
      this._logfile.println(paramInt + " rows affected.");
    }
  }
  
  public void print(String paramString)
  {
    if (this._termout) {
      this._out.print(paramString);
    }
    if (this._logfile != null) {
      this._logfile.print(paramString);
    }
  }
  
  public void prompt(String paramString)
  {
    this._out.print(paramString);
    if (this._logfile != null) {
      this._logfile.print(paramString);
    }
  }
  
  public void println(String paramString)
  {
    if (this._termout) {
      this._out.println(paramString);
    }
    if (this._logfile != null) {
      this._logfile.println(paramString);
    }
  }
  
  private String removeNewLine(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    for (int i = arrayOfChar.length - 1; (i >= 0) && ((arrayOfChar[i] == '\r') || (arrayOfChar[i] == '\n') || (arrayOfChar[i] == '\t') || (arrayOfChar[i] == ' ')); i--) {}
    if (i >= 0) {
      return String.valueOf(arrayOfChar, 0, i + 1);
    }
    return "";
  }
  
  public void print(Exception paramException)
  {
    String str = paramException.getMessage();
    this._out.println(removeNewLine(str));
    if (this._logfile != null) {
      this._logfile.println(removeNewLine(str));
    }
  }
  
  public void print(SQLException paramSQLException)
  {
    String str = paramSQLException.getMessage();
    this._out.println(removeNewLine(str));
    if (this._logfile != null) {
      this._logfile.println(removeNewLine(str));
    }
  }
  
  public int getPagesize()
  {
    return this._pagesize;
  }
  
  public void setPagesize(int paramInt)
  {
    if ((paramInt >= 0) && (paramInt <= 200)) {
      this._pagesize = paramInt;
    }
  }
  
  public void setSeperator(String paramString)
  {
    this._seperator = paramString;
  }
  
  public void setRecord(String paramString)
  {
    if ((paramString == null) || (paramString.length() == 0))
    {
      this._record = "\r\n";
      return;
    }
    char[] arrayOfChar = paramString.toCharArray();
    StringBuffer localStringBuffer = new StringBuffer();
    for (int i = 0; i < arrayOfChar.length; i++) {
      if (arrayOfChar[i] == '\\')
      {
        if (i + 1 < arrayOfChar.length)
        {
          if (arrayOfChar[(i + 1)] == 'r')
          {
            localStringBuffer.append('\r');
          }
          else if (arrayOfChar[(i + 1)] == 'n')
          {
            localStringBuffer.append('\n');
          }
          else
          {
            localStringBuffer.append(arrayOfChar[i]);
            localStringBuffer.append(arrayOfChar[(i + 1)]);
          }
          i += 1;
        }
        else
        {
          localStringBuffer.append(arrayOfChar[i]);
        }
      }
      else {
        localStringBuffer.append(arrayOfChar[i]);
      }
    }
    this._record = localStringBuffer.toString();
  }
  
  public String getSeperator()
  {
    return this._seperator;
  }
  
  public String getRecord()
  {
    return this._record;
  }
  
  public boolean getHeading()
  {
    return this._heading;
  }
  
  public void setAutotrace(boolean paramBoolean)
  {
    this._autotrace = paramBoolean;
  }
  
  public void setHeading(boolean paramBoolean)
  {
    this._heading = paramBoolean;
  }
  
  public void setLogFile(CommandLog paramCommandLog)
  {
    this._logfile = paramCommandLog;
  }
  
  public CommandLog getLogFile()
  {
    return this._logfile;
  }
}


/* Location:           D:\tmp\oasql.jar
 * Qualified Name:     com.asql.core.OutputCommandLog
 * JD-Core Version:    0.7.0.1
 */