package com.asql.core;

import java.io.IOException;
import java.io.InputStream;

public class InputCommandReader
  implements CommandReader
{
  private InputStream _in = null;
  private CommandStreamReader stdin = null;
  private String working_dir = JavaVM.USER_DIRECTORY;
  
  public InputCommandReader(InputStream paramInputStream)
  {
    this._in = paramInputStream;
    this.stdin = new CommandStreamReader(this._in);
  }
  
  public void close()
  {
    try
    {
      this._in.close();
    }
    catch (IOException localIOException) {}
  }
  
  public String readline()
    throws IOException
  {
    StringBuffer localStringBuffer = new StringBuffer();
    char c = '\000';
    int i = 0;
    while ((i = this.stdin.read()) != -1)
    {
      c = (char)i;
      if (c == '\n') {
        break;
      }
      if (c != '\r') {
        localStringBuffer.append(c);
      }
    }
    if ((i == -1) && (localStringBuffer.length() == 0)) {
      return null;
    }
    return localStringBuffer.toString();
  }
  
  public String readPassword()
    throws Exception
  {
    return PasswordReader.readPassword("Password: ");
  }
  
  public String getWorkingDir()
  {
    return this.working_dir;
  }
  
  public void setWorkingDir(String paramString)
  {
    this.working_dir = paramString;
  }
}


/* Location:           D:\tmp\oasql.jar
 * Qualified Name:     com.asql.core.InputCommandReader
 * JD-Core Version:    0.7.0.1
 */